"use server";

import { and, eq, gt, isNull } from "drizzle-orm";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { businesses, passwordResetTokens, userPreferences, users } from "@/db/schema";
import {
  createSession,
  deleteAllUserSessions,
  destroySession,
  generateToken,
  hashPassword,
  sha256,
  verifyPassword,
} from "@/lib/auth";
import { getAppOrigin, isEmailConfigured, sendEmail } from "@/lib/email";
import { safeTz } from "@/lib/format";
import type { ActionState } from "@/lib/types";
import { emailSchema, fieldErrorsFrom, formToObject, loginSchema, registerSchema, resetPasswordSchema } from "@/lib/validation";

export async function register(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = registerSchema.safeParse(formToObject(formData, ["fullName", "businessName", "email", "password", "timeZone"]));
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  const { fullName, businessName, email, password, timeZone } = parsed.data;

  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length > 0) {
    return { fieldErrors: { email: "An account with this email already exists. Try logging in instead." } };
  }

  const passwordHash = await hashPassword(password);
  let userId: string;
  try {
    userId = await db.transaction(async (tx) => {
      const [u] = await tx.insert(users).values({ fullName, email, passwordHash }).returning({ id: users.id });
      await tx.insert(businesses).values({ ownerId: u.id, name: businessName });
      await tx.insert(userPreferences).values({ userId: u.id, timeZone: safeTz(timeZone) });
      return u.id;
    });
  } catch {
    return { error: "We couldn't create your account right now. Please try again." };
  }

  await createSession(userId, true);
  redirect("/onboarding");
}

export async function login(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = loginSchema.safeParse(formToObject(formData, ["email", "password"]));
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  const remember = formData.get("remember") === "on";

  const [user] = await db.select().from(users).where(eq(users.email, parsed.data.email)).limit(1);
  if (!user || !(await verifyPassword(parsed.data.password, user.passwordHash))) {
    return { error: "Incorrect email or password." };
  }

  await createSession(user.id, remember);
  const [biz] = await db
    .select({ onboardingCompleted: businesses.onboardingCompleted })
    .from(businesses)
    .where(eq(businesses.ownerId, user.id))
    .limit(1);
  redirect(biz?.onboardingCompleted ? "/dashboard" : "/onboarding");
}

export async function logout() {
  await destroySession();
  redirect("/login");
}

export async function requestPasswordReset(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = emailSchema.safeParse(formData.get("email"));
  if (!parsed.success) return { fieldErrors: { email: parsed.error.issues[0]?.message ?? "Enter a valid email address" } };
  const email = parsed.data;
  const emailConfigured = isEmailConfigured();

  const [user] = await db.select({ id: users.id, fullName: users.fullName }).from(users).where(eq(users.email, email)).limit(1);
  if (!user) {
    return {
      ok: true,
      message: emailConfigured
        ? "If an account exists for this email, we've sent a password reset link."
        : "No account was found for this email address.",
      data: { emailConfigured: emailConfigured ? "1" : "0" },
    };
  }

  const token = generateToken();
  await db.insert(passwordResetTokens).values({
    userId: user.id,
    tokenHash: sha256(token),
    expiresAt: new Date(Date.now() + 60 * 60 * 1000),
  });
  const resetPath = `/reset-password?token=${token}`;

  if (emailConfigured) {
    const origin = await getAppOrigin();
    const sent = await sendEmail({
      to: email,
      subject: "Reset your LeadFlow password",
      html: `<p>Hi ${user.fullName},</p><p>Click the link below to reset your LeadFlow password. The link expires in 1 hour.</p><p><a href="${origin}${resetPath}">${origin}${resetPath}</a></p><p>If you did not request this, you can ignore this email.</p>`,
    });
    if (sent) {
      return { ok: true, message: "We've emailed you a password reset link. It expires in 1 hour.", data: { emailConfigured: "1" } };
    }
    return {
      ok: true,
      message: "We couldn't deliver the email. Use the secure link below to reset your password.",
      data: { resetPath, emailConfigured: "0" },
    };
  }

  return {
    ok: true,
    message: "Email delivery is not configured for this deployment, so your secure reset link is shown below.",
    data: { resetPath, emailConfigured: "0" },
  };
}

export async function resetPassword(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = resetPasswordSchema.safeParse(formToObject(formData, ["token", "password", "confirmPassword"]));
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };

  const [row] = await db
    .select()
    .from(passwordResetTokens)
    .where(
      and(
        eq(passwordResetTokens.tokenHash, sha256(parsed.data.token)),
        isNull(passwordResetTokens.usedAt),
        gt(passwordResetTokens.expiresAt, new Date()),
      ),
    )
    .limit(1);
  if (!row) return { error: "This reset link is invalid or has expired. Please request a new one." };

  const passwordHash = await hashPassword(parsed.data.password);
  await db.transaction(async (tx) => {
    await tx.update(users).set({ passwordHash, updatedAt: new Date() }).where(eq(users.id, row.userId));
    await tx.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, row.id));
  });
  await deleteAllUserSessions(row.userId);
  redirect("/login?reset=1");
}
