"use server";

import { and, count, eq, like, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/db";
import {
  activityLogs,
  customers,
  enquiries,
  enquirySources,
  followUps,
  notifications,
  type Enquiry,
} from "@/db/schema";
import { requireUser, type AuthContext } from "@/lib/auth";
import { DEFAULT_SOURCES, isStatus, statusMeta, type EnquiryStatus } from "@/lib/constants";
import { createNotification, logActivity } from "@/lib/events";
import { makeZonedDate } from "@/lib/format";
import type { ActionState } from "@/lib/types";
import { enquirySchema, fieldErrorsFrom, formToObject, parseMoney } from "@/lib/validation";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

const ENQUIRY_KEYS = [
  "customerName",
  "phone",
  "email",
  "company",
  "title",
  "description",
  "source",
  "productService",
  "enquiryDate",
  "assignedTo",
  "priority",
  "estimatedValue",
  "internalNotes",
  "status",
  "lostReason",
  "followUpDate",
  "followUpTime",
  "customSource",
];

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

async function getOwnedEnquiry(businessId: string, id: string) {
  const rows = await db
    .select({ enquiry: enquiries, customerName: customers.fullName })
    .from(enquiries)
    .innerJoin(customers, eq(customers.id, enquiries.customerId))
    .where(and(eq(enquiries.id, id), eq(enquiries.businessId, businessId)))
    .limit(1);
  return rows[0] ?? null;
}

async function findOrCreateCustomer(
  tx: Tx,
  businessId: string,
  data: { customerName: string; phone: string; email: string; company: string },
) {
  const email = data.email || null;
  const digits = data.phone.replace(/\D/g, "");
  let existing: { id: string; email: string | null; company: string | null } | undefined;
  if (email) {
    existing = (
      await tx
        .select({ id: customers.id, email: customers.email, company: customers.company })
        .from(customers)
        .where(and(eq(customers.businessId, businessId), eq(customers.email, email)))
        .limit(1)
    )[0];
  }
  if (!existing && digits.length >= 6) {
    existing = (
      await tx
        .select({ id: customers.id, email: customers.email, company: customers.company })
        .from(customers)
        .where(and(eq(customers.businessId, businessId), sql`regexp_replace(coalesce(${customers.phone}, ''), '[^0-9]', '', 'g') = ${digits}`))
        .limit(1)
    )[0];
  }
  if (existing) {
    await tx
      .update(customers)
      .set({
        email: existing.email ?? email,
        company: existing.company ?? (data.company || null),
        updatedAt: new Date(),
      })
      .where(eq(customers.id, existing.id));
    return existing.id;
  }
  const [c] = await tx
    .insert(customers)
    .values({ businessId, fullName: data.customerName, phone: data.phone, email, company: data.company || null })
    .returning({ id: customers.id });
  return c.id;
}

/** Shared status-transition logic with the automation rules attached to it. */
async function applyStatusChange(
  tx: Tx,
  ctx: AuthContext,
  enquiry: Enquiry,
  customerName: string,
  newStatus: EnquiryStatus,
  lostReason?: string | null,
) {
  const now = new Date();
  const set: Partial<typeof enquiries.$inferInsert> = { status: newStatus, updatedAt: now };
  if (newStatus === "contacted" && !enquiry.contactedAt) set.contactedAt = now;
  if (newStatus === "converted") {
    set.convertedAt = now;
    set.lostAt = null;
    set.lostReason = null;
  } else if (newStatus === "lost") {
    set.lostAt = now;
    set.lostReason = lostReason?.trim() || null;
    set.convertedAt = null;
  } else {
    set.convertedAt = null;
    set.lostAt = null;
    set.lostReason = null;
  }
  await tx.update(enquiries).set(set).where(eq(enquiries.id, enquiry.id));

  if (newStatus === "converted" || newStatus === "lost") {
    const cancelled = await tx
      .update(followUps)
      .set({ status: "cancelled", completionNotes: `Auto-cancelled: enquiry marked as ${newStatus}`, updatedAt: now })
      .where(and(eq(followUps.enquiryId, enquiry.id), eq(followUps.status, "pending")))
      .returning({ id: followUps.id });
    for (const f of cancelled) {
      await tx.delete(notifications).where(and(eq(notifications.userId, ctx.user.id), like(notifications.dedupeKey, `fu:${f.id}:%`)));
    }
    if (cancelled.length > 0) {
      await tx.insert(activityLogs).values({
        businessId: ctx.business.id,
        enquiryId: enquiry.id,
        userId: ctx.user.id,
        type: "follow_up_cancelled",
        description: `${cancelled.length} pending follow-up${cancelled.length === 1 ? "" : "s"} auto-cancelled because the enquiry was marked as ${newStatus}`,
      });
    }
  }

  const fromLabel = statusMeta(enquiry.status).label;
  const toLabel = statusMeta(newStatus).label;
  await tx.insert(activityLogs).values({
    businessId: ctx.business.id,
    enquiryId: enquiry.id,
    userId: ctx.user.id,
    type: newStatus === "converted" ? "converted" : newStatus === "lost" ? "lost" : "status_changed",
    description:
      newStatus === "converted"
        ? `Enquiry marked as converted — ${customerName} is now a customer`
        : newStatus === "lost"
          ? `Enquiry marked as lost: ${lostReason?.trim() || "No reason provided"}`
          : `Status changed from ${fromLabel} to ${toLabel}`,
    metadata: { from: enquiry.status, to: newStatus },
  });

  if (newStatus === "converted" && ctx.prefs.notifyConversions) {
    await tx
      .insert(notifications)
      .values({
        businessId: ctx.business.id,
        userId: ctx.user.id,
        type: "enquiry_converted",
        title: "Enquiry converted 🎉",
        message: `${customerName} became a customer — "${enquiry.title}".`,
        link: `/enquiries/${enquiry.id}`,
        dedupeKey: `converted:${enquiry.id}:${now.getTime()}`,
      })
      .onConflictDoNothing();
  }
}

export async function createEnquiry(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const ctx = await requireUser();
  const raw = formToObject(formData, ENQUIRY_KEYS);
  if (raw.source === "__custom__") raw.source = raw.customSource.trim();
  const parsed = enquirySchema.safeParse(raw);
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error), data: raw };
  const d = parsed.data;
  const money = parseMoney(d.estimatedValue);
  if (money.error) return { fieldErrors: { estimatedValue: money.error }, data: raw };

  let followUpAt: Date | null = null;
  if (d.followUpDate) {
    if (!DATE_RE.test(d.followUpDate)) return { fieldErrors: { followUpDate: "Enter a valid follow-up date" }, data: raw };
    followUpAt = makeZonedDate(d.followUpDate, d.followUpTime || "09:00", ctx.prefs.timeZone);
  }

  const businessId = ctx.business.id;
  const isCustomSource = !DEFAULT_SOURCES.includes(d.source);
  let enquiryId = "";

  try {
    await db.transaction(async (tx) => {
      const customerId = await findOrCreateCustomer(tx, businessId, d);
      if (isCustomSource) {
        await tx.insert(enquirySources).values({ businessId, name: d.source, isCustom: true }).onConflictDoNothing();
      }
      const [e] = await tx
        .insert(enquiries)
        .values({
          businessId,
          customerId,
          title: d.title,
          description: d.description || null,
          source: d.source,
          productService: d.productService || null,
          enquiryDate: d.enquiryDate,
          assignedTo: d.assignedTo || null,
          status: "new",
          priority: d.priority,
          estimatedValue: money.value,
          internalNotes: d.internalNotes || null,
        })
        .returning({ id: enquiries.id });
      enquiryId = e.id;
      await tx.insert(activityLogs).values({
        businessId,
        enquiryId,
        userId: ctx.user.id,
        type: "enquiry_created",
        description: `Enquiry "${d.title}" received via ${d.source}`,
      });
      if (followUpAt) {
        await tx.insert(followUps).values({
          businessId,
          enquiryId,
          title: `Follow up with ${d.customerName}`,
          description: `First follow-up for "${d.title}"`,
          dueAt: followUpAt,
          priority: d.priority,
          createdById: ctx.user.id,
        });
        await tx.insert(activityLogs).values({
          businessId,
          enquiryId,
          userId: ctx.user.id,
          type: "follow_up_scheduled",
          description: `Follow-up scheduled: "Follow up with ${d.customerName}"`,
        });
      }
    });
  } catch (err) {
    console.error("createEnquiry failed", err);
    return { error: "Could not save the enquiry. Please try again." };
  }

  if (ctx.prefs.notifyNewEnquiry) {
    await createNotification({
      businessId,
      userId: ctx.user.id,
      type: "new_enquiry",
      title: "New enquiry added",
      message: `${d.customerName} enquired about "${d.title}" via ${d.source}.`,
      link: `/enquiries/${enquiryId}`,
      dedupeKey: `new:${enquiryId}`,
    });
  }

  revalidatePath("/", "layout");
  redirect(`/enquiries/${enquiryId}`);
}

export async function updateEnquiry(id: string, _prev: ActionState, formData: FormData): Promise<ActionState> {
  const ctx = await requireUser();
  const owned = await getOwnedEnquiry(ctx.business.id, id);
  if (!owned) return { error: "Enquiry not found." };
  const existing = owned.enquiry;

  const raw = formToObject(formData, ENQUIRY_KEYS);
  if (raw.source === "__custom__") raw.source = raw.customSource.trim();
  const parsed = enquirySchema.safeParse(raw);
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error), data: raw };
  const d = parsed.data;
  const money = parseMoney(d.estimatedValue);
  if (money.error) return { fieldErrors: { estimatedValue: money.error }, data: raw };

  const newStatus = d.status && isStatus(d.status) ? d.status : existing.status;
  if (newStatus === "lost" && existing.status !== "lost" && !d.lostReason?.trim()) {
    return { fieldErrors: { lostReason: "Please record why this enquiry was lost" }, data: raw };
  }
  const isCustomSource = !DEFAULT_SOURCES.includes(d.source);

  try {
    await db.transaction(async (tx) => {
      await tx
        .update(customers)
        .set({
          fullName: d.customerName,
          phone: d.phone,
          email: d.email || null,
          company: d.company || null,
          updatedAt: new Date(),
        })
        .where(eq(customers.id, existing.customerId));
      if (isCustomSource) {
        await tx.insert(enquirySources).values({ businessId: ctx.business.id, name: d.source, isCustom: true }).onConflictDoNothing();
      }
      await tx
        .update(enquiries)
        .set({
          title: d.title,
          description: d.description || null,
          source: d.source,
          productService: d.productService || null,
          enquiryDate: d.enquiryDate,
          assignedTo: d.assignedTo || null,
          priority: d.priority,
          estimatedValue: money.value,
          internalNotes: d.internalNotes || null,
          lostReason: newStatus === "lost" ? d.lostReason?.trim() || existing.lostReason : existing.lostReason,
          updatedAt: new Date(),
        })
        .where(eq(enquiries.id, id));

      const changes: string[] = [];
      if (d.title !== existing.title) changes.push("title");
      if (d.priority !== existing.priority) changes.push("priority");
      if (d.source !== existing.source) changes.push("source");
      if ((money.value ?? null) !== (existing.estimatedValue ?? null)) changes.push("estimated value");
      if (d.enquiryDate !== existing.enquiryDate) changes.push("enquiry date");
      if ((d.assignedTo || null) !== (existing.assignedTo ?? null)) changes.push("assignee");
      await tx.insert(activityLogs).values({
        businessId: ctx.business.id,
        enquiryId: id,
        userId: ctx.user.id,
        type: "enquiry_updated",
        description: changes.length > 0 ? `Enquiry details updated (${changes.join(", ")})` : "Enquiry details updated",
      });

      if (newStatus !== existing.status) {
        await applyStatusChange(tx, ctx, existing, d.customerName, newStatus, d.lostReason);
      }
    });
  } catch (err) {
    console.error("updateEnquiry failed", err);
    return { error: "Could not update the enquiry. Please try again." };
  }

  revalidatePath("/", "layout");
  redirect(`/enquiries/${id}`);
}

export async function changeEnquiryStatus(enquiryId: string, status: string, lostReason?: string): Promise<ActionState> {
  const ctx = await requireUser();
  if (!isStatus(status)) return { error: "Invalid status." };
  const owned = await getOwnedEnquiry(ctx.business.id, enquiryId);
  if (!owned) return { error: "Enquiry not found." };
  if (owned.enquiry.status === status) return { ok: true };
  if (status === "lost" && !lostReason?.trim()) return { error: "Please provide a reason for marking this enquiry as lost." };

  try {
    await db.transaction((tx) => applyStatusChange(tx, ctx, owned.enquiry, owned.customerName, status, lostReason));
  } catch (err) {
    console.error("changeEnquiryStatus failed", err);
    return { error: "Could not update the status. Please try again." };
  }
  revalidatePath("/", "layout");
  return { ok: true, message: `Status updated to ${statusMeta(status).label}` };
}

export async function logContact(enquiryId: string, method: string): Promise<ActionState> {
  const ctx = await requireUser();
  const owned = await getOwnedEnquiry(ctx.business.id, enquiryId);
  if (!owned) return { error: "Enquiry not found." };
  const safeMethod = ["phone", "email", "whatsapp", "meeting", "other"].includes(method) ? method : "other";
  const label = { phone: "by phone", email: "by email", whatsapp: "on WhatsApp", meeting: "in a meeting", other: "" }[safeMethod];
  const now = new Date();
  try {
    await db.transaction(async (tx) => {
      await tx.insert(activityLogs).values({
        businessId: ctx.business.id,
        enquiryId,
        userId: ctx.user.id,
        type: "contacted",
        description: `Customer contacted${label ? ` ${label}` : ""}`,
        metadata: { method: safeMethod },
      });
      if (!owned.enquiry.contactedAt) {
        await tx.update(enquiries).set({ contactedAt: now, updatedAt: now }).where(eq(enquiries.id, enquiryId));
      }
      if (owned.enquiry.status === "new") {
        await applyStatusChange(tx, ctx, owned.enquiry, owned.customerName, "contacted");
      }
    });
  } catch (err) {
    console.error("logContact failed", err);
    return { error: "Could not log the contact. Please try again." };
  }
  revalidatePath("/", "layout");
  return { ok: true, message: "Contact logged" };
}

export async function deleteEnquiry(enquiryId: string): Promise<ActionState> {
  const ctx = await requireUser();
  const owned = await getOwnedEnquiry(ctx.business.id, enquiryId);
  if (!owned) return { error: "Enquiry not found." };
  try {
    await db.transaction(async (tx) => {
      await tx.delete(enquiries).where(eq(enquiries.id, enquiryId));
      await tx.delete(notifications).where(and(eq(notifications.userId, ctx.user.id), eq(notifications.link, `/enquiries/${enquiryId}`)));
      const [remaining] = await tx.select({ n: count() }).from(enquiries).where(eq(enquiries.customerId, owned.enquiry.customerId));
      if ((remaining?.n ?? 0) === 0) {
        await tx.delete(customers).where(eq(customers.id, owned.enquiry.customerId));
      }
      await tx.insert(activityLogs).values({
        businessId: ctx.business.id,
        enquiryId: null,
        userId: ctx.user.id,
        type: "enquiry_deleted",
        description: `Enquiry "${owned.enquiry.title}" for ${owned.customerName} was deleted`,
      });
    });
  } catch (err) {
    console.error("deleteEnquiry failed", err);
    return { error: "Could not delete the enquiry. Please try again." };
  }
  revalidatePath("/", "layout");
  return { ok: true, message: "Enquiry deleted" };
}

export async function recordActivityNote(enquiryId: string, description: string): Promise<ActionState> {
  const ctx = await requireUser();
  const owned = await getOwnedEnquiry(ctx.business.id, enquiryId);
  if (!owned) return { error: "Enquiry not found." };
  await logActivity({ businessId: ctx.business.id, enquiryId, userId: ctx.user.id, type: "note_added", description });
  revalidatePath("/", "layout");
  return { ok: true };
}
