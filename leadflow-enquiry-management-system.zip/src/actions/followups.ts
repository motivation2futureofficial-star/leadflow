"use server";

import { and, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { customers, enquiries, followUps } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { clearFollowUpNotifications, createNotification, logActivity, resolveFollowUpNotifications } from "@/lib/events";
import { formatDateTime, makeZonedDate } from "@/lib/format";
import type { ActionState } from "@/lib/types";
import { fieldErrorsFrom, followUpSchema, formToObject } from "@/lib/validation";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^\d{2}:\d{2}$/;

async function getOwnedFollowUp(businessId: string, id: string) {
  const rows = await db
    .select({ followUp: followUps, customerName: customers.fullName })
    .from(followUps)
    .innerJoin(enquiries, eq(enquiries.id, followUps.enquiryId))
    .innerJoin(customers, eq(customers.id, enquiries.customerId))
    .where(and(eq(followUps.id, id), eq(followUps.businessId, businessId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function scheduleFollowUp(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const ctx = await requireUser();
  const parsed = followUpSchema.safeParse(formToObject(formData, ["enquiryId", "title", "description", "date", "time", "priority"]));
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  const d = parsed.data;

  const [enq] = await db
    .select({ id: enquiries.id, title: enquiries.title, customerName: customers.fullName })
    .from(enquiries)
    .innerJoin(customers, eq(customers.id, enquiries.customerId))
    .where(and(eq(enquiries.id, d.enquiryId), eq(enquiries.businessId, ctx.business.id)))
    .limit(1);
  if (!enq) return { fieldErrors: { enquiryId: "Select a valid enquiry" } };

  const dueAt = makeZonedDate(d.date, d.time, ctx.prefs.timeZone);
  const [created] = await db
    .insert(followUps)
    .values({
      businessId: ctx.business.id,
      enquiryId: d.enquiryId,
      title: d.title,
      description: d.description || null,
      dueAt,
      priority: d.priority,
      createdById: ctx.user.id,
    })
    .returning({ id: followUps.id });

  await logActivity({
    businessId: ctx.business.id,
    enquiryId: d.enquiryId,
    userId: ctx.user.id,
    type: "follow_up_scheduled",
    description: `Follow-up scheduled: "${d.title}" for ${formatDateTime(dueAt, ctx.prefs)}`,
    metadata: { followUpId: created.id },
  });

  revalidatePath("/", "layout");
  return { ok: true, message: `Follow-up scheduled for ${formatDateTime(dueAt, ctx.prefs)}`, data: { id: created.id } };
}

export async function completeFollowUp(id: string, notes: string): Promise<ActionState> {
  const ctx = await requireUser();
  const owned = await getOwnedFollowUp(ctx.business.id, id);
  if (!owned) return { error: "Follow-up not found." };
  if (owned.followUp.status !== "pending") return { error: "This follow-up is no longer pending." };
  const now = new Date();
  const trimmed = notes.trim().slice(0, 2000);
  await db
    .update(followUps)
    .set({ status: "completed", completedAt: now, completionNotes: trimmed || null, updatedAt: now })
    .where(eq(followUps.id, id));
  await logActivity({
    businessId: ctx.business.id,
    enquiryId: owned.followUp.enquiryId,
    userId: ctx.user.id,
    type: "follow_up_completed",
    description: `Follow-up completed: "${owned.followUp.title}"${trimmed ? ` — ${trimmed}` : ""}`,
    metadata: { followUpId: id },
  });
  await resolveFollowUpNotifications(ctx.user.id, id);
  await createNotification({
    businessId: ctx.business.id,
    userId: ctx.user.id,
    type: "follow_up_completed",
    title: "Follow-up completed",
    message: `"${owned.followUp.title}" for ${owned.customerName} was marked as completed.`,
    link: `/enquiries/${owned.followUp.enquiryId}`,
    dedupeKey: `fu:${id}:completed`,
  });
  revalidatePath("/", "layout");
  return { ok: true, message: "Follow-up marked as completed" };
}

export async function rescheduleFollowUp(id: string, date: string, time: string): Promise<ActionState> {
  const ctx = await requireUser();
  if (!DATE_RE.test(date) || !TIME_RE.test(time)) return { error: "Choose a valid date and time." };
  const owned = await getOwnedFollowUp(ctx.business.id, id);
  if (!owned) return { error: "Follow-up not found." };
  if (owned.followUp.status !== "pending") return { error: "Only pending follow-ups can be rescheduled." };
  const dueAt = makeZonedDate(date, time, ctx.prefs.timeZone);
  await db.update(followUps).set({ dueAt, updatedAt: new Date() }).where(eq(followUps.id, id));
  await logActivity({
    businessId: ctx.business.id,
    enquiryId: owned.followUp.enquiryId,
    userId: ctx.user.id,
    type: "follow_up_rescheduled",
    description: `Follow-up "${owned.followUp.title}" rescheduled to ${formatDateTime(dueAt, ctx.prefs)}`,
    metadata: { followUpId: id, from: owned.followUp.dueAt.toISOString(), to: dueAt.toISOString() },
  });
  await clearFollowUpNotifications(ctx.user.id, id);
  revalidatePath("/", "layout");
  return { ok: true, message: `Rescheduled to ${formatDateTime(dueAt, ctx.prefs)}` };
}

export async function cancelFollowUp(id: string): Promise<ActionState> {
  const ctx = await requireUser();
  const owned = await getOwnedFollowUp(ctx.business.id, id);
  if (!owned) return { error: "Follow-up not found." };
  if (owned.followUp.status !== "pending") return { error: "This follow-up is no longer pending." };
  await db.update(followUps).set({ status: "cancelled", updatedAt: new Date() }).where(eq(followUps.id, id));
  await logActivity({
    businessId: ctx.business.id,
    enquiryId: owned.followUp.enquiryId,
    userId: ctx.user.id,
    type: "follow_up_cancelled",
    description: `Follow-up cancelled: "${owned.followUp.title}"`,
    metadata: { followUpId: id },
  });
  await resolveFollowUpNotifications(ctx.user.id, id);
  revalidatePath("/", "layout");
  return { ok: true, message: "Follow-up cancelled" };
}
