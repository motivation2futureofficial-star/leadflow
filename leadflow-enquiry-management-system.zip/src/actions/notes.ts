"use server";

import { and, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { enquiries, notes } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { logActivity } from "@/lib/events";
import type { ActionState } from "@/lib/types";
import { noteSchema } from "@/lib/validation";

export async function addNote(enquiryId: string, content: string): Promise<ActionState> {
  const ctx = await requireUser();
  const parsed = noteSchema.safeParse(content);
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Invalid note" };
  const [enq] = await db
    .select({ id: enquiries.id })
    .from(enquiries)
    .where(and(eq(enquiries.id, enquiryId), eq(enquiries.businessId, ctx.business.id)))
    .limit(1);
  if (!enq) return { error: "Enquiry not found." };
  await db.insert(notes).values({ businessId: ctx.business.id, enquiryId, authorId: ctx.user.id, content: parsed.data });
  const preview = parsed.data.length > 60 ? `${parsed.data.slice(0, 60)}…` : parsed.data;
  await logActivity({ businessId: ctx.business.id, enquiryId, userId: ctx.user.id, type: "note_added", description: `Note added: "${preview}"` });
  revalidatePath("/", "layout");
  return { ok: true, message: "Note added" };
}

export async function updateNote(noteId: string, content: string): Promise<ActionState> {
  const ctx = await requireUser();
  const parsed = noteSchema.safeParse(content);
  if (!parsed.success) return { error: parsed.error.issues[0]?.message ?? "Invalid note" };
  const [note] = await db
    .select()
    .from(notes)
    .where(and(eq(notes.id, noteId), eq(notes.businessId, ctx.business.id)))
    .limit(1);
  if (!note) return { error: "Note not found." };
  if (note.authorId !== ctx.user.id) return { error: "You can only edit your own notes." };
  await db.update(notes).set({ content: parsed.data, updatedAt: new Date() }).where(eq(notes.id, noteId));
  await logActivity({ businessId: ctx.business.id, enquiryId: note.enquiryId, userId: ctx.user.id, type: "note_updated", description: "Note updated" });
  revalidatePath("/", "layout");
  return { ok: true, message: "Note updated" };
}

export async function deleteNote(noteId: string): Promise<ActionState> {
  const ctx = await requireUser();
  const [note] = await db
    .select()
    .from(notes)
    .where(and(eq(notes.id, noteId), eq(notes.businessId, ctx.business.id)))
    .limit(1);
  if (!note) return { error: "Note not found." };
  if (note.authorId !== ctx.user.id) return { error: "You can only delete your own notes." };
  await db.delete(notes).where(eq(notes.id, noteId));
  await logActivity({ businessId: ctx.business.id, enquiryId: note.enquiryId, userId: ctx.user.id, type: "note_deleted", description: "Note deleted" });
  revalidatePath("/", "layout");
  return { ok: true, message: "Note deleted" };
}
