"use server";

import { and, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import type { ActionState } from "@/lib/types";

export async function markNotificationRead(id: string): Promise<ActionState> {
  const ctx = await requireUser();
  await db
    .update(notifications)
    .set({ isRead: true })
    .where(and(eq(notifications.id, id), eq(notifications.userId, ctx.user.id)));
  revalidatePath("/", "layout");
  return { ok: true };
}

export async function markAllNotificationsRead(): Promise<ActionState> {
  const ctx = await requireUser();
  await db
    .update(notifications)
    .set({ isRead: true })
    .where(and(eq(notifications.userId, ctx.user.id), eq(notifications.isRead, false)));
  revalidatePath("/", "layout");
  return { ok: true, message: "All notifications marked as read" };
}

export async function deleteNotification(id: string): Promise<ActionState> {
  const ctx = await requireUser();
  await db.delete(notifications).where(and(eq(notifications.id, id), eq(notifications.userId, ctx.user.id)));
  revalidatePath("/", "layout");
  return { ok: true };
}

export async function clearReadNotifications(): Promise<ActionState> {
  const ctx = await requireUser();
  await db.delete(notifications).where(and(eq(notifications.userId, ctx.user.id), eq(notifications.isRead, true)));
  revalidatePath("/", "layout");
  return { ok: true, message: "Read notifications cleared" };
}
