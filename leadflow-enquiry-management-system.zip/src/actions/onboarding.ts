"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { businesses } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { seedDemoData } from "@/lib/demo-data";
import { createNotification } from "@/lib/events";
import type { ActionState } from "@/lib/types";
import { fieldErrorsFrom, formToObject, onboardingSchema } from "@/lib/validation";

export async function completeOnboarding(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const ctx = await requireUser({ allowOnboarding: true });
  const parsed = onboardingSchema.safeParse(
    formToObject(formData, ["businessName", "category", "size", "phone", "email", "address", "website"]),
  );
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  const loadDemo = formData.get("loadDemo") === "on";
  const d = parsed.data;

  await db
    .update(businesses)
    .set({
      name: d.businessName,
      category: d.category,
      size: d.size,
      phone: d.phone || null,
      email: d.email || null,
      address: d.address || null,
      website: d.website || null,
      onboardingCompleted: true,
      updatedAt: new Date(),
    })
    .where(eq(businesses.id, ctx.business.id));

  if (loadDemo && !ctx.business.demoSeededAt) {
    try {
      await seedDemoData(ctx.business.id, ctx.user.id, ctx.prefs.timeZone);
    } catch (err) {
      console.error("Failed to seed demo data", err);
    }
  }

  await createNotification({
    businessId: ctx.business.id,
    userId: ctx.user.id,
    type: "account",
    title: "Welcome to LeadFlow 👋",
    message: loadDemo
      ? "Your workspace is ready with sample data. Remove it any time from Settings → Data."
      : "Your workspace is ready. Add your first enquiry to get started.",
    link: "/enquiries",
    dedupeKey: "account:welcome",
  });

  revalidatePath("/", "layout");
  redirect("/dashboard");
}
