"use server";

import { and, eq, ne } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { businesses, sessions, userPreferences, users } from "@/db/schema";
import { hashPassword, requireUser, SESSION_COOKIE, sha256, verifyPassword } from "@/lib/auth";
import { CURRENCIES, DATE_FORMATS } from "@/lib/constants";
import { removeDemoData } from "@/lib/demo-data";
import { safeTz } from "@/lib/format";
import type { ActionState } from "@/lib/types";
import {
  businessSchema,
  fieldErrorsFrom,
  formToObject,
  passwordChangeSchema,
  preferencesSchema,
  profileSchema,
} from "@/lib/validation";

const MAX_IMAGE_BYTES = 1024 * 1024;

async function fileToDataUrl(file: FormDataEntryValue | null): Promise<{ dataUrl?: string | null; error?: string }> {
  if (!(file instanceof File) || file.size === 0) return { dataUrl: undefined };
  if (!file.type.startsWith("image/")) return { error: "Please upload an image file (PNG, JPG, GIF or WebP)." };
  if (file.size > MAX_IMAGE_BYTES) return { error: "Image must be smaller than 1 MB." };
  const buffer = Buffer.from(await file.arrayBuffer());
  return { dataUrl: `data:${file.type};base64,${buffer.toString("base64")}` };
}

export async function updateProfile(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const ctx = await requireUser();
  const parsed = profileSchema.safeParse(formToObject(formData, ["fullName", "email"]));
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  const { fullName, email } = parsed.data;

  if (email !== ctx.user.email) {
    const taken = await db
      .select({ id: users.id })
      .from(users)
      .where(and(eq(users.email, email), ne(users.id, ctx.user.id)))
      .limit(1);
    if (taken.length > 0) return { fieldErrors: { email: "That email is already in use by another account." } };
  }

  const avatar = await fileToDataUrl(formData.get("avatar"));
  if (avatar.error) return { fieldErrors: { avatar: avatar.error } };
  const removeAvatar = formData.get("removeAvatar") === "on";

  await db
    .update(users)
    .set({
      fullName,
      email,
      ...(removeAvatar ? { avatarUrl: null } : avatar.dataUrl !== undefined ? { avatarUrl: avatar.dataUrl } : {}),
      updatedAt: new Date(),
    })
    .where(eq(users.id, ctx.user.id));

  revalidatePath("/", "layout");
  return { ok: true, message: "Profile updated" };
}

export async function changePassword(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const ctx = await requireUser();
  const parsed = passwordChangeSchema.safeParse(formToObject(formData, ["currentPassword", "newPassword", "confirmPassword"]));
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };

  const [user] = await db.select({ passwordHash: users.passwordHash }).from(users).where(eq(users.id, ctx.user.id)).limit(1);
  if (!user || !(await verifyPassword(parsed.data.currentPassword, user.passwordHash))) {
    return { fieldErrors: { currentPassword: "Your current password is incorrect." } };
  }

  const passwordHash = await hashPassword(parsed.data.newPassword);
  await db.update(users).set({ passwordHash, updatedAt: new Date() }).where(eq(users.id, ctx.user.id));

  // Sign out every other device but keep this session alive.
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(and(eq(sessions.userId, ctx.user.id), ne(sessions.id, sha256(token))));
  }
  return { ok: true, message: "Password changed. Other devices have been signed out." };
}

export async function updateBusiness(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const ctx = await requireUser();
  const parsed = businessSchema.safeParse(formToObject(formData, ["name", "category", "size", "phone", "email", "address", "website"]));
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  const d = parsed.data;

  const logo = await fileToDataUrl(formData.get("logo"));
  if (logo.error) return { fieldErrors: { logo: logo.error } };
  const removeLogo = formData.get("removeLogo") === "on";

  await db
    .update(businesses)
    .set({
      name: d.name,
      category: d.category || null,
      size: d.size || null,
      phone: d.phone || null,
      email: d.email || null,
      address: d.address || null,
      website: d.website || null,
      ...(removeLogo ? { logoUrl: null } : logo.dataUrl !== undefined ? { logoUrl: logo.dataUrl } : {}),
      updatedAt: new Date(),
    })
    .where(eq(businesses.id, ctx.business.id));

  revalidatePath("/", "layout");
  return { ok: true, message: "Business settings saved" };
}

export async function updatePreferences(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const ctx = await requireUser();
  const parsed = preferencesSchema.safeParse(formToObject(formData, ["dateFormat", "timeZone", "currency", "defaultDateRange", "reminderLeadHours"]));
  if (!parsed.success) return { fieldErrors: fieldErrorsFrom(parsed.error) };
  const d = parsed.data;
  if (!DATE_FORMATS.includes(d.dateFormat)) return { fieldErrors: { dateFormat: "Select a valid date format" } };
  if (!CURRENCIES.includes(d.currency)) return { fieldErrors: { currency: "Select a valid currency" } };
  const tz = safeTz(d.timeZone);
  if (tz !== d.timeZone) return { fieldErrors: { timeZone: "Select a valid time zone" } };

  const flag = (key: string) => formData.get(key) === "on";
  const values = {
    dateFormat: d.dateFormat,
    timeZone: tz,
    currency: d.currency,
    defaultDateRange: d.defaultDateRange,
    reminderLeadHours: d.reminderLeadHours,
    notifyNewEnquiry: flag("notifyNewEnquiry"),
    notifyUpcoming: flag("notifyUpcoming"),
    notifyDueToday: flag("notifyDueToday"),
    notifyOverdue: flag("notifyOverdue"),
    notifyConversions: flag("notifyConversions"),
    updatedAt: new Date(),
  };
  await db
    .insert(userPreferences)
    .values({ userId: ctx.user.id, ...values })
    .onConflictDoUpdate({ target: userPreferences.userId, set: values });

  revalidatePath("/", "layout");
  return { ok: true, message: "Preferences saved" };
}

export async function removeDemoDataAction(): Promise<ActionState> {
  const ctx = await requireUser();
  try {
    await removeDemoData(ctx.business.id);
  } catch (err) {
    console.error("removeDemoData failed", err);
    return { error: "Could not remove the sample data. Please try again." };
  }
  revalidatePath("/", "layout");
  return { ok: true, message: "Sample data removed. Only your real records remain." };
}

export async function deleteAccount(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const ctx = await requireUser();
  const confirm = String(formData.get("confirm") ?? "");
  const password = String(formData.get("password") ?? "");
  if (confirm !== "DELETE") return { fieldErrors: { confirm: 'Type "DELETE" to confirm.' } };
  const [user] = await db.select({ passwordHash: users.passwordHash }).from(users).where(eq(users.id, ctx.user.id)).limit(1);
  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    return { fieldErrors: { password: "Incorrect password." } };
  }
  await db.delete(users).where(eq(users.id, ctx.user.id));
  const store = await cookies();
  store.delete(SESSION_COOKIE);
  redirect("/?deleted=1");
}
