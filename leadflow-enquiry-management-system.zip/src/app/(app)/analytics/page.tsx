import { Activity, CheckCircle2, Inbox, Sparkles, XCircle } from "lucide-react";
import { ConversionTrendChart, DistributionChart, HorizontalBarChart, MonthlyPerformanceChart } from "@/components/charts";
import { DateRangeFilter } from "@/components/date-range-filter";
import { Card, CardHeader, PageHeader, StatCard } from "@/components/ui";
import { getAnalyticsData, resolveRange } from "@/lib/analytics";
import { requireUser } from "@/lib/auth";
import { PRIORITIES } from "@/lib/constants";
import { formatCurrency, formatPercent } from "@/lib/format";

export const metadata = { title: "Analytics" };

export default async function AnalyticsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requireUser();
  const sp = await searchParams;
  const tz = ctx.prefs.timeZone;
  const range = resolveRange(sp, tz, ctx.prefs.defaultDateRange);
  const data = await getAnalyticsData(ctx.business.id, range, tz);
  const { stats } = data;
  const currency = ctx.prefs.currency;
  const responseRate = data.contactedTotal > 0 ? (data.contactedWithin24h / data.contactedTotal) * 100 : null;

  return (
    <>
      <PageHeader title="Analytics & insights" description={`Performance calculated live from your enquiries · ${range.label}`} actions={<DateRangeFilter current={{ key: range.key, from: range.from, to: range.to }} />} />

      <section>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Enquiry performance</h2>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          <StatCard label="Total enquiries" value={stats.total} icon={Inbox} tone="info" hint={range.label} />
          <StatCard label="New" value={stats.byStatus.new} icon={Sparkles} tone="info" hint="Not yet contacted" />
          <StatCard label="Active" value={stats.active} icon={Activity} tone="warning" hint="New, contacted, interested or follow-up required" />
          <StatCard label="Converted" value={stats.byStatus.converted} icon={CheckCircle2} tone="success" hint={`Won ${formatCurrency(stats.wonValue, currency)}`} />
          <StatCard label="Lost" value={stats.byStatus.lost} icon={XCircle} tone="danger" hint={stats.total > 0 ? `${formatPercent((stats.byStatus.lost / stats.total) * 100, 0)} of enquiries` : "—"} />
        </div>
      </section>

      <section className="mt-8">
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Conversion analytics</h2>
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <div className="grid gap-px bg-slate-100 sm:grid-cols-3">
              <div className="bg-white p-5">
                <p className="text-sm font-medium text-slate-500">Conversion rate</p>
                <p className="mt-1 text-3xl font-semibold text-emerald-600">{formatPercent(stats.conversionRate)}</p>
                <p className="mt-1 text-xs text-slate-500">
                  {stats.byStatus.converted} converted ÷ {stats.total} eligible
                </p>
              </div>
              <div className="bg-white p-5">
                <p className="text-sm font-medium text-slate-500">Win rate (closed only)</p>
                <p className="mt-1 text-3xl font-semibold text-slate-900">{formatPercent(stats.winRate)}</p>
                <p className="mt-1 text-xs text-slate-500">
                  {stats.byStatus.converted} won ÷ {stats.byStatus.converted + stats.byStatus.lost} closed
                </p>
              </div>
              <div className="bg-white p-5">
                <p className="text-sm font-medium text-slate-500">Avg. deal value (won)</p>
                <p className="mt-1 text-3xl font-semibold text-slate-900">{formatCurrency(data.avgDealValue, currency)}</p>
                <p className="mt-1 text-xs text-slate-500">Across converted enquiries with a value</p>
              </div>
              <div className="bg-white p-5">
                <p className="text-sm font-medium text-slate-500">Avg. days to convert</p>
                <p className="mt-1 text-3xl font-semibold text-slate-900">{data.avgDaysToConvert === null ? "—" : data.avgDaysToConvert.toFixed(1)}</p>
                <p className="mt-1 text-xs text-slate-500">From enquiry date to conversion</p>
              </div>
              <div className="bg-white p-5">
                <p className="text-sm font-medium text-slate-500">Open pipeline value</p>
                <p className="mt-1 text-3xl font-semibold text-slate-900">{formatCurrency(stats.pipelineValue, currency)}</p>
                <p className="mt-1 text-xs text-slate-500">Estimated value of active enquiries</p>
              </div>
              <div className="bg-white p-5">
                <p className="text-sm font-medium text-slate-500">Contacted within 24h</p>
                <p className="mt-1 text-3xl font-semibold text-slate-900">{responseRate === null ? "—" : formatPercent(responseRate, 0)}</p>
                <p className="mt-1 text-xs text-slate-500">
                  {data.contactedWithin24h} of {data.contactedTotal} contacted enquiries
                </p>
              </div>
            </div>
          </Card>
          <Card className="bg-brand-50/60">
            <div className="p-5 text-sm text-slate-700">
              <p className="font-semibold text-slate-900">How conversion rate is calculated</p>
              <p className="mt-2 font-mono text-xs text-brand-800">Conversion Rate = Converted ÷ Eligible × 100</p>
              <ul className="mt-3 list-disc space-y-1.5 pl-4 text-xs leading-5">
                <li>
                  <span className="font-medium">Eligible enquiries</span> are every enquiry whose enquiry date falls inside the selected period — including enquiries that are still open.
                </li>
                <li>
                  <span className="font-medium">Converted</span> counts enquiries currently in the Converted status.
                </li>
                <li>
                  <span className="font-medium">Win rate</span> ignores open enquiries and only compares converted against lost, so it shows how often a decided deal goes your way.
                </li>
                <li>Monthly rates compare conversions in a month to enquiries received that month.</li>
              </ul>
            </div>
          </Card>
        </div>
      </section>

      <section className="mt-8">
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Source analytics</h2>
        <div className="grid gap-4 lg:grid-cols-5">
          <Card className="lg:col-span-2">
            <CardHeader title="Enquiries by source" description="Which platforms generate the most enquiries" />
            <div className="p-5">
              <HorizontalBarChart data={data.sources.map((s) => ({ name: s.name, value: s.total }))} height={Math.max(200, data.sources.length * 36)} />
            </div>
          </Card>
          <Card className="lg:col-span-3 overflow-hidden">
            <CardHeader title="Source performance" description="Volume, share and conversion by channel" />
            {data.sources.length === 0 ? (
              <p className="px-5 py-8 text-center text-sm text-slate-500">No enquiries in this period.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-slate-200 text-sm">
                  <thead className="bg-slate-50">
                    <tr>
                      {["Source", "Enquiries", "Share", "Converted", "Conv. rate", "Won value"].map((h) => (
                        <th key={h} className="whitespace-nowrap px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {data.sources.map((s) => (
                      <tr key={s.name}>
                        <td className="px-4 py-2.5">
                          <span className="flex items-center gap-2 font-medium text-slate-900">
                            <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: s.color }} /> {s.name}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-slate-700">{s.total}</td>
                        <td className="px-4 py-2.5 text-slate-700">
                          <span className="flex items-center gap-2">
                            <span className="h-1.5 w-16 overflow-hidden rounded-full bg-slate-100">
                              <span className="block h-full rounded-full bg-brand-500" style={{ width: `${Math.min(100, s.share)}%` }} />
                            </span>
                            {formatPercent(s.share, 0)}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-slate-700">{s.converted}</td>
                        <td className="px-4 py-2.5 font-medium text-emerald-700">{formatPercent(s.rate, 0)}</td>
                        <td className="px-4 py-2.5 text-slate-700">{formatCurrency(s.value, currency)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </section>

      <section className="mt-8">
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Monthly performance · last 12 months</h2>
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader title="Enquiries received, converted & lost" description="Grouped by month (independent of the date filter)" />
            <div className="p-5">
              <MonthlyPerformanceChart data={data.monthly} height={280} />
            </div>
          </Card>
          <Card>
            <CardHeader title="Conversion trend" description="Converted ÷ received, per month" />
            <div className="p-5">
              <ConversionTrendChart data={data.monthly} height={280} />
            </div>
          </Card>
        </div>
        <Card className="mt-4 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200 text-sm">
              <thead className="bg-slate-50">
                <tr>
                  {["Month", "Received", "Converted", "Lost", "Conversion rate"].map((h) => (
                    <th key={h} className="whitespace-nowrap px-4 py-2.5 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {[...data.monthly].reverse().map((m) => (
                  <tr key={m.month}>
                    <td className="px-4 py-2.5 font-medium text-slate-900">{m.label}</td>
                    <td className="px-4 py-2.5 text-slate-700">{m.received}</td>
                    <td className="px-4 py-2.5 text-emerald-700">{m.converted}</td>
                    <td className="px-4 py-2.5 text-red-600">{m.lost}</td>
                    <td className="px-4 py-2.5 text-slate-700">{formatPercent(m.rate)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </section>

      <section className="mt-8">
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-500">Pipeline mix</h2>
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader title="Status distribution" />
            <div className="p-5">
              <DistributionChart
                data={[
                  { name: "New", value: stats.byStatus.new, color: "#3b82f6" },
                  { name: "Contacted", value: stats.byStatus.contacted, color: "#0ea5e9" },
                  { name: "Interested", value: stats.byStatus.interested, color: "#8b5cf6" },
                  { name: "Follow-up Required", value: stats.byStatus.follow_up_required, color: "#f59e0b" },
                  { name: "Converted", value: stats.byStatus.converted, color: "#10b981" },
                  { name: "Lost", value: stats.byStatus.lost, color: "#ef4444" },
                ]}
                height={180}
              />
            </div>
          </Card>
          <Card>
            <CardHeader title="Priority distribution" />
            <div className="p-5">
              <DistributionChart data={PRIORITIES.map((p) => ({ name: p.label, value: data.priorities.find((x) => x.priority === p.value)?.n ?? 0, color: p.hex }))} height={180} />
            </div>
          </Card>
        </div>
      </section>
    </>
  );
}
