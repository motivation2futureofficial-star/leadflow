import Link from "next/link";
import { notFound } from "next/navigation";
import { Building2, CheckCircle2, Inbox, Mail, MessageCircle, Phone, Plus, Wallet } from "lucide-react";
import { ActivityTimeline } from "@/components/activity";
import { Avatar, Card, CardHeader, DemoTag, LinkButton, PageHeader, PriorityBadge, StatCard, StatusBadge, cn } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { ACTIVE_STATUSES, ACTIVITY_LABELS } from "@/lib/constants";
import { describeDue, formatCurrency, formatDate, formatDateTime, relativeTime } from "@/lib/format";
import { getCustomerDetail } from "@/lib/queries";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function CustomerDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const ctx = await requireUser();
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();
  const detail = await getCustomerDetail(ctx.business.id, id);
  if (!detail) notFound();
  const { customer, enquiries, activities } = detail;
  const prefs = ctx.prefs;
  const now = new Date();
  const active = enquiries.filter((e) => (ACTIVE_STATUSES as string[]).includes(e.status)).length;
  const converted = enquiries.filter((e) => e.status === "converted").length;
  const totalValue = enquiries.reduce((a, e) => a + Number(e.estimatedValue ?? 0), 0);
  const whatsappDigits = customer.phone?.replace(/\D/g, "");
  const newHref = `/enquiries/new?${new URLSearchParams({ name: customer.fullName, phone: customer.phone ?? "", email: customer.email ?? "", company: customer.company ?? "" }).toString()}`;

  return (
    <>
      <PageHeader
        backHref="/customers"
        backLabel="Customers"
        eyebrow={customer.isDemo ? <DemoTag /> : undefined}
        title={customer.fullName}
        description={customer.company ? `${customer.company} · customer since ${formatDate(customer.createdAt, prefs)}` : `Customer since ${formatDate(customer.createdAt, prefs)}`}
        actions={
          <LinkButton href={newHref}>
            <Plus className="h-4 w-4" /> New enquiry for this customer
          </LinkButton>
        }
      />

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total enquiries" value={enquiries.length} icon={Inbox} tone="info" />
        <StatCard label="Open enquiries" value={active} icon={Inbox} tone="warning" />
        <StatCard label="Converted" value={converted} icon={CheckCircle2} tone="success" />
        <StatCard label="Total estimated value" value={formatCurrency(totalValue, prefs.currency)} icon={Wallet} tone="violet" />
      </section>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <Card>
            <CardHeader title="Enquiries" description="All enquiries from this customer, newest first." />
            {enquiries.length === 0 ? (
              <p className="px-5 py-8 text-center text-sm text-slate-500">No enquiries recorded.</p>
            ) : (
              <ul className="divide-y divide-slate-100">
                {enquiries.map((e) => {
                  const due = e.nextFollowUpAt ? describeDue(e.nextFollowUpAt, prefs, now) : null;
                  return (
                    <li key={e.id} className="px-5 py-4 hover:bg-slate-50/70">
                      <Link href={`/enquiries/${e.id}`} className="block">
                        <div className="flex flex-wrap items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="flex items-center gap-2 font-medium text-slate-900">
                              <span className="truncate">{e.title}</span>
                              {e.isDemo && <DemoTag />}
                            </p>
                            <p className="mt-0.5 text-xs text-slate-500">
                              {e.source} · {formatDate(e.enquiryDate, prefs)}
                              {e.productService ? ` · ${e.productService}` : ""}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <StatusBadge status={e.status} />
                            <PriorityBadge priority={e.priority} />
                          </div>
                        </div>
                        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                          {e.estimatedValue && <span className="font-medium text-slate-800">{formatCurrency(e.estimatedValue, prefs.currency)}</span>}
                          {due && <span className={cn("font-medium", due.tone === "danger" ? "text-red-600" : due.tone === "warning" ? "text-amber-600" : "text-slate-600")}>Next follow-up: {due.label}</span>}
                          {e.status === "lost" && e.lostReason && <span>Lost: {e.lostReason}</span>}
                        </div>
                      </Link>
                    </li>
                  );
                })}
              </ul>
            )}
          </Card>

          <Card>
            <CardHeader title="Interaction history" description="Combined timeline across all of this customer's enquiries." />
            <ActivityTimeline
              items={activities.map((a) => ({
                id: a.log.id,
                type: a.log.type,
                description: a.log.description,
                context: a.enquiryTitle,
                href: a.log.enquiryId ? `/enquiries/${a.log.enquiryId}` : null,
                meta: `${ACTIVITY_LABELS[a.log.type] ?? "Activity"}${a.userName ? ` · ${a.userName}` : ""} · ${formatDateTime(a.log.createdAt, prefs)}`,
                timeAgo: relativeTime(a.log.createdAt, now),
              }))}
            />
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader title="Contact details" />
            <div className="p-5">
              <div className="flex items-center gap-3">
                <Avatar name={customer.fullName} size="lg" />
                <div className="min-w-0">
                  <p className="truncate font-semibold text-slate-900">{customer.fullName}</p>
                  {customer.company && (
                    <p className="flex items-center gap-1 truncate text-sm text-slate-500">
                      <Building2 className="h-3.5 w-3.5" /> {customer.company}
                    </p>
                  )}
                </div>
              </div>
              <ul className="mt-4 space-y-2 text-sm">
                <li className="flex items-center gap-2 text-slate-700">
                  <Phone className="h-4 w-4 text-slate-400" />
                  {customer.phone ? (
                    <a href={`tel:${customer.phone}`} className="hover:text-brand-700">
                      {customer.phone}
                    </a>
                  ) : (
                    <span className="text-slate-400">No phone</span>
                  )}
                </li>
                <li className="flex items-center gap-2 text-slate-700">
                  <Mail className="h-4 w-4 text-slate-400" />
                  {customer.email ? (
                    <a href={`mailto:${customer.email}`} className="truncate hover:text-brand-700">
                      {customer.email}
                    </a>
                  ) : (
                    <span className="text-slate-400">No email</span>
                  )}
                </li>
              </ul>
              {whatsappDigits && whatsappDigits.length >= 6 && (
                <a href={`https://wa.me/${whatsappDigits}`} target="_blank" rel="noreferrer" className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-700 hover:bg-emerald-100">
                  <MessageCircle className="h-4 w-4" /> Message on WhatsApp
                </a>
              )}
              <p className="mt-4 text-xs text-slate-500">Contact details are edited from any of the customer&apos;s enquiries.</p>
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}
