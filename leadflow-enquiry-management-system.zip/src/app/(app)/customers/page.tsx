import Link from "next/link";
import { ChevronRight, Download, Search, Users } from "lucide-react";
import { Avatar, Card, DemoTag, EmptyState, Input, LinkButton, PageHeader, StatusBadge, buttonClass } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { firstParam, formatCurrency, relativeTime } from "@/lib/format";
import { listCustomers } from "@/lib/queries";

export const metadata = { title: "Customers" };

export default async function CustomersPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requireUser();
  const sp = await searchParams;
  const q = firstParam(sp.q)?.trim() || undefined;
  const rows = await listCustomers(ctx.business.id, q);
  const now = new Date();

  return (
    <>
      <PageHeader
        title="Customers"
        description="Everyone who has enquired with you, with their complete enquiry history and value."
        actions={
          <Link href="/api/export/customers" prefetch={false} className={buttonClass("secondary")}>
            <Download className="h-4 w-4" /> Export CSV
          </Link>
        }
      />

      <Card className="p-3">
        <form method="get" className="flex gap-2">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input type="search" name="q" defaultValue={q ?? ""} placeholder="Search customers by name, phone, email or company…" className="pl-9" aria-label="Search customers" />
          </div>
          <button type="submit" className={buttonClass("secondary")}>
            Search
          </button>
          {q && (
            <Link href="/customers" className={buttonClass("ghost")}>
              Clear
            </Link>
          )}
        </form>
      </Card>

      <Card className="mt-4 overflow-hidden">
        {rows.length === 0 ? (
          <EmptyState
            icon={Users}
            title={q ? "No customers match your search" : "No customers yet"}
            description={q ? "Try a different name, phone number or email." : "Customers are created automatically when you add an enquiry."}
            action={
              q ? (
                <LinkButton href="/customers" variant="secondary">
                  Clear search
                </LinkButton>
              ) : (
                <LinkButton href="/enquiries/new">Add an enquiry</LinkButton>
              )
            }
          />
        ) : (
          <>
            <div className="hidden overflow-x-auto md:block">
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    {["Customer", "Contact", "Enquiries", "Latest status", "Est. value", "Last enquiry", ""].map((h) => (
                      <th key={h} scope="col" className="whitespace-nowrap px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {rows.map((r) => (
                    <tr key={r.customer.id} className="hover:bg-slate-50/70">
                      <td className="px-4 py-3">
                        <Link href={`/customers/${r.customer.id}`} className="flex items-center gap-3">
                          <Avatar name={r.customer.fullName} size="sm" />
                          <span className="min-w-0">
                            <span className="flex items-center gap-2">
                              <span className="truncate font-medium text-slate-900 hover:text-brand-700">{r.customer.fullName}</span>
                              {r.customer.isDemo && <DemoTag />}
                            </span>
                            {r.customer.company && <span className="block truncate text-xs text-slate-500">{r.customer.company}</span>}
                          </span>
                        </Link>
                      </td>
                      <td className="px-4 py-3 text-slate-700">
                        <span className="block">{r.customer.phone ?? "—"}</span>
                        <span className="block truncate text-xs text-slate-500">{r.customer.email ?? ""}</span>
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 text-slate-700">
                        <span className="font-medium text-slate-900">{r.enquiryCount}</span>
                        <span className="ml-1 text-xs text-slate-500">
                          ({r.activeCount} open · {r.convertedCount} won)
                        </span>
                      </td>
                      <td className="whitespace-nowrap px-4 py-3">{r.latestStatus ? <StatusBadge status={r.latestStatus} /> : "—"}</td>
                      <td className="whitespace-nowrap px-4 py-3 text-slate-700">{formatCurrency(r.totalValue, ctx.prefs.currency)}</td>
                      <td className="whitespace-nowrap px-4 py-3 text-slate-500">{r.lastEnquiryAt ? relativeTime(r.lastEnquiryAt, now) : "—"}</td>
                      <td className="px-4 py-3 text-right">
                        <Link href={`/customers/${r.customer.id}`} className={buttonClass("ghost", "icon-sm")} aria-label="View customer">
                          <ChevronRight className="h-4 w-4" />
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <ul className="divide-y divide-slate-100 md:hidden">
              {rows.map((r) => (
                <li key={r.customer.id}>
                  <Link href={`/customers/${r.customer.id}`} className="flex items-center gap-3 p-4">
                    <Avatar name={r.customer.fullName} />
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-2">
                        <span className="truncate font-medium text-slate-900">{r.customer.fullName}</span>
                        {r.customer.isDemo && <DemoTag />}
                      </p>
                      <p className="truncate text-xs text-slate-500">{[r.customer.phone, r.customer.email].filter(Boolean).join(" · ")}</p>
                      <p className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                        <span>
                          {r.enquiryCount} enquir{r.enquiryCount === 1 ? "y" : "ies"}
                        </span>
                        {r.latestStatus && <StatusBadge status={r.latestStatus} />}
                        <span>{formatCurrency(r.totalValue, ctx.prefs.currency)}</span>
                      </p>
                    </div>
                    <ChevronRight className="h-4 w-4 shrink-0 text-slate-400" />
                  </Link>
                </li>
              ))}
            </ul>
            <div className="border-t border-slate-200 px-4 py-3 text-sm text-slate-600">
              {rows.length} customer{rows.length === 1 ? "" : "s"}
              {q ? ` matching “${q}”` : ""}
            </div>
          </>
        )}
      </Card>
    </>
  );
}
