import Link from "next/link";
import {
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  Inbox,
  List,
  Percent,
  PhoneCall,
  Plus,
  Sparkles,
  Star,
  XCircle,
} from "lucide-react";
import { removeDemoDataAction } from "@/actions/settings";
import { ActivityTimeline } from "@/components/activity";
import { DistributionChart, EnquiriesOverTimeChart, MonthlyPerformanceChart } from "@/components/charts";
import { DateRangeFilter } from "@/components/date-range-filter";
import { ConfirmButton } from "@/components/modal";
import { Badge, Card, CardHeader, LinkButton, PageHeader, PriorityBadge, StatCard, buttonClass, cn } from "@/components/ui";
import { getDashboardCharts, getDashboardStats, getRecentActivity, resolveRange } from "@/lib/analytics";
import { requireUser } from "@/lib/auth";
import { ACTIVITY_LABELS } from "@/lib/constants";
import { describeDue, formatCurrency, formatDateTime, formatPercent, relativeTime, todayInTz } from "@/lib/format";
import { getDemoCounts, getFollowUpBuckets } from "@/lib/queries";

export const metadata = { title: "Dashboard" };

function greeting(tz: string) {
  const hour = Number(new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", hourCycle: "h23" }).format(new Date()));
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

function pctChange(current: number, previous: number) {
  if (previous === 0) return current === 0 ? 0 : 100;
  return ((current - previous) / previous) * 100;
}

export default async function DashboardPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requireUser();
  const sp = await searchParams;
  const tz = ctx.prefs.timeZone;
  const range = resolveRange(sp, tz, ctx.prefs.defaultDateRange);
  const businessId = ctx.business.id;

  const [stats, charts, activity, buckets, demo] = await Promise.all([
    getDashboardStats(businessId, range, tz),
    getDashboardCharts(businessId, range, tz),
    getRecentActivity(businessId, 8),
    getFollowUpBuckets(businessId, tz),
    getDemoCounts(businessId),
  ]);
  const now = new Date();
  const attention = [...buckets.overdue, ...buckets.dueToday].slice(0, 6);
  const firstName = ctx.user.fullName.split(" ")[0];
  const today = todayInTz(tz);

  return (
    <>
      <PageHeader
        title={`${greeting(tz)}, ${firstName}`}
        description={
          stats.followUpsDue > 0 ? (
            <>
              You have <span className="font-semibold text-slate-900">{stats.followUpsDue}</span> follow-up{stats.followUpsDue === 1 ? "" : "s"} due
              {stats.overdue > 0 && (
                <>
                  {" "}
                  (<span className="font-semibold text-red-600">{stats.overdue} overdue</span>)
                </>
              )}
              . Showing {range.label.toLowerCase()}.
            </>
          ) : (
            <>No follow-ups are due today. Showing {range.label.toLowerCase()}.</>
          )
        }
        actions={<DateRangeFilter current={{ key: range.key, from: range.from, to: range.to }} />}
      />

      {demo.enquiries > 0 && (
        <div className="mb-6 flex flex-col gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <Sparkles className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" />
            <div>
              <p className="text-sm font-semibold text-amber-900">You&apos;re exploring with sample data</p>
              <p className="text-xs text-amber-800/80">
                {demo.enquiries} sample enquiries and {demo.customers} sample customers are labelled “Sample”. Remove them whenever you&apos;re ready — your real records won&apos;t be touched.
              </p>
            </div>
          </div>
          <ConfirmButton
            action={removeDemoDataAction}
            title="Remove sample data?"
            description="All sample enquiries, customers, follow-ups, notes, activity and notifications will be permanently deleted. Records you created yourself are kept."
            confirmLabel="Remove sample data"
            variant="secondary"
            size="sm"
            className="shrink-0"
          >
            Remove sample data
          </ConfirmButton>
        </div>
      )}

      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Total Enquiries"
          value={stats.total}
          icon={Inbox}
          tone="info"
          href={`/enquiries?from=${range.from}&to=${range.to}`}
          trend={stats.hasPrev ? { value: pctChange(stats.total, stats.prevTotal), label: "vs previous period" } : null}
          hint={`${range.label}`}
        />
        <StatCard label="New Enquiries" value={stats.byStatus.new} icon={Sparkles} tone="info" href={`/enquiries?status=new&from=${range.from}&to=${range.to}`} hint="Awaiting first contact" />
        <StatCard label="Contacted" value={stats.byStatus.contacted} icon={PhoneCall} tone="sky" href={`/enquiries?status=contacted&from=${range.from}&to=${range.to}`} hint="First contact made" />
        <StatCard label="Interested Leads" value={stats.byStatus.interested} icon={Star} tone="violet" href={`/enquiries?status=interested&from=${range.from}&to=${range.to}`} hint={`Pipeline ${formatCurrency(stats.pipelineValue, ctx.prefs.currency)}`} />
        <StatCard
          label="Follow-ups Due"
          value={stats.followUpsDue}
          icon={CalendarClock}
          tone={stats.overdue > 0 ? "danger" : stats.followUpsDue > 0 ? "warning" : "default"}
          href="/follow-ups"
          hint={stats.overdue > 0 ? `${stats.overdue} overdue · ${stats.dueToday} today` : stats.followUpsDue > 0 ? `${stats.dueToday} due today` : "Nothing due today"}
        />
        <StatCard
          label="Converted Customers"
          value={stats.byStatus.converted}
          icon={CheckCircle2}
          tone="success"
          href={`/enquiries?status=converted&from=${range.from}&to=${range.to}`}
          trend={stats.hasPrev ? { value: pctChange(stats.byStatus.converted, stats.prevConverted), label: "vs previous period" } : null}
          hint={`Won ${formatCurrency(stats.wonValue, ctx.prefs.currency)}`}
        />
        <StatCard label="Lost Enquiries" value={stats.byStatus.lost} icon={XCircle} tone="danger" href={`/enquiries?status=lost&from=${range.from}&to=${range.to}`} hint={stats.total > 0 ? `${formatPercent((stats.byStatus.lost / stats.total) * 100, 0)} of enquiries` : "No enquiries yet"} />
        <StatCard label="Conversion Rate" value={formatPercent(stats.conversionRate)} icon={Percent} tone="success" href="/analytics" hint={`${stats.byStatus.converted} converted ÷ ${stats.total} enquiries`} />
      </section>

      <section className="mt-6 flex flex-wrap gap-2">
        <Link href="/enquiries/new" className={buttonClass("primary", "md")}>
          <Plus className="h-4 w-4" /> Add New Enquiry
        </Link>
        <Link href="/enquiries" className={buttonClass("secondary", "md")}>
          <List className="h-4 w-4" /> View All Enquiries
        </Link>
        <Link href="/follow-ups?schedule=1" className={buttonClass("secondary", "md")}>
          <CalendarClock className="h-4 w-4" /> Schedule Follow-up
        </Link>
        <Link href="/follow-ups#overdue" className={buttonClass(stats.overdue > 0 ? "outline-danger" : "secondary", "md")}>
          <AlertTriangle className="h-4 w-4" /> View Overdue Follow-ups
          {stats.overdue > 0 && <span className="ml-1 rounded-full bg-red-600 px-1.5 text-[11px] font-semibold text-white">{stats.overdue}</span>}
        </Link>
      </section>

      <section className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Enquiries received over time" description={`${charts.weekly ? "Weekly" : "Daily"} enquiries · ${range.label}`} />
          <div className="p-5">
            <EnquiriesOverTimeChart data={charts.overTime} />
          </div>
        </Card>
        <Card>
          <CardHeader title="Status distribution" description="Where enquiries sit in the pipeline" />
          <div className="p-5">
            <DistributionChart data={charts.byStatus} height={180} emptyMessage="No enquiries in this period" />
          </div>
        </Card>
      </section>

      <section className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader
            title="Monthly performance"
            description="Enquiries received, converted and lost · last 6 months"
            action={
              charts.growth !== null && (
                <Badge className={cn(charts.growth >= 0 ? "bg-emerald-50 text-emerald-700 ring-emerald-600/20" : "bg-red-50 text-red-700 ring-red-600/20")}>
                  {charts.growth >= 0 ? "▲" : "▼"} {Math.abs(charts.growth).toFixed(0)}% growth this month
                </Badge>
              )
            }
          />
          <div className="p-5">
            <MonthlyPerformanceChart data={charts.monthly} />
          </div>
        </Card>
        <Card>
          <CardHeader title="Enquiry sources" description="Which channels bring enquiries" />
          <div className="p-5">
            <DistributionChart data={charts.bySource.slice(0, 8)} height={180} emptyMessage="No enquiries in this period" />
          </div>
        </Card>
      </section>

      <section className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader title="Recent activity" description="Latest updates across your enquiries" action={<Link href="/enquiries" className="text-sm font-medium text-brand-600 hover:text-brand-700">View enquiries</Link>} />
          <ActivityTimeline
            emptyText="Activity will appear here as you add enquiries, change statuses and complete follow-ups."
            items={activity.map((a) => ({
              id: a.log.id,
              type: a.log.type,
              description: a.log.description,
              context: a.customerName ?? null,
              href: a.log.enquiryId ? `/enquiries/${a.log.enquiryId}` : null,
              meta: `${ACTIVITY_LABELS[a.log.type] ?? "Activity"}${a.userName ? ` · ${a.userName}` : ""} · ${formatDateTime(a.log.createdAt, ctx.prefs)}`,
              timeAgo: relativeTime(a.log.createdAt, now),
            }))}
          />
        </Card>
        <Card>
          <CardHeader title="Needs attention" description="Overdue and due-today follow-ups" action={<Link href="/follow-ups" className="text-sm font-medium text-brand-600 hover:text-brand-700">All follow-ups</Link>} />
          {attention.length === 0 ? (
            <div className="px-5 py-10 text-center">
              <CheckCircle2 className="mx-auto h-8 w-8 text-emerald-500" />
              <p className="mt-2 text-sm font-medium text-slate-900">You&apos;re all caught up</p>
              <p className="text-xs text-slate-500">No follow-ups are overdue or due today ({today}).</p>
            </div>
          ) : (
            <ul className="divide-y divide-slate-100">
              {attention.map((f) => {
                const due = describeDue(f.followUp.dueAt, ctx.prefs, now);
                return (
                  <li key={f.followUp.id} className="px-5 py-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <Link href={`/enquiries/${f.followUp.enquiryId}`} className="block truncate text-sm font-medium text-slate-900 hover:text-brand-700">
                          {f.customerName}
                        </Link>
                        <p className="truncate text-xs text-slate-500">{f.followUp.title}</p>
                      </div>
                      <PriorityBadge priority={f.followUp.priority} />
                    </div>
                    <p className={cn("mt-1 text-xs font-medium", due.tone === "danger" ? "text-red-600" : due.tone === "warning" ? "text-amber-600" : "text-slate-500")}>{due.label}</p>
                  </li>
                );
              })}
            </ul>
          )}
          {(buckets.overdue.length + buckets.dueToday.length) > attention.length && (
            <div className="border-t border-slate-100 px-5 py-3 text-center">
              <LinkButton href="/follow-ups" variant="ghost" size="sm">
                View {buckets.overdue.length + buckets.dueToday.length - attention.length} more
              </LinkButton>
            </div>
          )}
        </Card>
      </section>
    </>
  );
}
