import { notFound } from "next/navigation";
import { updateEnquiry } from "@/actions/enquiries";
import { EnquiryForm } from "@/components/enquiry-form";
import { PageHeader } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { getAssigneeOptions, getEnquiryDetail, getSourceOptions } from "@/lib/queries";

export const metadata = { title: "Edit enquiry" };

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function EditEnquiryPage({ params }: { params: Promise<{ id: string }> }) {
  const ctx = await requireUser();
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();
  const [detail, sources, assignees] = await Promise.all([
    getEnquiryDetail(ctx.business.id, id),
    getSourceOptions(ctx.business.id),
    getAssigneeOptions(ctx.business.id),
  ]);
  if (!detail) notFound();
  const { enquiry, customer } = detail;
  const action = updateEnquiry.bind(null, id);

  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader backHref={`/enquiries/${id}`} backLabel={customer.fullName} title="Edit enquiry" description="Changes are recorded in the enquiry's activity timeline." />
      <EnquiryForm
        mode="edit"
        action={action}
        sources={sources}
        assignees={assignees}
        currency={ctx.prefs.currency}
        cancelHref={`/enquiries/${id}`}
        defaults={{
          customerName: customer.fullName,
          phone: customer.phone ?? "",
          email: customer.email ?? "",
          company: customer.company ?? "",
          title: enquiry.title,
          description: enquiry.description ?? "",
          source: enquiry.source,
          productService: enquiry.productService ?? "",
          enquiryDate: enquiry.enquiryDate,
          assignedTo: enquiry.assignedTo ?? "",
          priority: enquiry.priority,
          estimatedValue: enquiry.estimatedValue ? String(Number(enquiry.estimatedValue)) : "",
          internalNotes: enquiry.internalNotes ?? "",
          status: enquiry.status,
          lostReason: enquiry.lostReason ?? "",
        }}
      />
    </div>
  );
}
