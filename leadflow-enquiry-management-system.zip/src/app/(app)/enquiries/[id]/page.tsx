import Link from "next/link";
import { notFound } from "next/navigation";
import { Building2, CalendarCheck2, CalendarClock, ExternalLink, Mail, MessageCircle, Pencil, Phone, Trash2, User } from "lucide-react";
import { deleteEnquiry } from "@/actions/enquiries";
import { ActivityTimeline } from "@/components/activity";
import { FollowUpActions, ScheduleFollowUpButton } from "@/components/followup-components";
import { ConfirmButton } from "@/components/modal";
import { NotesPanel } from "@/components/notes-panel";
import { LogContactButton, StatusControl } from "@/components/status-control";
import { Avatar, Badge, Card, CardHeader, DemoTag, DescriptionList, LinkButton, PageHeader, PriorityBadge, StatusBadge, cn } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { ACTIVITY_LABELS, priorityMeta } from "@/lib/constants";
import { describeDue, formatCurrency, formatDate, formatDateTime, relativeTime, toDateInput, toTimeInput, todayInTz } from "@/lib/format";
import { getEnquiryDetail } from "@/lib/queries";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const ctx = await requireUser();
  const detail = UUID_RE.test(id) ? await getEnquiryDetail(ctx.business.id, id) : null;
  return { title: detail ? `${detail.customer.fullName} · ${detail.enquiry.title}` : "Enquiry" };
}

export default async function EnquiryDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const ctx = await requireUser();
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();
  const detail = await getEnquiryDetail(ctx.business.id, id);
  if (!detail) notFound();
  const { enquiry, customer, followUps, notes, activities } = detail;
  const prefs = ctx.prefs;
  const tz = prefs.timeZone;
  const now = new Date();
  const today = todayInTz(tz);
  const pendingFollowUps = followUps.filter((f) => f.status === "pending");
  const pastFollowUps = followUps.filter((f) => f.status !== "pending").sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime());
  const isClosed = enquiry.status === "converted" || enquiry.status === "lost";
  const whatsappDigits = customer.phone?.replace(/\D/g, "");

  return (
    <>
      <PageHeader
        backHref="/enquiries"
        backLabel="Enquiries"
        eyebrow={
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={enquiry.status} />
            <PriorityBadge priority={enquiry.priority} />
            <Badge>{enquiry.source}</Badge>
            {enquiry.isDemo && <DemoTag />}
          </div>
        }
        title={customer.fullName}
        description={enquiry.title}
        actions={
          <>
            {!isClosed && <LogContactButton enquiryId={enquiry.id} isNew={enquiry.status === "new"} />}
            {!isClosed && <ScheduleFollowUpButton enquiryId={enquiry.id} enquiryLabel={`${customer.fullName} — ${enquiry.title}`} today={today} variant="secondary" defaultTitle={`Follow up with ${customer.fullName.split(" ")[0]}`} />}
            <LinkButton href={`/enquiries/${enquiry.id}/edit`} variant="secondary">
              <Pencil className="h-4 w-4" /> Edit
            </LinkButton>
            <ConfirmButton
              action={deleteEnquiry.bind(null, enquiry.id)}
              title="Delete this enquiry?"
              description={`"${enquiry.title}" and all of its follow-ups, notes and history will be permanently deleted. This cannot be undone.`}
              confirmLabel="Delete enquiry"
              variant="outline-danger"
              successMessage="Enquiry deleted"
              redirectTo="/enquiries"
            >
              <Trash2 className="h-4 w-4" /> Delete
            </ConfirmButton>
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <Card>
            <CardHeader title="Enquiry details" description={`Received ${formatDate(enquiry.enquiryDate, prefs)} · added ${relativeTime(enquiry.createdAt, now)}`} />
            <div className="p-5">
              <DescriptionList
                items={[
                  { label: "Product / service", value: enquiry.productService || "—" },
                  { label: "Enquiry source", value: enquiry.source },
                  { label: "Estimated deal value", value: enquiry.estimatedValue ? formatCurrency(enquiry.estimatedValue, prefs.currency) : "—" },
                  { label: "Priority", value: priorityMeta(enquiry.priority).label },
                  { label: "Assigned to", value: enquiry.assignedTo || "Unassigned" },
                  { label: "Last updated", value: formatDateTime(enquiry.updatedAt, prefs) },
                  ...(enquiry.contactedAt ? [{ label: "First contacted", value: formatDateTime(enquiry.contactedAt, prefs) }] : []),
                  ...(enquiry.convertedAt ? [{ label: "Converted on", value: formatDateTime(enquiry.convertedAt, prefs) }] : []),
                  ...(enquiry.lostAt ? [{ label: "Marked lost on", value: formatDateTime(enquiry.lostAt, prefs) }] : []),
                  ...(enquiry.status === "lost" ? [{ label: "Reason for loss", value: enquiry.lostReason || "Not recorded" }] : []),
                ]}
              />
              <div className="mt-5 border-t border-slate-100 pt-5">
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">Original enquiry</p>
                <p className="mt-1 whitespace-pre-wrap text-sm text-slate-800">{enquiry.description || <span className="text-slate-400">No description recorded.</span>}</p>
              </div>
              {enquiry.internalNotes && (
                <div className="mt-5 rounded-lg bg-amber-50 p-4">
                  <p className="text-xs font-medium uppercase tracking-wide text-amber-700">Internal notes</p>
                  <p className="mt-1 whitespace-pre-wrap text-sm text-amber-900">{enquiry.internalNotes}</p>
                </div>
              )}
            </div>
          </Card>

          <Card>
            <CardHeader title="Notes" description="Internal notes for your team. Only the author can edit or delete a note." />
            <NotesPanel
              enquiryId={enquiry.id}
              notes={notes.map((n) => ({
                id: n.note.id,
                content: n.note.content,
                authorName: n.authorName ?? "Team member",
                createdAtLabel: formatDateTime(n.note.createdAt, prefs),
                edited: n.note.updatedAt.getTime() - n.note.createdAt.getTime() > 1000,
                canEdit: n.note.authorId === ctx.user.id,
                isDemo: n.note.isDemo,
              }))}
            />
          </Card>

          <Card>
            <CardHeader title="Interaction history" description="Chronological timeline of everything that happened with this enquiry." />
            <ActivityTimeline
              items={activities.map((a) => ({
                id: a.log.id,
                type: a.log.type,
                description: a.log.description,
                meta: `${ACTIVITY_LABELS[a.log.type] ?? "Activity"}${a.userName ? ` · ${a.userName}` : ""} · ${formatDateTime(a.log.createdAt, prefs)}`,
                timeAgo: relativeTime(a.log.createdAt, now),
              }))}
            />
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader title="Status" description="Changing the status updates your dashboard, analytics and timeline." />
            <div className="p-5">
              <StatusControl enquiryId={enquiry.id} status={enquiry.status} />
              <p className="mt-3 text-xs text-slate-500">
                {enquiry.status === "converted"
                  ? "This customer has been won. Pending follow-ups were cleared automatically."
                  : enquiry.status === "lost"
                    ? "This enquiry is closed as lost. You can reopen it by selecting another status."
                    : "Marking as Converted or Lost closes the enquiry and clears any pending follow-ups."}
              </p>
            </div>
          </Card>

          <Card>
            <CardHeader
              title="Customer"
              action={
                <Link href={`/customers/${customer.id}`} className="inline-flex items-center gap-1 text-sm font-medium text-brand-600 hover:text-brand-700">
                  Full profile <ExternalLink className="h-3.5 w-3.5" />
                </Link>
              }
            />
            <div className="p-5">
              <div className="flex items-center gap-3">
                <Avatar name={customer.fullName} size="lg" />
                <div className="min-w-0">
                  <p className="truncate font-semibold text-slate-900">{customer.fullName}</p>
                  {customer.company && (
                    <p className="flex items-center gap-1 truncate text-sm text-slate-500">
                      <Building2 className="h-3.5 w-3.5" /> {customer.company}
                    </p>
                  )}
                </div>
              </div>
              <ul className="mt-4 space-y-2 text-sm">
                <li className="flex items-center gap-2 text-slate-700">
                  <Phone className="h-4 w-4 text-slate-400" />
                  {customer.phone ? (
                    <a href={`tel:${customer.phone}`} className="hover:text-brand-700">
                      {customer.phone}
                    </a>
                  ) : (
                    <span className="text-slate-400">No phone</span>
                  )}
                </li>
                <li className="flex items-center gap-2 text-slate-700">
                  <Mail className="h-4 w-4 text-slate-400" />
                  {customer.email ? (
                    <a href={`mailto:${customer.email}`} className="truncate hover:text-brand-700">
                      {customer.email}
                    </a>
                  ) : (
                    <span className="text-slate-400">No email</span>
                  )}
                </li>
                <li className="flex items-center gap-2 text-slate-700">
                  <User className="h-4 w-4 text-slate-400" />
                  Customer since {formatDate(customer.createdAt, prefs)}
                </li>
              </ul>
              {whatsappDigits && whatsappDigits.length >= 6 && (
                <a
                  href={`https://wa.me/${whatsappDigits}`}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-700 hover:bg-emerald-100"
                >
                  <MessageCircle className="h-4 w-4" /> Message on WhatsApp
                </a>
              )}
            </div>
          </Card>

          <Card>
            <CardHeader title="Follow-ups" description={pendingFollowUps.length > 0 ? `${pendingFollowUps.length} pending` : "No pending follow-ups"} />
            {pendingFollowUps.length === 0 ? (
              <div className="px-5 py-6 text-center">
                <CalendarClock className="mx-auto h-6 w-6 text-slate-300" />
                <p className="mt-2 text-sm text-slate-500">{isClosed ? "This enquiry is closed." : "Schedule a follow-up so this lead isn't forgotten."}</p>
                {!isClosed && (
                  <div className="mt-3">
                    <ScheduleFollowUpButton enquiryId={enquiry.id} enquiryLabel={`${customer.fullName} — ${enquiry.title}`} today={today} size="sm" variant="subtle" defaultTitle={`Follow up with ${customer.fullName.split(" ")[0]}`} />
                  </div>
                )}
              </div>
            ) : (
              <ul className="divide-y divide-slate-100">
                {pendingFollowUps.map((f) => {
                  const due = describeDue(f.dueAt, prefs, now);
                  return (
                    <li key={f.id} className="px-5 py-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium text-slate-900">{f.title}</p>
                          <p className={cn("text-xs font-medium", due.tone === "danger" ? "text-red-600" : due.tone === "warning" ? "text-amber-600" : due.tone === "info" ? "text-brand-700" : "text-slate-500")}>{due.label}</p>
                          {f.description && <p className="mt-1 text-xs text-slate-500">{f.description}</p>}
                        </div>
                        <PriorityBadge priority={f.priority} />
                      </div>
                      <div className="mt-3">
                        <FollowUpActions id={f.id} title={f.title} dueDate={toDateInput(f.dueAt, tz)} dueTime={toTimeInput(f.dueAt, tz)} compact />
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
            {pastFollowUps.length > 0 && (
              <details className="border-t border-slate-100">
                <summary className="cursor-pointer px-5 py-3 text-xs font-medium text-slate-500 hover:text-slate-900">
                  {pastFollowUps.length} completed or cancelled
                </summary>
                <ul className="divide-y divide-slate-100 border-t border-slate-100">
                  {pastFollowUps.slice(0, 8).map((f) => (
                    <li key={f.id} className="flex items-start gap-2 px-5 py-3">
                      <CalendarCheck2 className={cn("mt-0.5 h-4 w-4 shrink-0", f.status === "completed" ? "text-emerald-500" : "text-slate-300")} />
                      <div className="min-w-0">
                        <p className="truncate text-sm text-slate-700">{f.title}</p>
                        <p className="text-xs text-slate-400">
                          {f.status === "completed" ? `Completed ${formatDateTime(f.completedAt ?? f.updatedAt, prefs)}` : `Cancelled · was due ${formatDateTime(f.dueAt, prefs)}`}
                        </p>
                        {f.completionNotes && <p className="mt-0.5 text-xs text-slate-500">{f.completionNotes}</p>}
                      </div>
                    </li>
                  ))}
                </ul>
              </details>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}
