import { createEnquiry } from "@/actions/enquiries";
import { EnquiryForm } from "@/components/enquiry-form";
import { PageHeader } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { firstParam, todayInTz } from "@/lib/format";
import { getAssigneeOptions, getSourceOptions } from "@/lib/queries";

export const metadata = { title: "Add enquiry" };

export default async function NewEnquiryPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requireUser();
  const sp = await searchParams;
  const [sources, assignees] = await Promise.all([getSourceOptions(ctx.business.id), getAssigneeOptions(ctx.business.id)]);
  const pre = (k: string) => (firstParam(sp[k]) ?? "").slice(0, 200);
  return (
    <div className="mx-auto max-w-4xl">
      <PageHeader backHref="/enquiries" backLabel="Enquiries" title="Add new enquiry" description="New enquiries start with the status “New” and appear instantly in your dashboard and analytics." />
      <EnquiryForm
        mode="create"
        action={createEnquiry}
        sources={sources}
        assignees={assignees}
        currency={ctx.prefs.currency}
        cancelHref="/enquiries"
        defaults={{
          customerName: pre("name"),
          phone: pre("phone"),
          email: pre("email"),
          company: pre("company"),
          title: "",
          description: "",
          source: "",
          productService: "",
          enquiryDate: todayInTz(ctx.prefs.timeZone),
          assignedTo: "",
          priority: "medium",
          estimatedValue: "",
          internalNotes: "",
          status: "new",
          lostReason: "",
        }}
      />
    </div>
  );
}
