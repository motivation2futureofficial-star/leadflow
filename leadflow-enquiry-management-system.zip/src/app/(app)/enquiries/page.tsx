import Link from "next/link";
import { ArrowDown, ArrowUp, ArrowUpDown, ChevronLeft, ChevronRight, Eye, Inbox, Pencil, Plus, SearchX, Trash2 } from "lucide-react";
import { deleteEnquiry } from "@/actions/enquiries";
import { EnquiryFilters } from "@/components/enquiry-filters";
import { ConfirmButton } from "@/components/modal";
import { StatusControl } from "@/components/status-control";
import { Card, DemoTag, EmptyState, LinkButton, PageHeader, PriorityBadge, buttonClass, cn } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { describeDue, formatCurrency, formatDate, relativeTime } from "@/lib/format";
import { getSourceOptions, listEnquiries, parseEnquiryFilters } from "@/lib/queries";

export const metadata = { title: "Enquiries" };

const COLUMNS: { key: string; label: string; sort?: string; className?: string }[] = [
  { key: "customer", label: "Customer", sort: "name" },
  { key: "phone", label: "Phone" },
  { key: "email", label: "Email" },
  { key: "source", label: "Source" },
  { key: "status", label: "Status", sort: "status" },
  { key: "priority", label: "Priority", sort: "priority" },
  { key: "date", label: "Date Added", sort: "date" },
  { key: "followup", label: "Next Follow-up", sort: "followup" },
  { key: "actions", label: "Actions", className: "text-right" },
];

export default async function EnquiriesPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requireUser();
  const sp = await searchParams;
  const filters = parseEnquiryFilters(sp);
  const [result, sources] = await Promise.all([listEnquiries(ctx.business.id, filters), getSourceOptions(ctx.business.id)]);
  const now = new Date();

  const base = new URLSearchParams();
  (["q", "status", "source", "priority", "from", "to", "sort", "dir"] as const).forEach((k) => {
    const v = filters[k];
    if (v) base.set(k, String(v));
  });
  if (filters.pageSize && filters.pageSize !== 10) base.set("pageSize", String(filters.pageSize));

  const exportHref = `/api/export/enquiries?${base.toString()}`;
  const pageHref = (p: number) => {
    const u = new URLSearchParams(base);
    if (p > 1) u.set("page", String(p));
    const s = u.toString();
    return `/enquiries${s ? `?${s}` : ""}`;
  };
  const currentSort = filters.sort ?? "created";
  const currentDir = filters.dir === "asc" ? "asc" : "desc";
  const sortHref = (key: string) => {
    const u = new URLSearchParams(base);
    u.set("sort", key);
    if (currentSort === key) u.set("dir", currentDir === "desc" ? "asc" : "desc");
    else u.set("dir", key === "name" ? "asc" : "desc");
    return `/enquiries?${u.toString()}`;
  };
  const hasFilters = Boolean(filters.q || filters.status || filters.source || filters.priority || filters.from || filters.to);
  const start = result.total === 0 ? 0 : (result.page - 1) * result.pageSize + 1;
  const end = Math.min(result.total, result.page * result.pageSize);
  const pageNumbers = Array.from({ length: result.pageCount }, (_, i) => i + 1).filter(
    (p) => p === 1 || p === result.pageCount || Math.abs(p - result.page) <= 1,
  );

  return (
    <>
      <PageHeader
        title="Enquiries"
        description="Every customer enquiry in one place. Search, filter, update statuses and export."
        actions={
          <LinkButton href="/enquiries/new">
            <Plus className="h-4 w-4" /> Add enquiry
          </LinkButton>
        }
      />

      <EnquiryFilters
        sources={sources}
        current={{ q: filters.q, status: filters.status, source: filters.source, priority: filters.priority, from: filters.from, to: filters.to, pageSize: filters.pageSize }}
        total={result.total}
        exportHref={exportHref}
      />

      <Card className="mt-4 overflow-hidden">
        {result.rows.length === 0 ? (
          hasFilters ? (
            <EmptyState
              icon={SearchX}
              title="No enquiries match your filters"
              description="Try a different search term or clear the filters to see all enquiries."
              action={
                <LinkButton href="/enquiries" variant="secondary">
                  Clear filters
                </LinkButton>
              }
            />
          ) : (
            <EmptyState
              icon={Inbox}
              title="No enquiries yet"
              description="Add your first enquiry to start tracking leads, scheduling follow-ups and measuring conversions."
              action={
                <LinkButton href="/enquiries/new">
                  <Plus className="h-4 w-4" /> Add your first enquiry
                </LinkButton>
              }
            />
          )
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden overflow-x-auto md:block">
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    {COLUMNS.map((col) => (
                      <th key={col.key} scope="col" className={cn("whitespace-nowrap px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500", col.className)}>
                        {col.sort ? (
                          <Link href={sortHref(col.sort)} className="inline-flex items-center gap-1 hover:text-slate-900">
                            {col.label}
                            {currentSort === col.sort ? (
                              currentDir === "asc" ? (
                                <ArrowUp className="h-3.5 w-3.5 text-brand-600" />
                              ) : (
                                <ArrowDown className="h-3.5 w-3.5 text-brand-600" />
                              )
                            ) : (
                              <ArrowUpDown className="h-3.5 w-3.5 opacity-40" />
                            )}
                          </Link>
                        ) : (
                          col.label
                        )}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {result.rows.map((row) => {
                    const due = row.nextFollowUpAt ? describeDue(row.nextFollowUpAt, ctx.prefs, now) : null;
                    return (
                      <tr key={row.id} className="hover:bg-slate-50/70">
                        <td className="max-w-[260px] px-4 py-3">
                          <Link href={`/enquiries/${row.id}`} className="block">
                            <span className="flex items-center gap-2">
                              <span className="truncate font-medium text-slate-900 hover:text-brand-700">{row.customerName}</span>
                              {row.isDemo && <DemoTag />}
                            </span>
                            <span className="block truncate text-xs text-slate-500">{row.title}</span>
                          </Link>
                        </td>
                        <td className="whitespace-nowrap px-4 py-3 text-slate-700">
                          {row.customerPhone ? (
                            <a href={`tel:${row.customerPhone}`} className="hover:text-brand-700">
                              {row.customerPhone}
                            </a>
                          ) : (
                            "—"
                          )}
                        </td>
                        <td className="max-w-[200px] truncate px-4 py-3 text-slate-700">
                          {row.customerEmail ? (
                            <a href={`mailto:${row.customerEmail}`} className="hover:text-brand-700">
                              {row.customerEmail}
                            </a>
                          ) : (
                            "—"
                          )}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3 text-slate-700">{row.source}</td>
                        <td className="whitespace-nowrap px-4 py-3">
                          <StatusControl enquiryId={row.id} status={row.status} />
                        </td>
                        <td className="whitespace-nowrap px-4 py-3">
                          <PriorityBadge priority={row.priority} />
                        </td>
                        <td className="whitespace-nowrap px-4 py-3 text-slate-700">
                          <span className="block">{formatDate(row.enquiryDate, ctx.prefs)}</span>
                          <span className="block text-xs text-slate-400">added {relativeTime(row.createdAt, now)}</span>
                        </td>
                        <td className="whitespace-nowrap px-4 py-3">
                          {due ? (
                            <span className={cn("text-xs font-medium", due.tone === "danger" ? "text-red-600" : due.tone === "warning" ? "text-amber-600" : due.tone === "info" ? "text-brand-700" : "text-slate-600")}>{due.label}</span>
                          ) : (
                            <span className="text-xs text-slate-400">—</span>
                          )}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-0.5">
                            <Link href={`/enquiries/${row.id}`} className={buttonClass("ghost", "icon-sm")} title="View profile" aria-label="View">
                              <Eye className="h-4 w-4" />
                            </Link>
                            <Link href={`/enquiries/${row.id}/edit`} className={buttonClass("ghost", "icon-sm")} title="Edit" aria-label="Edit">
                              <Pencil className="h-4 w-4" />
                            </Link>
                            <ConfirmButton
                              action={deleteEnquiry.bind(null, row.id)}
                              title="Delete this enquiry?"
                              description={`The enquiry "${row.title}" for ${row.customerName}, along with its follow-ups and notes, will be permanently deleted.`}
                              confirmLabel="Delete enquiry"
                              variant="ghost"
                              size="icon-sm"
                              className="text-slate-500 hover:text-red-600"
                              successMessage="Enquiry deleted"
                            >
                              <Trash2 className="h-4 w-4" />
                            </ConfirmButton>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <ul className="divide-y divide-slate-100 md:hidden">
              {result.rows.map((row) => {
                const due = row.nextFollowUpAt ? describeDue(row.nextFollowUpAt, ctx.prefs, now) : null;
                return (
                  <li key={row.id} className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <Link href={`/enquiries/${row.id}`} className="min-w-0">
                        <span className="flex items-center gap-2">
                          <span className="truncate font-medium text-slate-900">{row.customerName}</span>
                          {row.isDemo && <DemoTag />}
                        </span>
                        <span className="block truncate text-xs text-slate-500">{row.title}</span>
                      </Link>
                      <PriorityBadge priority={row.priority} />
                    </div>
                    <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-600">
                      <StatusControl enquiryId={row.id} status={row.status} />
                      <span className="rounded-full bg-slate-100 px-2 py-0.5">{row.source}</span>
                      <span>{formatDate(row.enquiryDate, ctx.prefs)}</span>
                      {row.estimatedValue && <span className="font-medium text-slate-800">{formatCurrency(row.estimatedValue, ctx.prefs.currency)}</span>}
                    </div>
                    <div className="mt-2 flex items-center justify-between gap-3">
                      <div className="min-w-0 text-xs text-slate-500">
                        {row.customerPhone && (
                          <a href={`tel:${row.customerPhone}`} className="block truncate">
                            {row.customerPhone}
                          </a>
                        )}
                        {due && <span className={cn("block font-medium", due.tone === "danger" ? "text-red-600" : due.tone === "warning" ? "text-amber-600" : "text-slate-600")}>{due.label}</span>}
                      </div>
                      <div className="flex shrink-0 items-center gap-0.5">
                        <Link href={`/enquiries/${row.id}/edit`} className={buttonClass("ghost", "icon-sm")} aria-label="Edit">
                          <Pencil className="h-4 w-4" />
                        </Link>
                        <ConfirmButton
                          action={deleteEnquiry.bind(null, row.id)}
                          title="Delete this enquiry?"
                          description={`"${row.title}" for ${row.customerName} will be permanently deleted.`}
                          confirmLabel="Delete enquiry"
                          variant="ghost"
                          size="icon-sm"
                          className="text-slate-500 hover:text-red-600"
                          successMessage="Enquiry deleted"
                        >
                          <Trash2 className="h-4 w-4" />
                        </ConfirmButton>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>

            {/* Pagination */}
            <div className="flex flex-col items-center justify-between gap-3 border-t border-slate-200 px-4 py-3 text-sm text-slate-600 sm:flex-row">
              <p>
                Showing <span className="font-medium text-slate-900">{start}</span>–<span className="font-medium text-slate-900">{end}</span> of{" "}
                <span className="font-medium text-slate-900">{result.total}</span>
              </p>
              {result.pageCount > 1 && (
                <nav className="flex items-center gap-1" aria-label="Pagination">
                  <Link href={pageHref(Math.max(1, result.page - 1))} aria-disabled={result.page === 1} className={cn(buttonClass("secondary", "icon-sm"), result.page === 1 && "pointer-events-none opacity-50")}>
                    <ChevronLeft className="h-4 w-4" />
                  </Link>
                  {pageNumbers.map((p, i) => (
                    <span key={p} className="flex items-center">
                      {i > 0 && pageNumbers[i - 1] !== p - 1 && <span className="px-1 text-slate-400">…</span>}
                      <Link href={pageHref(p)} className={cn(buttonClass(p === result.page ? "primary" : "secondary", "icon-sm"), "text-xs")} aria-current={p === result.page ? "page" : undefined}>
                        {p}
                      </Link>
                    </span>
                  ))}
                  <Link href={pageHref(Math.min(result.pageCount, result.page + 1))} aria-disabled={result.page === result.pageCount} className={cn(buttonClass("secondary", "icon-sm"), result.page === result.pageCount && "pointer-events-none opacity-50")}>
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </nav>
              )}
            </div>
          </>
        )}
      </Card>
    </>
  );
}
