"use client";

import { useEffect } from "react";
import { AlertTriangle } from "lucide-react";
import { Button, EmptyState, LinkButton } from "@/components/ui";

export default function AppError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
      <EmptyState
        icon={AlertTriangle}
        title="Something went wrong"
        description="We couldn't load this page. Your data is safe — please try again."
        action={
          <div className="flex gap-2">
            <Button onClick={reset}>Try again</Button>
            <LinkButton href="/dashboard" variant="secondary">
              Go to dashboard
            </LinkButton>
          </div>
        }
      />
    </div>
  );
}
