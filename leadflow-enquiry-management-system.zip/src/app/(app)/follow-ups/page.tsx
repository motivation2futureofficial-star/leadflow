import Link from "next/link";
import { AlertTriangle, CalendarCheck2, CalendarClock, CheckCircle2, History, Sun } from "lucide-react";
import { FollowUpActions, ScheduleFollowUpButton } from "@/components/followup-components";
import { Card, CardHeader, DemoTag, PageHeader, PriorityBadge, StatusBadge, cn } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { describeDue, formatDateTime, toDateInput, toTimeInput, todayInTz } from "@/lib/format";
import { getEnquiryOptions, getFollowUpBuckets, type FollowUpRow } from "@/lib/queries";
import type { UserPreferences } from "@/db/schema";

export const metadata = { title: "Follow-ups" };

function FollowUpList({ items, prefs, now, emptyText }: { items: FollowUpRow[]; prefs: UserPreferences; now: Date; emptyText: string }) {
  if (items.length === 0) return <p className="px-5 py-6 text-center text-sm text-slate-500">{emptyText}</p>;
  return (
    <ul className="divide-y divide-slate-100">
      {items.map((f) => {
        const due = describeDue(f.followUp.dueAt, prefs, now);
        return (
          <li key={f.followUp.id} className="flex flex-col gap-3 px-5 py-4 lg:flex-row lg:items-center lg:justify-between">
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <Link href={`/enquiries/${f.followUp.enquiryId}`} className="font-medium text-slate-900 hover:text-brand-700">
                  {f.customerName}
                </Link>
                <StatusBadge status={f.enquiryStatus} />
                <PriorityBadge priority={f.followUp.priority} />
                {f.followUp.isDemo && <DemoTag />}
              </div>
              <p className="mt-1 text-sm text-slate-800">{f.followUp.title}</p>
              {f.followUp.description && <p className="mt-0.5 text-xs text-slate-500">{f.followUp.description}</p>}
              <p className="mt-1 text-xs text-slate-500">
                Re: {f.enquiryTitle}
                {f.customerPhone && (
                  <>
                    {" · "}
                    <a href={`tel:${f.customerPhone}`} className="hover:text-brand-700">
                      {f.customerPhone}
                    </a>
                  </>
                )}
              </p>
              <p className={cn("mt-1 text-xs font-semibold", due.tone === "danger" ? "text-red-600" : due.tone === "warning" ? "text-amber-600" : due.tone === "info" ? "text-brand-700" : "text-slate-600")}>
                {due.label}
                {due.delta !== 0 && <span className="font-normal text-slate-400"> · {formatDateTime(f.followUp.dueAt, prefs)}</span>}
              </p>
            </div>
            <div className="shrink-0">
              <FollowUpActions id={f.followUp.id} title={f.followUp.title} dueDate={toDateInput(f.followUp.dueAt, prefs.timeZone)} dueTime={toTimeInput(f.followUp.dueAt, prefs.timeZone)} compact />
            </div>
          </li>
        );
      })}
    </ul>
  );
}

export default async function FollowUpsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requireUser();
  const sp = await searchParams;
  const view = sp.view === "history" ? "history" : "active";
  const openSchedule = sp.schedule === "1";
  const tz = ctx.prefs.timeZone;
  const [buckets, options] = await Promise.all([getFollowUpBuckets(ctx.business.id, tz, view === "history"), getEnquiryOptions(ctx.business.id)]);
  const today = todayInTz(tz);
  const now = buckets.now;
  const totalActive = buckets.overdue.length + buckets.dueToday.length + buckets.upcoming.length;

  return (
    <>
      <PageHeader
        title="Follow-ups"
        description="Your reminder queue. Overdue items are flagged automatically so nothing gets forgotten."
        actions={<ScheduleFollowUpButton enquiryOptions={options} today={today} defaultOpen={openSchedule} />}
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <a href="#overdue" className={cn("rounded-xl border bg-white p-4 shadow-sm", buckets.overdue.length > 0 ? "border-red-200" : "border-slate-200")}>
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-slate-500">Overdue</p>
            <AlertTriangle className={cn("h-5 w-5", buckets.overdue.length > 0 ? "text-red-500" : "text-slate-300")} />
          </div>
          <p className={cn("mt-1 text-2xl font-semibold", buckets.overdue.length > 0 ? "text-red-600" : "text-slate-900")}>{buckets.overdue.length}</p>
        </a>
        <a href="#today" className={cn("rounded-xl border bg-white p-4 shadow-sm", buckets.dueToday.length > 0 ? "border-amber-200" : "border-slate-200")}>
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-slate-500">Due today</p>
            <Sun className={cn("h-5 w-5", buckets.dueToday.length > 0 ? "text-amber-500" : "text-slate-300")} />
          </div>
          <p className={cn("mt-1 text-2xl font-semibold", buckets.dueToday.length > 0 ? "text-amber-600" : "text-slate-900")}>{buckets.dueToday.length}</p>
        </a>
        <a href="#upcoming" className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-slate-500">Upcoming</p>
            <CalendarClock className="h-5 w-5 text-brand-500" />
          </div>
          <p className="mt-1 text-2xl font-semibold text-slate-900">{buckets.upcoming.length}</p>
        </a>
      </div>

      <div className="mt-6 flex items-center gap-1 border-b border-slate-200">
        <Link href="/follow-ups" className={cn("-mb-px border-b-2 px-3 py-2 text-sm font-medium", view === "active" ? "border-brand-600 text-brand-700" : "border-transparent text-slate-500 hover:text-slate-900")}>
          Active ({totalActive})
        </Link>
        <Link href="/follow-ups?view=history" className={cn("-mb-px border-b-2 px-3 py-2 text-sm font-medium", view === "history" ? "border-brand-600 text-brand-700" : "border-transparent text-slate-500 hover:text-slate-900")}>
          History
        </Link>
      </div>

      {view === "active" ? (
        <div className="mt-4 space-y-4">
          {totalActive === 0 && (
            <Card>
              <div className="px-5 py-12 text-center">
                <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-500" />
                <h3 className="mt-3 text-sm font-semibold text-slate-900">No pending follow-ups</h3>
                <p className="mt-1 text-sm text-slate-500">Schedule a follow-up from any enquiry, or use the button above.</p>
              </div>
            </Card>
          )}
          {(buckets.overdue.length > 0 || totalActive > 0) && (
            <Card className={cn(buckets.overdue.length > 0 && "border-red-200")}>
              <div id="overdue" className="scroll-mt-20">
                <CardHeader
                  title={
                    <span className="flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4 text-red-500" /> Overdue
                    </span>
                  }
                  description="These follow-ups were due on a previous day. Complete or reschedule them."
                />
              </div>
              <FollowUpList items={buckets.overdue} prefs={ctx.prefs} now={now} emptyText="Nothing overdue — great work." />
            </Card>
          )}
          {totalActive > 0 && (
            <Card className={cn(buckets.dueToday.length > 0 && "border-amber-200")}>
              <div id="today" className="scroll-mt-20">
                <CardHeader
                  title={
                    <span className="flex items-center gap-2">
                      <Sun className="h-4 w-4 text-amber-500" /> Due today
                    </span>
                  }
                  description={`Follow-ups scheduled for today (${today}).`}
                />
              </div>
              <FollowUpList items={buckets.dueToday} prefs={ctx.prefs} now={now} emptyText="No follow-ups due today." />
            </Card>
          )}
          {totalActive > 0 && (
            <Card>
              <div id="upcoming" className="scroll-mt-20">
                <CardHeader
                  title={
                    <span className="flex items-center gap-2">
                      <CalendarClock className="h-4 w-4 text-brand-500" /> Upcoming
                    </span>
                  }
                  description="Everything scheduled after today."
                />
              </div>
              <FollowUpList items={buckets.upcoming} prefs={ctx.prefs} now={now} emptyText="No upcoming follow-ups scheduled." />
            </Card>
          )}
        </div>
      ) : (
        <Card className="mt-4">
          <CardHeader
            title={
              <span className="flex items-center gap-2">
                <History className="h-4 w-4 text-slate-500" /> Completed & cancelled
              </span>
            }
            description="The most recent 100 closed follow-ups."
          />
          {buckets.history.length === 0 ? (
            <p className="px-5 py-8 text-center text-sm text-slate-500">No completed or cancelled follow-ups yet.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {buckets.history.map((f) => (
                <li key={f.followUp.id} className="flex items-start gap-3 px-5 py-4">
                  <CalendarCheck2 className={cn("mt-0.5 h-5 w-5 shrink-0", f.followUp.status === "completed" ? "text-emerald-500" : "text-slate-300")} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Link href={`/enquiries/${f.followUp.enquiryId}`} className="font-medium text-slate-900 hover:text-brand-700">
                        {f.customerName}
                      </Link>
                      <span className={cn("rounded-full px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide", f.followUp.status === "completed" ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500")}>
                        {f.followUp.status}
                      </span>
                      {f.followUp.isDemo && <DemoTag />}
                    </div>
                    <p className="mt-0.5 text-sm text-slate-800">{f.followUp.title}</p>
                    <p className="text-xs text-slate-500">
                      Was due {formatDateTime(f.followUp.dueAt, ctx.prefs)}
                      {f.followUp.completedAt ? ` · completed ${formatDateTime(f.followUp.completedAt, ctx.prefs)}` : ""}
                    </p>
                    {f.followUp.completionNotes && <p className="mt-1 text-xs text-slate-600">{f.followUp.completionNotes}</p>}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}
    </>
  );
}
