import type { ReactNode } from "react";
import { AppShell } from "@/components/app-shell";
import { requireUser } from "@/lib/auth";
import { syncFollowUpNotifications } from "@/lib/events";
import { formatDateTime, relativeTime } from "@/lib/format";
import { getFollowUpCounts, getNotifications, getUnreadCount } from "@/lib/queries";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const ctx = await requireUser();
  await syncFollowUpNotifications(ctx.business.id, ctx.user.id, ctx.prefs);
  const [unread, recent, counts] = await Promise.all([
    getUnreadCount(ctx.user.id),
    getNotifications(ctx.user.id, 8),
    getFollowUpCounts(ctx.business.id, ctx.prefs.timeZone),
  ]);
  const now = new Date();

  return (
    <AppShell
      user={{ fullName: ctx.user.fullName, email: ctx.user.email, avatarUrl: ctx.user.avatarUrl }}
      business={{ name: ctx.business.name, category: ctx.business.category, logoUrl: ctx.business.logoUrl }}
      counts={{ unread, overdue: counts.overdue, dueToday: counts.dueToday }}
      notifications={recent.map((n) => ({
        id: n.id,
        type: n.type,
        title: n.title,
        message: n.message,
        link: n.link,
        isRead: n.isRead,
        timeAgo: relativeTime(n.createdAt, now),
        createdAtLabel: formatDateTime(n.createdAt, ctx.prefs),
      }))}
    >
      {children}
    </AppShell>
  );
}
