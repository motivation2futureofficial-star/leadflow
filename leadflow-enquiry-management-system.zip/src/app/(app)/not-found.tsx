import { SearchX } from "lucide-react";
import { Card, EmptyState, LinkButton } from "@/components/ui";

export default function AppNotFound() {
  return (
    <Card>
      <EmptyState
        icon={SearchX}
        title="We couldn't find that record"
        description="It may have been deleted, or it belongs to a different workspace."
        action={
          <div className="flex gap-2">
            <LinkButton href="/enquiries">Go to enquiries</LinkButton>
            <LinkButton href="/dashboard" variant="secondary">
              Dashboard
            </LinkButton>
          </div>
        }
      />
    </Card>
  );
}
