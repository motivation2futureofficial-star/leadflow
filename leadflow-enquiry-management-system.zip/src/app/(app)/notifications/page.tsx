import Link from "next/link";
import { CheckCheck, Trash2 } from "lucide-react";
import { clearReadNotifications, markAllNotificationsRead } from "@/actions/notifications";
import { ActionButton, ConfirmButton } from "@/components/modal";
import { NotificationList } from "@/components/notification-list";
import { Card, PageHeader, cn } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { formatDateTime, relativeTime } from "@/lib/format";
import { getNotifications } from "@/lib/queries";

export const metadata = { title: "Notifications" };

export default async function NotificationsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requireUser();
  const sp = await searchParams;
  const filter = sp.filter === "unread" ? "unread" : "all";
  const all = await getNotifications(ctx.user.id, 200);
  const unreadCount = all.filter((n) => !n.isRead).length;
  const readCount = all.length - unreadCount;
  const visible = filter === "unread" ? all.filter((n) => !n.isRead) : all;
  const now = new Date();

  return (
    <>
      <PageHeader
        title="Notifications"
        description={unreadCount > 0 ? `${unreadCount} unread notification${unreadCount === 1 ? "" : "s"}` : "You're all caught up."}
        actions={
          <>
            {unreadCount > 0 && (
              <ActionButton action={markAllNotificationsRead} variant="secondary">
                <CheckCheck className="h-4 w-4" /> Mark all as read
              </ActionButton>
            )}
            {readCount > 0 && (
              <ConfirmButton
                action={clearReadNotifications}
                title="Clear read notifications?"
                description={`${readCount} read notification${readCount === 1 ? "" : "s"} will be deleted. Unread ones are kept.`}
                confirmLabel="Clear"
                variant="ghost"
              >
                <Trash2 className="h-4 w-4" /> Clear read
              </ConfirmButton>
            )}
          </>
        }
      />

      <div className="mb-4 flex items-center gap-1 border-b border-slate-200">
        <Link href="/notifications" className={cn("-mb-px border-b-2 px-3 py-2 text-sm font-medium", filter === "all" ? "border-brand-600 text-brand-700" : "border-transparent text-slate-500 hover:text-slate-900")}>
          All ({all.length})
        </Link>
        <Link href="/notifications?filter=unread" className={cn("-mb-px border-b-2 px-3 py-2 text-sm font-medium", filter === "unread" ? "border-brand-600 text-brand-700" : "border-transparent text-slate-500 hover:text-slate-900")}>
          Unread ({unreadCount})
        </Link>
      </div>

      <Card className="overflow-hidden">
        <NotificationList
          items={visible.map((n) => ({
            id: n.id,
            type: n.type,
            title: n.title,
            message: n.message,
            link: n.link,
            isRead: n.isRead,
            timeAgo: relativeTime(n.createdAt, now),
            createdAtLabel: formatDateTime(n.createdAt, ctx.prefs),
          }))}
        />
      </Card>
      <p className="mt-3 text-xs text-slate-500">
        Reminders are generated inside LeadFlow based on your notification preferences. Email delivery is not connected
        {process.env.RESEND_API_KEY ? "" : " (configure RESEND_API_KEY and EMAIL_FROM to enable it)"}.
      </p>
    </>
  );
}
