import Link from "next/link";
import { AlertTriangle, Building2, Database, Download, KeyRound, Sliders, Sparkles, User } from "lucide-react";
import { removeDemoDataAction } from "@/actions/settings";
import { ConfirmButton } from "@/components/modal";
import { BusinessForm, DeleteAccountForm, PasswordForm, PreferencesForm, ProfileForm } from "@/components/settings-forms";
import { Card, CardHeader, PageHeader, buttonClass, cn } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { formatDate } from "@/lib/format";
import { getDemoCounts } from "@/lib/queries";

export const metadata = { title: "Settings" };

const TABS = [
  { key: "profile", label: "Profile", icon: User },
  { key: "business", label: "Business", icon: Building2 },
  { key: "preferences", label: "Preferences", icon: Sliders },
  { key: "data", label: "Data", icon: Database },
] as const;

type TabKey = (typeof TABS)[number]["key"];

export default async function SettingsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requireUser();
  const sp = await searchParams;
  const tab: TabKey = TABS.some((t) => t.key === sp.tab) ? (sp.tab as TabKey) : "profile";
  const demo = tab === "data" ? await getDemoCounts(ctx.business.id) : null;

  return (
    <>
      <PageHeader title="Settings" description="Manage your profile, business details, preferences and data." />
      <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
        <nav className="flex gap-1 overflow-x-auto lg:flex-col" aria-label="Settings sections">
          {TABS.map((t) => (
            <Link
              key={t.key}
              href={`/settings?tab=${t.key}`}
              className={cn(
                "flex shrink-0 items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium",
                tab === t.key ? "bg-white text-brand-700 shadow-sm ring-1 ring-slate-200" : "text-slate-600 hover:bg-white/60 hover:text-slate-900",
              )}
            >
              <t.icon className="h-4 w-4" /> {t.label}
            </Link>
          ))}
        </nav>

        <div className="space-y-6">
          {tab === "profile" && (
            <>
              <Card>
                <CardHeader title="Profile" description="Your name, login email and profile photo." />
                <div className="p-5">
                  <ProfileForm user={{ fullName: ctx.user.fullName, email: ctx.user.email, avatarUrl: ctx.user.avatarUrl }} />
                </div>
              </Card>
              <Card>
                <CardHeader
                  title={
                    <span className="flex items-center gap-2">
                      <KeyRound className="h-4 w-4 text-slate-500" /> Change password
                    </span>
                  }
                  description="Changing your password signs out every other device."
                />
                <div className="p-5">
                  <PasswordForm />
                </div>
              </Card>
              <p className="text-xs text-slate-500">Member since {formatDate(ctx.user.createdAt, ctx.prefs)}.</p>
            </>
          )}

          {tab === "business" && (
            <Card>
              <CardHeader title="Business settings" description="Shown in your sidebar and used across the workspace." />
              <div className="p-5">
                <BusinessForm business={ctx.business} />
              </div>
            </Card>
          )}

          {tab === "preferences" && (
            <Card>
              <CardHeader title="Preferences" description="Formats, time zone and notification preferences." />
              <div className="p-5">
                <PreferencesForm prefs={ctx.prefs} />
              </div>
            </Card>
          )}

          {tab === "data" && demo && (
            <>
              <Card>
                <CardHeader
                  title={
                    <span className="flex items-center gap-2">
                      <Download className="h-4 w-4 text-slate-500" /> Export your data
                    </span>
                  }
                  description="Download CSV files you can open in Excel or Google Sheets."
                />
                <div className="flex flex-wrap gap-2 p-5">
                  <Link href="/api/export/enquiries" prefetch={false} className={buttonClass("secondary")}>
                    <Download className="h-4 w-4" /> Export enquiry records
                  </Link>
                  <Link href="/api/export/customers" prefetch={false} className={buttonClass("secondary")}>
                    <Download className="h-4 w-4" /> Export customer information
                  </Link>
                </div>
              </Card>

              <Card>
                <CardHeader
                  title={
                    <span className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-amber-500" /> Sample data
                    </span>
                  }
                  description="Sample records are labelled “Sample” throughout the app and never mix with your real data once removed."
                />
                <div className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
                  <p className="text-sm text-slate-700">
                    {demo.enquiries > 0 ? (
                      <>
                        <span className="font-semibold">{demo.enquiries}</span> sample enquiries and <span className="font-semibold">{demo.customers}</span> sample customers are currently in your workspace.
                      </>
                    ) : ctx.business.demoRemovedAt ? (
                      <>Sample data was removed on {formatDate(ctx.business.demoRemovedAt, ctx.prefs)}. Only your real records remain.</>
                    ) : (
                      <>No sample data is loaded in this workspace.</>
                    )}
                  </p>
                  {demo.enquiries > 0 && (
                    <ConfirmButton
                      action={removeDemoDataAction}
                      title="Remove all sample data?"
                      description="Every sample enquiry, customer, follow-up, note, activity and notification will be permanently deleted. Records you created yourself are not affected."
                      confirmLabel="Remove sample data"
                      variant="secondary"
                    >
                      Remove sample data
                    </ConfirmButton>
                  )}
                </div>
              </Card>

              <Card className="border-red-200">
                <CardHeader
                  title={
                    <span className="flex items-center gap-2 text-red-700">
                      <AlertTriangle className="h-4 w-4" /> Delete account
                    </span>
                  }
                  description="Permanently deletes your account, business profile and every enquiry, customer, follow-up and note. This cannot be undone."
                />
                <div className="p-5">
                  <DeleteAccountForm />
                </div>
              </Card>
            </>
          )}
        </div>
      </div>
    </>
  );
}
