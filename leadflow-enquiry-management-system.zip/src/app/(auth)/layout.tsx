import Link from "next/link";
import type { ReactNode } from "react";
import { CheckCircle2, Zap } from "lucide-react";

const POINTS = [
  "Capture enquiries from every channel in one place",
  "Schedule follow-ups and get reminded before they're overdue",
  "Track every customer conversation and status change",
  "See which sources convert best with live analytics",
];

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-[46%] flex-col justify-between bg-brand-900 p-12 text-white lg:flex">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-500">
            <Zap className="h-5 w-5" />
          </span>
          <span className="text-xl font-semibold tracking-tight">LeadFlow</span>
        </Link>
        <div>
          <h2 className="text-3xl font-semibold leading-tight tracking-tight">
            Never lose a potential customer because an enquiry was forgotten.
          </h2>
          <ul className="mt-8 space-y-4">
            {POINTS.map((p) => (
              <li key={p} className="flex items-start gap-3 text-brand-100">
                <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-400" />
                <span>{p}</span>
              </li>
            ))}
          </ul>
        </div>
        <p className="text-sm text-brand-200/70">Built for small businesses, agencies, consultants, institutes and sales teams.</p>
      </aside>
      <main className="flex flex-1 flex-col bg-slate-50">
        <div className="flex items-center justify-between px-6 py-5 lg:hidden">
          <Link href="/" className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-900 text-white">
              <Zap className="h-5 w-5" />
            </span>
            <span className="text-lg font-semibold tracking-tight">LeadFlow</span>
          </Link>
        </div>
        <div className="flex flex-1 items-center justify-center px-6 py-10">
          <div className="w-full max-w-md">{children}</div>
        </div>
      </main>
    </div>
  );
}
