import Link from "next/link";
import { redirect } from "next/navigation";
import { LoginForm } from "@/components/auth-forms";
import { getCurrentUser } from "@/lib/auth";

export const metadata = { title: "Log in" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await getCurrentUser();
  if (ctx) redirect(ctx.business.onboardingCompleted ? "/dashboard" : "/onboarding");
  const sp = await searchParams;
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
      <h1 className="text-2xl font-semibold tracking-tight text-slate-900">Welcome back</h1>
      <p className="mt-1 text-sm text-slate-500">Log in to your LeadFlow workspace.</p>
      <div className="mt-6">
        <LoginForm resetDone={sp.reset === "1"} />
      </div>
      <p className="mt-6 text-center text-sm text-slate-600">
        New to LeadFlow?{" "}
        <Link href="/register" className="font-medium text-brand-600 hover:text-brand-700">
          Create an account
        </Link>
      </p>
    </div>
  );
}
