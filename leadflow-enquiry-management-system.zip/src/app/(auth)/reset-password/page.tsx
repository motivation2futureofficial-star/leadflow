import Link from "next/link";
import { ResetPasswordForm } from "@/components/auth-forms";
import { Alert } from "@/components/ui";

export const metadata = { title: "Set new password" };

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const token = typeof sp.token === "string" ? sp.token : "";
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">
      <h1 className="text-2xl font-semibold tracking-tight text-slate-900">Choose a new password</h1>
      <p className="mt-1 text-sm text-slate-500">Your new password will apply to all devices.</p>
      <div className="mt-6">
        {token ? (
          <ResetPasswordForm token={token} />
        ) : (
          <Alert tone="danger" title="Missing reset token">
            This link is incomplete.{" "}
            <Link href="/forgot-password" className="font-medium underline">
              Request a new reset link
            </Link>
            .
          </Alert>
        )}
      </div>
    </div>
  );
}
