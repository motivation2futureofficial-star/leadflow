import type { NextRequest } from "next/server";
import { requireApiUser } from "@/lib/auth";
import { statusMeta } from "@/lib/constants";
import { csvEscape, formatDate, formatDateTime, todayInTz } from "@/lib/format";
import { listCustomers } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const ctx = await requireApiUser();
  if (!ctx) return new Response("Unauthorized", { status: 401 });

  const q = request.nextUrl.searchParams.get("q")?.trim() || undefined;
  const rows = await listCustomers(ctx.business.id, q);

  const header = ["Full Name", "Phone", "Email", "Company", "Total Enquiries", "Open Enquiries", "Converted", "Total Estimated Value", "Latest Status", "Last Enquiry", "Customer Since", "Sample Record"];
  const lines = [header.join(",")];
  for (const r of rows) {
    lines.push(
      [
        r.customer.fullName,
        r.customer.phone,
        r.customer.email,
        r.customer.company,
        r.enquiryCount,
        r.activeCount,
        r.convertedCount,
        r.totalValue ?? "0",
        r.latestStatus ? statusMeta(r.latestStatus).label : "",
        r.lastEnquiryAt ? formatDateTime(r.lastEnquiryAt, ctx.prefs) : "",
        formatDate(r.customer.createdAt, ctx.prefs),
        r.customer.isDemo ? "Yes" : "No",
      ]
        .map(csvEscape)
        .join(","),
    );
  }

  const filename = `leadflow-customers-${todayInTz(ctx.prefs.timeZone)}.csv`;
  return new Response(`\uFEFF${lines.join("\r\n")}`, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}
