import type { NextRequest } from "next/server";
import { requireApiUser } from "@/lib/auth";
import { statusMeta } from "@/lib/constants";
import { csvEscape, formatDate, formatDateTime, todayInTz } from "@/lib/format";
import { listEnquiries, parseEnquiryFilters } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const ctx = await requireApiUser();
  if (!ctx) return new Response("Unauthorized", { status: 401 });

  const sp = Object.fromEntries(request.nextUrl.searchParams.entries());
  const filters = parseEnquiryFilters(sp);
  const result = await listEnquiries(ctx.business.id, { ...filters, page: 1, pageSize: 10_000 });

  const header = [
    "Customer Name",
    "Phone",
    "Email",
    "Company",
    "Enquiry Title",
    "Product / Service",
    "Source",
    "Status",
    "Priority",
    "Enquiry Date",
    "Assigned To",
    "Estimated Value",
    "Next Follow-up",
    "Created At",
    "Sample Record",
  ];
  const lines = [header.join(",")];
  for (const r of result.rows) {
    lines.push(
      [
        r.customerName,
        r.customerPhone,
        r.customerEmail,
        r.customerCompany,
        r.title,
        r.productService,
        r.source,
        statusMeta(r.status).label,
        r.priority,
        formatDate(r.enquiryDate, ctx.prefs),
        r.assignedTo,
        r.estimatedValue ?? "",
        r.nextFollowUpAt ? formatDateTime(r.nextFollowUpAt, ctx.prefs) : "",
        formatDateTime(r.createdAt, ctx.prefs),
        r.isDemo ? "Yes" : "No",
      ]
        .map(csvEscape)
        .join(","),
    );
  }

  const filename = `leadflow-enquiries-${todayInTz(ctx.prefs.timeZone)}.csv`;
  return new Response(`\uFEFF${lines.join("\r\n")}`, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}
