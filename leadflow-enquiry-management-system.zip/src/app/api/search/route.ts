import type { NextRequest } from "next/server";
import { requireApiUser } from "@/lib/auth";
import { globalSearch } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const ctx = await requireApiUser();
  if (!ctx) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const q = request.nextUrl.searchParams.get("q")?.trim().slice(0, 100) ?? "";
  if (q.length < 2) return Response.json({ enquiries: [], customers: [] });
  const results = await globalSearch(ctx.business.id, q);
  return Response.json(results, { headers: { "Cache-Control": "no-store" } });
}
