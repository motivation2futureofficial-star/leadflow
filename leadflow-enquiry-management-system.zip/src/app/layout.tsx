import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "LeadFlow — Smart Enquiry Management",
    template: "%s · LeadFlow",
  },
  description:
    "LeadFlow helps small businesses capture, track and follow up on every customer enquiry so no lead is ever forgotten.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-full bg-slate-50 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
