import { redirect } from "next/navigation";
import { Zap } from "lucide-react";
import { OnboardingForm } from "@/components/onboarding-form";
import { requireUser } from "@/lib/auth";
import { logout } from "@/actions/auth";

export const metadata = { title: "Set up your workspace" };

export default async function OnboardingPage() {
  const ctx = await requireUser({ allowOnboarding: true });
  if (ctx.business.onboardingCompleted) redirect("/dashboard");
  const b = ctx.business;
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="mx-auto flex max-w-3xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-900 text-white">
            <Zap className="h-5 w-5" />
          </span>
          <span className="text-lg font-semibold tracking-tight">LeadFlow</span>
        </div>
        <form action={logout}>
          <button type="submit" className="text-sm font-medium text-slate-500 hover:text-slate-900">
            Log out
          </button>
        </form>
      </header>
      <main className="mx-auto max-w-3xl px-6 pb-16">
        <div className="mb-8">
          <p className="text-sm font-semibold text-brand-600">Step 2 of 2</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight text-slate-900">Welcome, {ctx.user.fullName.split(" ")[0]} 👋</h1>
          <p className="mt-2 text-slate-600">Tell us a little about your business so we can personalise your dashboard.</p>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
          <OnboardingForm
            defaults={{
              businessName: b.name,
              category: b.category ?? "",
              size: b.size ?? "",
              phone: b.phone ?? "",
              email: b.email ?? "",
              address: b.address ?? "",
              website: b.website ?? "",
            }}
          />
        </div>
      </main>
    </div>
  );
}
