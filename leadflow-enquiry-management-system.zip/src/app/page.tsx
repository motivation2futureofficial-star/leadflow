import Link from "next/link";
import { redirect } from "next/navigation";
import {
  ArrowRight,
  BarChart3,
  Bell,
  CalendarClock,
  CheckCircle2,
  Inbox,
  ShieldCheck,
  Users,
  Zap,
} from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { Alert, buttonClass } from "@/components/ui";

export const dynamic = "force-dynamic";

const FEATURES = [
  { icon: Inbox, title: "Centralised enquiries", text: "Capture every enquiry from Instagram, WhatsApp, your website, referrals and walk-ins in one organised pipeline." },
  { icon: CalendarClock, title: "Smart follow-ups", text: "Schedule reminders, see what's due today and never let an overdue follow-up slip through the cracks." },
  { icon: Users, title: "Customer profiles", text: "Every customer gets a complete history: enquiries, status changes, notes and every interaction." },
  { icon: BarChart3, title: "Actionable analytics", text: "Know which channels bring your best leads and how your conversion rate trends month over month." },
  { icon: Bell, title: "In-app reminders", text: "A notification centre keeps upcoming, due and overdue follow-ups front and centre." },
  { icon: ShieldCheck, title: "Private & secure", text: "Each business workspace is isolated. Your customer data is only ever visible to you." },
];

export default async function LandingPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await getCurrentUser();
  if (ctx) redirect(ctx.business.onboardingCompleted ? "/dashboard" : "/onboarding");
  const sp = await searchParams;
  const deleted = sp.deleted === "1";

  return (
    <div className="min-h-screen bg-white text-slate-900">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-900 text-white">
            <Zap className="h-5 w-5" />
          </span>
          <span className="text-lg font-semibold tracking-tight">LeadFlow</span>
        </Link>
        <nav className="flex items-center gap-2">
          <Link href="/login" className={buttonClass("ghost", "md")}>
            Log in
          </Link>
          <Link href="/register" className={buttonClass("primary", "md")}>
            Get started free
          </Link>
        </nav>
      </header>

      <main>
        <section className="mx-auto max-w-6xl px-6 pb-20 pt-12 sm:pt-20">
          {deleted && (
            <Alert tone="success" className="mb-8 max-w-xl">
              Your account and all of its data have been permanently deleted.
            </Alert>
          )}
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-brand-50 px-3 py-1 text-xs font-semibold text-brand-700 ring-1 ring-inset ring-brand-200">
              Smart customer enquiry management
            </span>
            <h1 className="mt-5 text-4xl font-semibold tracking-tight text-slate-950 sm:text-5xl lg:text-6xl">
              Never lose a customer because you forgot to follow up.
            </h1>
            <p className="mt-6 text-lg leading-8 text-slate-600">
              LeadFlow turns scattered enquiries into a structured, trackable workflow. Capture leads, schedule follow-ups, see
              what&apos;s overdue and convert more customers — built for small businesses, agencies, consultants and sales teams.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link href="/register" className={buttonClass("primary", "lg")}>
                Create your free workspace <ArrowRight className="h-4 w-4" />
              </Link>
              <Link href="/login" className={buttonClass("secondary", "lg")}>
                I already have an account
              </Link>
            </div>
            <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-slate-600">
              {["Set up in under 2 minutes", "Sample data to explore", "Export your data any time"].map((t) => (
                <li key={t} className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-600" /> {t}
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-16 overflow-hidden rounded-2xl border border-slate-200 bg-slate-50 shadow-sm">
            <div className="grid gap-px bg-slate-200 sm:grid-cols-2 lg:grid-cols-4">
              {[
                { label: "Total enquiries", value: "128", tone: "text-slate-900" },
                { label: "Follow-ups due today", value: "6", tone: "text-amber-600" },
                { label: "Overdue follow-ups", value: "2", tone: "text-red-600" },
                { label: "Conversion rate", value: "31%", tone: "text-emerald-600" },
              ].map((s) => (
                <div key={s.label} className="bg-white p-6">
                  <p className="text-sm font-medium text-slate-500">{s.label}</p>
                  <p className={`mt-2 text-3xl font-semibold tracking-tight ${s.tone}`}>{s.value}</p>
                </div>
              ))}
            </div>
            <p className="px-6 py-3 text-center text-xs text-slate-500">Illustrative preview — your dashboard is calculated live from your own enquiries.</p>
          </div>
        </section>

        <section className="border-t border-slate-100 bg-slate-50 py-20">
          <div className="mx-auto max-w-6xl px-6">
            <h2 className="text-3xl font-semibold tracking-tight text-slate-950">Everything you need to manage enquiries properly</h2>
            <p className="mt-3 max-w-2xl text-slate-600">
              Simple enough for a one-person business, structured enough for a growing team.
            </p>
            <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((f) => (
                <div key={f.title} className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
                    <f.icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-4 text-base font-semibold text-slate-900">{f.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-600">{f.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="mx-auto max-w-6xl px-6">
            <div className="rounded-2xl bg-brand-900 px-8 py-12 text-white sm:px-12">
              <h2 className="text-3xl font-semibold tracking-tight">Start tracking every enquiry today</h2>
              <p className="mt-3 max-w-xl text-brand-100">
                Register, answer four quick questions about your business and your personalised dashboard is ready — with optional
                sample data so you can explore every feature.
              </p>
              <Link href="/register" className={buttonClass("primary", "lg", "mt-8 bg-white text-brand-900 hover:bg-brand-50")}>
                Get started <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-100 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-6 text-sm text-slate-500 sm:flex-row">
          <p>© {new Date().getFullYear()} LeadFlow. Smart enquiry management for growing businesses.</p>
          <div className="flex gap-4">
            <Link href="/login" className="hover:text-slate-900">
              Log in
            </Link>
            <Link href="/register" className="hover:text-slate-900">
              Register
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
