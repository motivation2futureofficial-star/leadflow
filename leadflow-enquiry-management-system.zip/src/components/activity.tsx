import Link from "next/link";
import type { LucideIcon } from "lucide-react";
import {
  ArrowRightLeft,
  CalendarCheck2,
  CalendarClock,
  CalendarX2,
  CheckCircle2,
  FilePlus2,
  History,
  MessageSquare,
  PencilLine,
  PhoneCall,
  Trash2,
  XCircle,
} from "lucide-react";
import { cn } from "./ui";

const ICONS: Record<string, { icon: LucideIcon; className: string }> = {
  enquiry_created: { icon: FilePlus2, className: "bg-blue-50 text-blue-600" },
  enquiry_updated: { icon: PencilLine, className: "bg-slate-100 text-slate-600" },
  enquiry_deleted: { icon: Trash2, className: "bg-slate-100 text-slate-600" },
  status_changed: { icon: ArrowRightLeft, className: "bg-violet-50 text-violet-600" },
  contacted: { icon: PhoneCall, className: "bg-sky-50 text-sky-600" },
  follow_up_scheduled: { icon: CalendarClock, className: "bg-amber-50 text-amber-600" },
  follow_up_completed: { icon: CalendarCheck2, className: "bg-emerald-50 text-emerald-600" },
  follow_up_rescheduled: { icon: CalendarClock, className: "bg-amber-50 text-amber-600" },
  follow_up_cancelled: { icon: CalendarX2, className: "bg-slate-100 text-slate-500" },
  note_added: { icon: MessageSquare, className: "bg-indigo-50 text-indigo-600" },
  note_updated: { icon: MessageSquare, className: "bg-indigo-50 text-indigo-600" },
  note_deleted: { icon: MessageSquare, className: "bg-slate-100 text-slate-500" },
  converted: { icon: CheckCircle2, className: "bg-emerald-50 text-emerald-600" },
  lost: { icon: XCircle, className: "bg-red-50 text-red-600" },
};

export function ActivityIcon({ type, size = "md" }: { type: string; size?: "sm" | "md" }) {
  const meta = ICONS[type] ?? { icon: History, className: "bg-slate-100 text-slate-500" };
  const Icon = meta.icon;
  return (
    <span className={cn("flex shrink-0 items-center justify-center rounded-full ring-4 ring-white", meta.className, size === "sm" ? "h-7 w-7" : "h-8 w-8")}>
      <Icon className={size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4"} />
    </span>
  );
}

export type TimelineItem = {
  id: string;
  type: string;
  description: string;
  meta: string;
  timeAgo: string;
  href?: string | null;
  context?: string | null;
};

export function ActivityTimeline({ items, emptyText = "No activity yet." }: { items: TimelineItem[]; emptyText?: string }) {
  if (items.length === 0) return <p className="px-5 py-8 text-center text-sm text-slate-500">{emptyText}</p>;
  return (
    <ol className="relative space-y-0 px-5 py-2">
      {items.map((item, idx) => (
        <li key={item.id} className="relative flex gap-4 pb-6 last:pb-2">
          {idx !== items.length - 1 && <span className="absolute left-4 top-8 -ml-px h-full w-0.5 bg-slate-100" aria-hidden="true" />}
          <ActivityIcon type={item.type} />
          <div className="min-w-0 flex-1 pt-1">
            <p className="text-sm text-slate-800">
              {item.description}
              {item.context && item.href && (
                <>
                  {" "}
                  <Link href={item.href} className="font-medium text-brand-600 hover:text-brand-700">
                    {item.context}
                  </Link>
                </>
              )}
              {item.context && !item.href && <span className="font-medium text-slate-900"> {item.context}</span>}
            </p>
            <p className="mt-0.5 text-xs text-slate-500" title={item.meta}>
              {item.timeAgo} · {item.meta}
            </p>
          </div>
        </li>
      ))}
    </ol>
  );
}
