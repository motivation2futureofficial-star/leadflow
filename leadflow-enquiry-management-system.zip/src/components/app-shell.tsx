"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState, useTransition, type FormEvent, type ReactNode } from "react";
import {
  BarChart3,
  Bell,
  Building2,
  CalendarClock,
  Check,
  CheckCheck,
  ChevronDown,
  Inbox,
  LayoutDashboard,
  LogOut,
  Menu,
  Plus,
  Search,
  Settings,
  Sparkles,
  User,
  Users,
  X,
  Zap,
} from "lucide-react";
import { logout } from "@/actions/auth";
import { markAllNotificationsRead, markNotificationRead } from "@/actions/notifications";
import type { NotificationItem } from "@/lib/types";
import { Avatar, Spinner, StatusBadge, buttonClass, cn } from "./ui";
import { ToastProvider } from "./toast";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/enquiries", label: "Enquiries", icon: Inbox },
  { href: "/customers", label: "Customers", icon: Users },
  { href: "/follow-ups", label: "Follow-ups", icon: CalendarClock, badge: "overdue" as const },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/notifications", label: "Notifications", icon: Bell, badge: "unread" as const },
  { href: "/settings", label: "Settings", icon: Settings },
];

type ShellProps = {
  user: { fullName: string; email: string; avatarUrl: string | null };
  business: { name: string; category: string | null; logoUrl: string | null };
  counts: { unread: number; overdue: number; dueToday: number };
  notifications: NotificationItem[];
  children: ReactNode;
};

export function AppShell({ user, business, counts, notifications, children }: ShellProps) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  return (
    <ToastProvider>
      <div className="min-h-screen bg-slate-50">
        {/* Desktop sidebar */}
        <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 lg:block">
          <SidebarContent pathname={pathname} counts={counts} business={business} />
        </aside>

        {/* Mobile drawer */}
        {mobileOpen && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <div className="absolute inset-0 bg-slate-900/50 animate-fade-in" onClick={() => setMobileOpen(false)} aria-hidden="true" />
            <div className="absolute inset-y-0 left-0 w-72 max-w-[85vw] shadow-xl">
              <SidebarContent pathname={pathname} counts={counts} business={business} onNavigate={() => setMobileOpen(false)} />
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                className="absolute right-3 top-4 rounded-md p-1.5 text-brand-100 hover:bg-white/10"
                aria-label="Close menu"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>
        )}

        <div className="lg:pl-64">
          <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b border-slate-200 bg-white/95 px-4 backdrop-blur sm:px-6">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden"
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" />
            </button>
            <GlobalSearch />
            <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
              <Link href="/enquiries/new" className={buttonClass("primary", "sm")}>
                <Plus className="h-4 w-4" />
                <span className="hidden sm:inline">Add enquiry</span>
              </Link>
              <NotificationBell items={notifications} unread={counts.unread} />
              <UserMenu user={user} />
            </div>
          </header>
          <main className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8">{children}</main>
        </div>
      </div>
      <AutoRefresh />
    </ToastProvider>
  );
}

function SidebarContent({
  pathname,
  counts,
  business,
  onNavigate,
}: {
  pathname: string;
  counts: ShellProps["counts"];
  business: ShellProps["business"];
  onNavigate?: () => void;
}) {
  return (
    <div className="flex h-full flex-col bg-brand-900 text-white">
      <div className="flex h-16 items-center gap-2.5 px-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-500">
          <Zap className="h-5 w-5" />
        </div>
        <span className="text-lg font-semibold tracking-tight">LeadFlow</span>
      </div>
      <nav className="scrollbar-thin flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {NAV.map((item) => {
          const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
          const badge = item.badge ? counts[item.badge] : 0;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={cn(
                "group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                active ? "bg-white/10 text-white" : "text-brand-100/80 hover:bg-white/5 hover:text-white",
              )}
            >
              <item.icon className={cn("h-5 w-5 shrink-0", active ? "text-white" : "text-brand-200/70 group-hover:text-white")} />
              {item.label}
              {badge > 0 && (
                <span
                  className={cn(
                    "ml-auto rounded-full px-2 py-0.5 text-[11px] font-semibold leading-4",
                    item.badge === "overdue" ? "bg-red-500 text-white" : "bg-brand-500 text-white",
                  )}
                >
                  {badge > 99 ? "99+" : badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-white/10 p-4">
        <div className="flex items-center gap-3">
          {business.logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={business.logoUrl} alt="" className="h-9 w-9 rounded-lg bg-white object-contain ring-1 ring-white/20" />
          ) : (
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10">
              <Building2 className="h-4 w-4 text-brand-100" />
            </div>
          )}
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{business.name}</p>
            <p className="truncate text-xs text-brand-200/70">{business.category ?? "Business workspace"}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

type SearchResults = {
  enquiries: { id: string; title: string; status: string; customerName: string }[];
  customers: { id: string; fullName: string; email: string | null; phone: string | null }[];
};

function GlobalSearch() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<SearchResults | null>(null);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const term = q.trim();
    if (term.length < 2) {
      setResults(null);
      setLoading(false);
      return;
    }
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(term)}`, { signal: controller.signal });
        if (res.ok) {
          setResults((await res.json()) as SearchResults);
          setOpen(true);
        }
      } catch {
        /* aborted */
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }, 250);
    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [q]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const term = q.trim();
    if (!term) return;
    setOpen(false);
    router.push(`/enquiries?q=${encodeURIComponent(term)}`);
  };

  const hasResults = results && (results.enquiries.length > 0 || results.customers.length > 0);

  return (
    <div ref={ref} className="relative w-full max-w-md">
      <form onSubmit={submit} role="search">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onFocus={() => results && setOpen(true)}
          placeholder="Search enquiries, customers…"
          className="h-10 w-full rounded-lg border-0 bg-slate-100 pl-9 pr-9 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:ring-2 focus:ring-brand-500"
          aria-label="Global search"
        />
        {loading && <Spinner className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />}
      </form>
      {open && results && (
        <div className="absolute left-0 right-0 top-12 z-40 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
          {!hasResults ? (
            <p className="px-4 py-6 text-center text-sm text-slate-500">No matches for “{q.trim()}”</p>
          ) : (
            <div className="max-h-96 overflow-y-auto py-2">
              {results.enquiries.length > 0 && (
                <div>
                  <p className="px-4 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Enquiries</p>
                  {results.enquiries.map((e) => (
                    <Link
                      key={e.id}
                      href={`/enquiries/${e.id}`}
                      onClick={() => setOpen(false)}
                      className="flex items-center justify-between gap-3 px-4 py-2 text-sm hover:bg-slate-50"
                    >
                      <span className="min-w-0">
                        <span className="block truncate font-medium text-slate-900">{e.customerName}</span>
                        <span className="block truncate text-xs text-slate-500">{e.title}</span>
                      </span>
                      <StatusBadge status={e.status} />
                    </Link>
                  ))}
                </div>
              )}
              {results.customers.length > 0 && (
                <div>
                  <p className="px-4 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-wide text-slate-400">Customers</p>
                  {results.customers.map((c) => (
                    <Link key={c.id} href={`/customers/${c.id}`} onClick={() => setOpen(false)} className="block px-4 py-2 text-sm hover:bg-slate-50">
                      <span className="block truncate font-medium text-slate-900">{c.fullName}</span>
                      <span className="block truncate text-xs text-slate-500">{[c.phone, c.email].filter(Boolean).join(" · ")}</span>
                    </Link>
                  ))}
                </div>
              )}
              <button type="button" onClick={submit} className="mt-1 w-full border-t border-slate-100 px-4 py-2 text-left text-xs font-medium text-brand-600 hover:bg-slate-50">
                See all results for “{q.trim()}”
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function NotificationBell({ items, unread }: { items: NotificationItem[]; unread: number }) {
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const openItem = (n: NotificationItem) => {
    setOpen(false);
    startTransition(async () => {
      if (!n.isRead) await markNotificationRead(n.id);
      router.push(n.link ?? "/notifications");
      router.refresh();
    });
  };

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="relative rounded-lg p-2 text-slate-600 hover:bg-slate-100"
        aria-label={`Notifications (${unread} unread)`}
      >
        <Bell className="h-5 w-5" />
        {unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white ring-2 ring-white">
            {unread > 99 ? "99+" : unread}
          </span>
        )}
      </button>
      {open && (
        <div className="absolute right-0 top-12 z-40 w-[22rem] max-w-[calc(100vw-2rem)] overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
            <p className="text-sm font-semibold text-slate-900">Notifications</p>
            {unread > 0 && (
              <button
                type="button"
                disabled={pending}
                onClick={() =>
                  startTransition(async () => {
                    await markAllNotificationsRead();
                    router.refresh();
                  })
                }
                className="inline-flex items-center gap-1 text-xs font-medium text-brand-600 hover:text-brand-700 disabled:opacity-50"
              >
                <CheckCheck className="h-3.5 w-3.5" /> Mark all read
              </button>
            )}
          </div>
          <div className="max-h-96 overflow-y-auto">
            {items.length === 0 ? (
              <div className="px-4 py-8 text-center">
                <Sparkles className="mx-auto h-6 w-6 text-slate-300" />
                <p className="mt-2 text-sm text-slate-500">You&apos;re all caught up</p>
              </div>
            ) : (
              items.map((n) => (
                <button
                  key={n.id}
                  type="button"
                  onClick={() => openItem(n)}
                  className={cn("flex w-full items-start gap-3 px-4 py-3 text-left hover:bg-slate-50", !n.isRead && "bg-brand-50/40")}
                >
                  <span className={cn("mt-1.5 h-2 w-2 shrink-0 rounded-full", n.isRead ? "bg-transparent" : "bg-brand-500")} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-medium text-slate-900">{n.title}</span>
                    <span className="mt-0.5 line-clamp-2 block text-xs text-slate-500">{n.message}</span>
                    <span className="mt-1 block text-[11px] text-slate-400">{n.timeAgo}</span>
                  </span>
                  {n.isRead && <Check className="mt-1 h-3.5 w-3.5 shrink-0 text-slate-300" />}
                </button>
              ))
            )}
          </div>
          <Link href="/notifications" onClick={() => setOpen(false)} className="block border-t border-slate-100 px-4 py-2.5 text-center text-xs font-medium text-brand-600 hover:bg-slate-50">
            View all notifications
          </Link>
        </div>
      )}
    </div>
  );
}

function UserMenu({ user }: { user: ShellProps["user"] }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);
  return (
    <div ref={ref} className="relative">
      <button type="button" onClick={() => setOpen((v) => !v)} className="flex items-center gap-2 rounded-lg p-1 hover:bg-slate-100" aria-label="Account menu">
        <Avatar name={user.fullName} src={user.avatarUrl} size="sm" />
        <ChevronDown className="hidden h-4 w-4 text-slate-500 sm:block" />
      </button>
      {open && (
        <div className="absolute right-0 top-12 z-40 w-60 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
          <div className="border-b border-slate-100 px-4 py-3">
            <p className="truncate text-sm font-semibold text-slate-900">{user.fullName}</p>
            <p className="truncate text-xs text-slate-500">{user.email}</p>
          </div>
          <div className="py-1">
            <Link href="/settings?tab=profile" onClick={() => setOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
              <User className="h-4 w-4 text-slate-400" /> Profile settings
            </Link>
            <Link href="/settings?tab=business" onClick={() => setOpen(false)} className="flex items-center gap-2 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
              <Building2 className="h-4 w-4 text-slate-400" /> Business settings
            </Link>
          </div>
          <form action={logout} className="border-t border-slate-100 py-1">
            <button type="submit" className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50">
              <LogOut className="h-4 w-4" /> Log out
            </button>
          </form>
        </div>
      )}
    </div>
  );
}

/** Refreshes server data every minute so time-based reminders appear without a manual reload. */
function AutoRefresh() {
  const router = useRouter();
  useEffect(() => {
    const id = window.setInterval(() => {
      if (document.visibilityState === "visible") router.refresh();
    }, 60_000);
    return () => window.clearInterval(id);
  }, [router]);
  return null;
}
