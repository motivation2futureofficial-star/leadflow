"use client";

import Link from "next/link";
import { useActionState, useEffect, useState } from "react";
import { Copy, Eye, EyeOff } from "lucide-react";
import { login, register, requestPasswordReset, resetPassword } from "@/actions/auth";
import { initialActionState } from "@/lib/types";
import { Alert, Button, Field, Input } from "./ui";
import { FormMessage, SubmitButton } from "./modal";

function PasswordInput({ id, name, placeholder, autoComplete, invalid }: { id: string; name: string; placeholder?: string; autoComplete?: string; invalid?: boolean }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <Input id={id} name={name} type={show ? "text" : "password"} placeholder={placeholder} autoComplete={autoComplete} invalid={invalid} required className="pr-10" />
      <button
        type="button"
        onClick={() => setShow((v) => !v)}
        className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded p-1 text-slate-400 hover:text-slate-600"
        aria-label={show ? "Hide password" : "Show password"}
      >
        {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
      </button>
    </div>
  );
}

export function LoginForm({ resetDone }: { resetDone?: boolean }) {
  const [state, action] = useActionState(login, initialActionState);
  return (
    <form action={action} className="space-y-5">
      {resetDone && <Alert tone="success">Your password has been reset. Log in with your new password.</Alert>}
      <FormMessage state={state} />
      <Field label="Email address" htmlFor="email" error={state.fieldErrors?.email} required>
        <Input id="email" name="email" type="email" autoComplete="email" placeholder="you@business.com" required invalid={Boolean(state.fieldErrors?.email)} />
      </Field>
      <Field label="Password" htmlFor="password" error={state.fieldErrors?.password} required>
        <PasswordInput id="password" name="password" autoComplete="current-password" placeholder="Your password" invalid={Boolean(state.fieldErrors?.password)} />
      </Field>
      <div className="flex items-center justify-between">
        <label className="flex items-center gap-2 text-sm text-slate-600">
          <input type="checkbox" name="remember" defaultChecked className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500" />
          Remember me for 30 days
        </label>
        <Link href="/forgot-password" className="text-sm font-medium text-brand-600 hover:text-brand-700">
          Forgot password?
        </Link>
      </div>
      <SubmitButton className="w-full" size="lg" pendingText="Logging in…">
        Log in
      </SubmitButton>
    </form>
  );
}

export function RegisterForm() {
  const [state, action] = useActionState(register, initialActionState);
  const [tz, setTz] = useState("UTC");
  useEffect(() => {
    try {
      setTz(Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC");
    } catch {
      setTz("UTC");
    }
  }, []);
  return (
    <form action={action} className="space-y-5">
      <FormMessage state={state} />
      <input type="hidden" name="timeZone" value={tz} />
      <Field label="Full name" htmlFor="fullName" error={state.fieldErrors?.fullName} required>
        <Input id="fullName" name="fullName" autoComplete="name" placeholder="Alex Morgan" required invalid={Boolean(state.fieldErrors?.fullName)} />
      </Field>
      <Field label="Business name" htmlFor="businessName" error={state.fieldErrors?.businessName} required>
        <Input id="businessName" name="businessName" autoComplete="organization" placeholder="Morgan Interiors" required invalid={Boolean(state.fieldErrors?.businessName)} />
      </Field>
      <Field label="Email address" htmlFor="email" error={state.fieldErrors?.email} required>
        <Input id="email" name="email" type="email" autoComplete="email" placeholder="you@business.com" required invalid={Boolean(state.fieldErrors?.email)} />
      </Field>
      <Field label="Password" htmlFor="password" error={state.fieldErrors?.password} hint="At least 8 characters." required>
        <PasswordInput id="password" name="password" autoComplete="new-password" placeholder="Create a strong password" invalid={Boolean(state.fieldErrors?.password)} />
      </Field>
      <SubmitButton className="w-full" size="lg" pendingText="Creating your workspace…">
        Create account
      </SubmitButton>
      <p className="text-center text-xs text-slate-500">By creating an account you agree to keep your customers&apos; data safe and private.</p>
    </form>
  );
}

export function ForgotPasswordForm() {
  const [state, action] = useActionState(requestPasswordReset, initialActionState);
  const [copied, setCopied] = useState(false);
  const resetPath = state.data?.resetPath;
  const [origin, setOrigin] = useState("");
  useEffect(() => setOrigin(window.location.origin), []);
  const fullLink = resetPath ? `${origin}${resetPath}` : "";

  return (
    <form action={action} className="space-y-5">
      {state.ok && state.message && <Alert tone={resetPath ? "warning" : "success"}>{state.message}</Alert>}
      {state.error && <Alert tone="danger">{state.error}</Alert>}
      {resetPath && (
        <div className="rounded-lg border border-slate-200 bg-white p-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Your password reset link</p>
          <p className="mt-1 text-xs text-slate-500">
            To send this link by email instead, configure <code className="rounded bg-slate-100 px-1">RESEND_API_KEY</code> and{" "}
            <code className="rounded bg-slate-100 px-1">EMAIL_FROM</code> on the server. The link expires in 1 hour.
          </p>
          <div className="mt-3 flex items-center gap-2">
            <Input readOnly value={fullLink} className="font-mono text-xs" onFocus={(e) => e.currentTarget.select()} />
            <Button
              variant="secondary"
              size="icon"
              type="button"
              aria-label="Copy link"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(fullLink);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                } catch {
                  /* clipboard not available */
                }
              }}
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
          {copied && <p className="mt-1 text-xs text-emerald-600">Copied!</p>}
          <Link href={resetPath} className="mt-3 inline-block text-sm font-medium text-brand-600 hover:text-brand-700">
            Open reset page →
          </Link>
        </div>
      )}
      <Field label="Email address" htmlFor="email" error={state.fieldErrors?.email} required>
        <Input id="email" name="email" type="email" autoComplete="email" placeholder="you@business.com" required invalid={Boolean(state.fieldErrors?.email)} />
      </Field>
      <SubmitButton className="w-full" size="lg" pendingText="Generating link…">
        Send reset link
      </SubmitButton>
    </form>
  );
}

export function ResetPasswordForm({ token }: { token: string }) {
  const [state, action] = useActionState(resetPassword, initialActionState);
  return (
    <form action={action} className="space-y-5">
      <FormMessage state={state} />
      <input type="hidden" name="token" value={token} />
      {state.fieldErrors?.token && <Alert tone="danger">{state.fieldErrors.token}</Alert>}
      <Field label="New password" htmlFor="password" error={state.fieldErrors?.password} hint="At least 8 characters." required>
        <PasswordInput id="password" name="password" autoComplete="new-password" invalid={Boolean(state.fieldErrors?.password)} />
      </Field>
      <Field label="Confirm new password" htmlFor="confirmPassword" error={state.fieldErrors?.confirmPassword} required>
        <PasswordInput id="confirmPassword" name="confirmPassword" autoComplete="new-password" invalid={Boolean(state.fieldErrors?.confirmPassword)} />
      </Field>
      <SubmitButton className="w-full" size="lg" pendingText="Updating password…">
        Set new password
      </SubmitButton>
    </form>
  );
}
