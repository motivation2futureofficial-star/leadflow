"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { cn } from "./ui";

const tooltipStyle = {
  borderRadius: 8,
  border: "1px solid #e2e8f0",
  boxShadow: "0 4px 12px rgba(15, 23, 42, 0.08)",
  fontSize: 12,
  padding: "8px 12px",
};

const axisProps = { tick: { fontSize: 11, fill: "#64748b" }, axisLine: false, tickLine: false } as const;

function Empty({ message }: { message: string }) {
  return <div className="flex h-full items-center justify-center text-sm text-slate-400">{message}</div>;
}

export function EnquiriesOverTimeChart({ data, height = 260 }: { data: { label: string; count: number }[]; height?: number }) {
  const total = data.reduce((a, d) => a + d.count, 0);
  const interval = Math.max(0, Math.ceil(data.length / 8) - 1);
  return (
    <div style={{ height }}>
      {total === 0 ? (
        <Empty message="No enquiries in this period yet" />
      ) : (
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
            <defs>
              <linearGradient id="enqGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#2563eb" stopOpacity={0.25} />
                <stop offset="100%" stopColor="#2563eb" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
            <XAxis dataKey="label" interval={interval} {...axisProps} />
            <YAxis allowDecimals={false} {...axisProps} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v) => [v, "Enquiries"]} />
            <Area type="monotone" dataKey="count" stroke="#2563eb" strokeWidth={2} fill="url(#enqGradient)" name="Enquiries" />
          </AreaChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

export function MonthlyPerformanceChart({
  data,
  height = 260,
  showLost = true,
}: {
  data: { label: string; received: number; converted: number; lost: number }[];
  height?: number;
  showLost?: boolean;
}) {
  const total = data.reduce((a, d) => a + d.received, 0);
  return (
    <div style={{ height }}>
      {total === 0 ? (
        <Empty message="No monthly data yet" />
      ) : (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }} barGap={4}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
            <XAxis dataKey="label" {...axisProps} />
            <YAxis allowDecimals={false} {...axisProps} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "#f1f5f9" }} />
            <Legend wrapperStyle={{ fontSize: 12 }} iconType="circle" iconSize={8} />
            <Bar dataKey="received" name="Received" fill="#2563eb" radius={[4, 4, 0, 0]} maxBarSize={28} />
            <Bar dataKey="converted" name="Converted" fill="#10b981" radius={[4, 4, 0, 0]} maxBarSize={28} />
            {showLost && <Bar dataKey="lost" name="Lost" fill="#f87171" radius={[4, 4, 0, 0]} maxBarSize={28} />}
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

export function ConversionTrendChart({ data, height = 240 }: { data: { label: string; rate: number; converted: number; received: number }[]; height?: number }) {
  const total = data.reduce((a, d) => a + d.received, 0);
  return (
    <div style={{ height }}>
      {total === 0 ? (
        <Empty message="No conversion data yet" />
      ) : (
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 8, right: 8, left: -16, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
            <XAxis dataKey="label" {...axisProps} />
            <YAxis unit="%" {...axisProps} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v) => [`${v}%`, "Conversion rate"]} />
            <Line type="monotone" dataKey="rate" stroke="#10b981" strokeWidth={2} dot={{ r: 3, fill: "#10b981" }} name="Conversion rate" />
          </LineChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

export function DistributionChart({
  data,
  height = 220,
  className,
  emptyMessage = "No data yet",
}: {
  data: { name: string; value: number; color: string }[];
  height?: number;
  className?: string;
  emptyMessage?: string;
}) {
  const total = data.reduce((a, d) => a + d.value, 0);
  const visible = data.filter((d) => d.value > 0);
  return (
    <div className={cn("flex flex-col items-center gap-4 sm:flex-row", className)}>
      <div style={{ height, width: height }} className="shrink-0">
        {total === 0 ? (
          <Empty message={emptyMessage} />
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={visible} dataKey="value" nameKey="name" innerRadius="58%" outerRadius="88%" paddingAngle={2} stroke="none">
                {visible.map((entry) => (
                  <Cell key={entry.name} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} />
            </PieChart>
          </ResponsiveContainer>
        )}
      </div>
      <ul className="w-full min-w-0 flex-1 space-y-2">
        {data.map((d) => (
          <li key={d.name} className="flex items-center gap-2 text-sm">
            <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: d.color }} />
            <span className="truncate text-slate-600">{d.name}</span>
            <span className="ml-auto shrink-0 font-medium text-slate-900">{d.value}</span>
            <span className="w-11 shrink-0 text-right text-xs text-slate-400">{total > 0 ? `${Math.round((d.value / total) * 100)}%` : "0%"}</span>
          </li>
        ))}
        {data.length === 0 && <li className="text-sm text-slate-400">{emptyMessage}</li>}
      </ul>
    </div>
  );
}

export function HorizontalBarChart({ data, height = 220, color = "#2563eb" }: { data: { name: string; value: number }[]; height?: number; color?: string }) {
  const total = data.reduce((a, d) => a + d.value, 0);
  return (
    <div style={{ height }}>
      {total === 0 ? (
        <Empty message="No data yet" />
      ) : (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ top: 0, right: 16, left: 8, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
            <XAxis type="number" allowDecimals={false} {...axisProps} />
            <YAxis type="category" dataKey="name" width={110} {...axisProps} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "#f1f5f9" }} />
            <Bar dataKey="value" name="Enquiries" fill={color} radius={[0, 4, 4, 0]} maxBarSize={22} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}
