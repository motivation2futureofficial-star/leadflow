"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useState, type FormEvent } from "react";
import { CalendarRange } from "lucide-react";
import { DATE_RANGE_OPTIONS } from "@/lib/constants";
import { Button, Input, cn } from "./ui";

export function DateRangeFilter({ current }: { current: { key: string; from: string; to: string } }) {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const [showCustom, setShowCustom] = useState(current.key === "custom");
  const [from, setFrom] = useState(current.from);
  const [to, setTo] = useState(current.to);

  const apply = (params: Record<string, string>) => {
    const next = new URLSearchParams(sp.toString());
    ["range", "from", "to"].forEach((k) => next.delete(k));
    for (const [k, v] of Object.entries(params)) next.set(k, v);
    router.push(`${pathname}?${next.toString()}`);
  };

  const submitCustom = (e: FormEvent) => {
    e.preventDefault();
    if (from && to && from <= to) apply({ range: "custom", from, to });
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="inline-flex flex-wrap rounded-lg bg-white p-1 shadow-sm ring-1 ring-inset ring-slate-200">
        {DATE_RANGE_OPTIONS.map((o) => (
          <button
            key={o.value}
            type="button"
            onClick={() => {
              setShowCustom(false);
              apply({ range: o.value });
            }}
            className={cn(
              "rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
              current.key === o.value && !showCustom ? "bg-brand-900 text-white" : "text-slate-600 hover:bg-slate-100",
            )}
          >
            {o.label}
          </button>
        ))}
        <button
          type="button"
          onClick={() => setShowCustom((v) => !v)}
          className={cn(
            "inline-flex items-center gap-1 rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
            current.key === "custom" || showCustom ? "bg-brand-900 text-white" : "text-slate-600 hover:bg-slate-100",
          )}
        >
          <CalendarRange className="h-3.5 w-3.5" /> Custom
        </button>
      </div>
      {showCustom && (
        <form onSubmit={submitCustom} className="flex flex-wrap items-center gap-2">
          <Input type="date" value={from} max={to || undefined} onChange={(e) => setFrom(e.target.value)} className="h-9 w-auto py-1 text-xs" aria-label="From date" required />
          <span className="text-xs text-slate-500">to</span>
          <Input type="date" value={to} min={from || undefined} onChange={(e) => setTo(e.target.value)} className="h-9 w-auto py-1 text-xs" aria-label="To date" required />
          <Button type="submit" size="sm">
            Apply
          </Button>
        </form>
      )}
    </div>
  );
}
