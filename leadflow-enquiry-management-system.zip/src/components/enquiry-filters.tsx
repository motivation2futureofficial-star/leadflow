"use client";

import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import { Download, Search, SlidersHorizontal, X } from "lucide-react";
import { ENQUIRY_STATUSES, PRIORITIES } from "@/lib/constants";
import { Input, Select, Spinner, buttonClass, cn } from "./ui";

export type EnquiryFilterValues = {
  q?: string;
  status?: string;
  source?: string;
  priority?: string;
  from?: string;
  to?: string;
  pageSize?: number;
};

export function EnquiryFilters({
  sources,
  current,
  total,
  exportHref,
}: {
  sources: string[];
  current: EnquiryFilterValues;
  total: number;
  exportHref: string;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const [q, setQ] = useState(current.q ?? "");
  const [pending, startTransition] = useTransition();
  const [showAdvanced, setShowAdvanced] = useState(Boolean(current.from || current.to || current.priority));
  const lastApplied = useRef(current.q ?? "");

  const update = useCallback(
    (patch: Record<string, string | undefined>) => {
      const next = new URLSearchParams(sp.toString());
      for (const [k, v] of Object.entries(patch)) {
        if (v) next.set(k, v);
        else next.delete(k);
      }
      next.delete("page");
      startTransition(() => router.replace(`${pathname}?${next.toString()}`));
    },
    [sp, pathname, router],
  );

  // Sync local search box when the URL changes externally (e.g. global search).
  useEffect(() => {
    const external = current.q ?? "";
    if (external !== lastApplied.current) {
      lastApplied.current = external;
      setQ(external);
    }
  }, [current.q]);

  useEffect(() => {
    const trimmed = q.trim();
    if (trimmed === lastApplied.current) return;
    const t = window.setTimeout(() => {
      lastApplied.current = trimmed;
      update({ q: trimmed || undefined });
    }, 300);
    return () => window.clearTimeout(t);
  }, [q, update]);

  const hasFilters = Boolean(current.q || current.status || current.source || current.priority || current.from || current.to);

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <Input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search by name, phone, email, company or title…"
            className="pl-9"
            aria-label="Search enquiries"
          />
          {pending && <Spinner className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />}
        </div>
        <div className="grid grid-cols-2 gap-2 sm:flex sm:items-center">
          <Select value={current.status ?? ""} onChange={(e) => update({ status: e.target.value || undefined })} aria-label="Filter by status" className="sm:w-44">
            <option value="">All statuses</option>
            <option value="active">Active (open) only</option>
            {ENQUIRY_STATUSES.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </Select>
          <Select value={current.source ?? ""} onChange={(e) => update({ source: e.target.value || undefined })} aria-label="Filter by source" className="sm:w-40">
            <option value="">All sources</option>
            {sources.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </Select>
          <button
            type="button"
            onClick={() => setShowAdvanced((v) => !v)}
            className={cn(buttonClass("secondary", "md"), showAdvanced && "bg-slate-100")}
            aria-expanded={showAdvanced}
          >
            <SlidersHorizontal className="h-4 w-4" /> More
          </button>
          <Link href={exportHref} className={buttonClass("secondary", "md")} prefetch={false} title="Export the current results to CSV">
            <Download className="h-4 w-4" /> <span className="hidden sm:inline">Export CSV</span>
            <span className="sm:hidden">CSV</span>
          </Link>
        </div>
      </div>

      {showAdvanced && (
        <div className="mt-3 grid grid-cols-2 gap-2 border-t border-slate-100 pt-3 sm:grid-cols-4">
          <Select value={current.priority ?? ""} onChange={(e) => update({ priority: e.target.value || undefined })} aria-label="Filter by priority">
            <option value="">All priorities</option>
            {PRIORITIES.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </Select>
          <Input type="date" value={current.from ?? ""} onChange={(e) => update({ from: e.target.value || undefined })} aria-label="Enquiry date from" />
          <Input type="date" value={current.to ?? ""} onChange={(e) => update({ to: e.target.value || undefined })} aria-label="Enquiry date to" />
          <Select value={String(current.pageSize ?? 10)} onChange={(e) => update({ pageSize: e.target.value })} aria-label="Rows per page">
            {[10, 25, 50].map((n) => (
              <option key={n} value={n}>
                {n} per page
              </option>
            ))}
          </Select>
        </div>
      )}

      <div className="mt-3 flex items-center justify-between gap-3 text-xs text-slate-500">
        <span>
          {total === 0 ? "No enquiries" : `${total} enquir${total === 1 ? "y" : "ies"}`}
          {hasFilters ? " match your filters" : " in total"}
        </span>
        {hasFilters && (
          <button type="button" onClick={() => startTransition(() => router.replace(pathname))} className="inline-flex items-center gap-1 font-medium text-brand-600 hover:text-brand-700">
            <X className="h-3.5 w-3.5" /> Clear filters
          </button>
        )}
      </div>
    </div>
  );
}
