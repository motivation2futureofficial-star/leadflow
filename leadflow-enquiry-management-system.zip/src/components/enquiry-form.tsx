"use client";

import Link from "next/link";
import { useActionState, useState } from "react";
import { ENQUIRY_STATUSES, PRIORITIES } from "@/lib/constants";
import { initialActionState, type ActionState } from "@/lib/types";
import { FormMessage, SubmitButton } from "./modal";
import { Card, CardHeader, Field, Input, Select, Textarea, buttonClass } from "./ui";

export type EnquiryFormDefaults = {
  customerName: string;
  phone: string;
  email: string;
  company: string;
  title: string;
  description: string;
  source: string;
  productService: string;
  enquiryDate: string;
  assignedTo: string;
  priority: string;
  estimatedValue: string;
  internalNotes: string;
  status: string;
  lostReason: string;
};

const CUSTOM = "__custom__";

export function EnquiryForm({
  mode,
  action,
  sources,
  assignees,
  defaults,
  cancelHref,
  currency,
}: {
  mode: "create" | "edit";
  action: (prev: ActionState, formData: FormData) => Promise<ActionState>;
  sources: string[];
  assignees: string[];
  defaults: EnquiryFormDefaults;
  cancelHref: string;
  currency: string;
}) {
  const [state, formAction] = useActionState(action, initialActionState);
  const v = (key: keyof EnquiryFormDefaults) => state.data?.[key] ?? defaults[key];
  const err = (key: string) => state.fieldErrors?.[key];

  const initialSource = v("source");
  const sourceIsCustom = Boolean(initialSource) && !sources.includes(initialSource);
  const [source, setSource] = useState(sourceIsCustom ? CUSTOM : initialSource || "");
  const [customSource, setCustomSource] = useState(sourceIsCustom ? initialSource : state.data?.customSource ?? "");
  const [status, setStatus] = useState(v("status") || "new");

  return (
    <form action={formAction} className="space-y-6">
      <FormMessage state={state} />

      <Card>
        <CardHeader title="Customer information" description="Who is enquiring? Matching email or phone numbers are linked to the existing customer." />
        <div className="grid gap-5 p-5 sm:grid-cols-2">
          <Field label="Customer full name" htmlFor="customerName" error={err("customerName")} required>
            <Input id="customerName" name="customerName" defaultValue={v("customerName")} placeholder="e.g. Priya Sharma" required invalid={Boolean(err("customerName"))} />
          </Field>
          <Field label="Phone number" htmlFor="phone" error={err("phone")} required>
            <Input id="phone" name="phone" type="tel" defaultValue={v("phone")} placeholder="+1 555 123 4567" required invalid={Boolean(err("phone"))} />
          </Field>
          <Field label="Email address" htmlFor="email" error={err("email")}>
            <Input id="email" name="email" type="email" defaultValue={v("email")} placeholder="customer@example.com" invalid={Boolean(err("email"))} />
          </Field>
          <Field label="Company name" htmlFor="company" error={err("company")} hint="Optional">
            <Input id="company" name="company" defaultValue={v("company")} placeholder="Company or organisation" />
          </Field>
        </div>
      </Card>

      <Card>
        <CardHeader title="Enquiry information" description="What are they interested in and where did the enquiry come from?" />
        <div className="grid gap-5 p-5 sm:grid-cols-2">
          <Field label="Enquiry title" htmlFor="title" error={err("title")} required className="sm:col-span-2">
            <Input id="title" name="title" defaultValue={v("title")} placeholder="e.g. Wedding photography package for December" required invalid={Boolean(err("title"))} />
          </Field>
          <Field label="Enquiry description" htmlFor="description" error={err("description")} className="sm:col-span-2">
            <Textarea id="description" name="description" defaultValue={v("description")} placeholder="Details of what the customer asked for, requirements, budget, timeline…" />
          </Field>
          <Field label="Enquiry source" htmlFor="source" error={err("source")} required>
            <Select id="source" name="source" value={source} onChange={(e) => setSource(e.target.value)} required invalid={Boolean(err("source"))}>
              <option value="">Select a source</option>
              {sources.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
              <option value={CUSTOM}>＋ Add a custom source…</option>
            </Select>
            {source === CUSTOM && (
              <Input
                name="customSource"
                value={customSource}
                onChange={(e) => setCustomSource(e.target.value)}
                placeholder="Name of the new source, e.g. Trade Show"
                className="mt-2"
                required
                maxLength={60}
              />
            )}
          </Field>
          <Field label="Product or service interested in" htmlFor="productService" error={err("productService")}>
            <Input id="productService" name="productService" defaultValue={v("productService")} placeholder="e.g. Premium package, 2BHK apartment" />
          </Field>
          <Field label="Enquiry date" htmlFor="enquiryDate" error={err("enquiryDate")} required>
            <Input id="enquiryDate" name="enquiryDate" type="date" defaultValue={v("enquiryDate")} required invalid={Boolean(err("enquiryDate"))} />
          </Field>
          <Field label="Assigned team member" htmlFor="assignedTo" error={err("assignedTo")} hint="Optional — start typing to reuse a previous name">
            <Input id="assignedTo" name="assignedTo" defaultValue={v("assignedTo")} list="assignee-options" placeholder="e.g. Alex Morgan" />
            <datalist id="assignee-options">
              {assignees.map((a) => (
                <option key={a} value={a} />
              ))}
            </datalist>
          </Field>
        </div>
      </Card>

      <Card>
        <CardHeader title="Additional information" description="Prioritise and add context for your team." />
        <div className="grid gap-5 p-5 sm:grid-cols-2">
          <Field label="Priority level" htmlFor="priority" error={err("priority")} required>
            <Select id="priority" name="priority" defaultValue={v("priority") || "medium"} required>
              {PRIORITIES.map((p) => (
                <option key={p.value} value={p.value}>
                  {p.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label={`Estimated deal value (${currency})`} htmlFor="estimatedValue" error={err("estimatedValue")} hint="Optional">
            <Input id="estimatedValue" name="estimatedValue" inputMode="decimal" defaultValue={v("estimatedValue")} placeholder="0.00" invalid={Boolean(err("estimatedValue"))} />
          </Field>
          {mode === "edit" && (
            <Field label="Status" htmlFor="status" error={err("status")}>
              <Select id="status" name="status" value={status} onChange={(e) => setStatus(e.target.value)}>
                {ENQUIRY_STATUSES.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </Select>
            </Field>
          )}
          {mode === "edit" && status === "lost" && (
            <Field label="Reason for loss" htmlFor="lostReason" error={err("lostReason")} required={defaults.status !== "lost"}>
              <Input id="lostReason" name="lostReason" defaultValue={v("lostReason")} placeholder="e.g. Chose a competitor" invalid={Boolean(err("lostReason"))} />
            </Field>
          )}
          <Field label="Internal notes" htmlFor="internalNotes" error={err("internalNotes")} className="sm:col-span-2" hint="Visible only to your team.">
            <Textarea id="internalNotes" name="internalNotes" defaultValue={v("internalNotes")} placeholder="Anything your team should know…" />
          </Field>
          {mode === "create" && (
            <>
              <Field label="Schedule first follow-up" htmlFor="followUpDate" error={err("followUpDate")} hint="Optional — creates a reminder immediately.">
                <Input id="followUpDate" name="followUpDate" type="date" defaultValue={state.data?.followUpDate ?? ""} invalid={Boolean(err("followUpDate"))} />
              </Field>
              <Field label="Follow-up time" htmlFor="followUpTime" error={err("followUpTime")}>
                <Input id="followUpTime" name="followUpTime" type="time" defaultValue={state.data?.followUpTime ?? "10:00"} />
              </Field>
            </>
          )}
        </div>
      </Card>

      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Link href={cancelHref} className={buttonClass("secondary", "lg")}>
          Cancel
        </Link>
        <SubmitButton size="lg" pendingText={mode === "create" ? "Saving enquiry…" : "Saving changes…"}>
          {mode === "create" ? "Save enquiry" : "Save changes"}
        </SubmitButton>
      </div>
    </form>
  );
}
