"use client";

import { useRouter } from "next/navigation";
import { useActionState, useEffect, useRef, useState, useTransition } from "react";
import { CalendarClock, CalendarPlus, Check, XCircle } from "lucide-react";
import { cancelFollowUp, completeFollowUp, rescheduleFollowUp, scheduleFollowUp } from "@/actions/followups";
import { FOLLOW_UP_TIME_PRESETS, PRIORITIES } from "@/lib/constants";
import { initialActionState } from "@/lib/types";
import { ConfirmButton, FormMessage, Modal, SubmitButton } from "./modal";
import { useToast } from "./toast";
import { Button, Field, Input, Select, Spinner, Textarea, type ButtonSize, type ButtonVariant } from "./ui";

export function ScheduleFollowUpButton({
  enquiryId,
  enquiryLabel,
  enquiryOptions = [],
  today,
  defaultOpen = false,
  label = "Schedule follow-up",
  variant = "primary",
  size = "md",
  defaultTitle,
}: {
  enquiryId?: string;
  enquiryLabel?: string;
  enquiryOptions?: { id: string; label: string }[];
  today: string;
  defaultOpen?: boolean;
  label?: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  defaultTitle?: string;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const [state, action] = useActionState(scheduleFollowUp, initialActionState);
  const handled = useRef<string | null>(null);
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    if (state.ok && state.data?.id && handled.current !== state.data.id) {
      handled.current = state.data.id;
      setOpen(false);
      toast({ title: state.message ?? "Follow-up scheduled", variant: "success" });
      router.refresh();
    }
  }, [state, router, toast]);

  const err = (k: string) => state.fieldErrors?.[k];

  return (
    <>
      <Button variant={variant} size={size} onClick={() => setOpen(true)}>
        <CalendarPlus className="h-4 w-4" /> {label}
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title="Schedule a follow-up" description="Set a reminder so this enquiry never slips through the cracks.">
        <form action={action} className="space-y-4">
          {state.error && <FormMessage state={state} />}
          {enquiryId ? (
            <>
              <input type="hidden" name="enquiryId" value={enquiryId} />
              {enquiryLabel && (
                <p className="rounded-lg bg-slate-50 px-3 py-2 text-sm text-slate-700">
                  For <span className="font-medium">{enquiryLabel}</span>
                </p>
              )}
            </>
          ) : (
            <Field label="Enquiry" htmlFor="fu-enquiry" error={err("enquiryId")} required>
              <Select id="fu-enquiry" name="enquiryId" defaultValue={state.data?.enquiryId ?? ""} required invalid={Boolean(err("enquiryId"))}>
                <option value="">Select an active enquiry</option>
                {enquiryOptions.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.label}
                  </option>
                ))}
              </Select>
              {enquiryOptions.length === 0 && <p className="mt-1.5 text-xs text-amber-600">You have no active enquiries. Add one first.</p>}
            </Field>
          )}
          <Field label="Reminder title" htmlFor="fu-title" error={err("title")} required>
            <Input id="fu-title" name="title" defaultValue={defaultTitle ?? ""} placeholder="e.g. Call to confirm the quote" required invalid={Boolean(err("title"))} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Date" htmlFor="fu-date" error={err("date")} required>
              <Input id="fu-date" name="date" type="date" defaultValue={today} min={today} required invalid={Boolean(err("date"))} />
            </Field>
            <Field label="Time" htmlFor="fu-time" error={err("time")} required>
              <Input id="fu-time" name="time" type="time" defaultValue="10:00" list="fu-time-presets" required invalid={Boolean(err("time"))} />
              <datalist id="fu-time-presets">
                {FOLLOW_UP_TIME_PRESETS.map((t) => (
                  <option key={t} value={t} />
                ))}
              </datalist>
            </Field>
          </div>
          <Field label="Priority" htmlFor="fu-priority" error={err("priority")} required>
            <Select id="fu-priority" name="priority" defaultValue="medium">
              {PRIORITIES.map((p) => (
                <option key={p.value} value={p.value}>
                  {p.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Description" htmlFor="fu-description" error={err("description")} hint="Optional — what should happen at this follow-up?">
            <Textarea id="fu-description" name="description" placeholder="e.g. Share updated pricing and ask about decision timeline" className="min-h-[72px]" />
          </Field>
          <div className="flex justify-end gap-2 pt-1">
            <Button variant="secondary" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <SubmitButton pendingText="Scheduling…">
              <CalendarClock className="h-4 w-4" /> Schedule
            </SubmitButton>
          </div>
        </form>
      </Modal>
    </>
  );
}

export function FollowUpActions({
  id,
  title,
  dueDate,
  dueTime,
  compact = false,
}: {
  id: string;
  title: string;
  dueDate: string;
  dueTime: string;
  compact?: boolean;
}) {
  const [completeOpen, setCompleteOpen] = useState(false);
  const [rescheduleOpen, setRescheduleOpen] = useState(false);
  const [notes, setNotes] = useState("");
  const [date, setDate] = useState(dueDate);
  const [time, setTime] = useState(dueTime);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const run = (fn: () => Promise<{ error?: string; message?: string }>, close: () => void) =>
    startTransition(async () => {
      const res = await fn();
      if (res.error) {
        toast({ title: res.error, variant: "error" });
        return;
      }
      close();
      toast({ title: res.message ?? "Done", variant: "success" });
      router.refresh();
    });

  const size: ButtonSize = compact ? "sm" : "md";

  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <Button variant="success" size={size} onClick={() => setCompleteOpen(true)} title="Mark as completed">
        <Check className="h-4 w-4" /> Complete
      </Button>
      <Button variant="secondary" size={size} onClick={() => setRescheduleOpen(true)} title="Reschedule">
        <CalendarClock className="h-4 w-4" /> {compact ? "" : "Reschedule"}
      </Button>
      <ConfirmButton
        action={() => cancelFollowUp(id)}
        title="Cancel this follow-up?"
        description={`"${title}" will be removed from your reminders. The enquiry itself is not affected.`}
        confirmLabel="Cancel follow-up"
        variant="ghost"
        size={size}
        className="text-slate-500 hover:text-red-600"
      >
        <XCircle className="h-4 w-4" /> {compact ? "" : "Cancel"}
      </ConfirmButton>

      <Modal open={completeOpen} onClose={() => !pending && setCompleteOpen(false)} title="Complete follow-up" description={title} size="sm">
        <label htmlFor={`complete-notes-${id}`} className="mb-1.5 block text-sm font-medium text-slate-700">
          Outcome notes <span className="font-normal text-slate-400">(optional)</span>
        </label>
        <Textarea id={`complete-notes-${id}`} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="What happened? e.g. Spoke to the customer, sending revised quote tomorrow." autoFocus />
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setCompleteOpen(false)} disabled={pending}>
            Back
          </Button>
          <Button variant="success" onClick={() => run(() => completeFollowUp(id, notes), () => setCompleteOpen(false))} disabled={pending}>
            {pending && <Spinner />} Mark completed
          </Button>
        </div>
      </Modal>

      <Modal open={rescheduleOpen} onClose={() => !pending && setRescheduleOpen(false)} title="Reschedule follow-up" description={title} size="sm">
        <div className="grid grid-cols-2 gap-3">
          <Field label="New date" htmlFor={`rs-date-${id}`} required>
            <Input id={`rs-date-${id}`} type="date" value={date} onChange={(e) => setDate(e.target.value)} required />
          </Field>
          <Field label="New time" htmlFor={`rs-time-${id}`} required>
            <Input id={`rs-time-${id}`} type="time" value={time} onChange={(e) => setTime(e.target.value)} required />
          </Field>
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setRescheduleOpen(false)} disabled={pending}>
            Back
          </Button>
          <Button onClick={() => run(() => rescheduleFollowUp(id, date, time), () => setRescheduleOpen(false))} disabled={pending || !date || !time}>
            {pending && <Spinner />} Save new time
          </Button>
        </div>
      </Modal>
    </div>
  );
}
