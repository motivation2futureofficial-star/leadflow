"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition, type ReactNode } from "react";
import { useFormStatus } from "react-dom";
import { X } from "lucide-react";
import type { ActionState } from "@/lib/types";
import { Alert, Button, Spinner, cn, type ButtonSize, type ButtonVariant } from "./ui";
import { useToast } from "./toast";

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  size = "md",
}: {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  description?: ReactNode;
  children: ReactNode;
  size?: "sm" | "md" | "lg";
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;
  const sizes = { sm: "max-w-md", md: "max-w-lg", lg: "max-w-2xl" };
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-4">
      <div className="absolute inset-0 bg-slate-900/50 animate-fade-in" onClick={onClose} aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        className={cn("relative flex max-h-[92vh] w-full flex-col rounded-t-2xl bg-white shadow-xl sm:rounded-xl animate-toast-in", sizes[size])}
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-5 py-4">
          <div>
            <h2 className="text-base font-semibold text-slate-900">{title}</h2>
            {description && <p className="mt-0.5 text-sm text-slate-500">{description}</p>}
          </div>
          <button type="button" onClick={onClose} className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="overflow-y-auto px-5 py-4">{children}</div>
      </div>
    </div>
  );
}

export function SubmitButton({
  children,
  pendingText,
  variant = "primary",
  size = "md",
  className,
  disabled,
}: {
  children: ReactNode;
  pendingText?: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  disabled?: boolean;
}) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" variant={variant} size={size} className={className} disabled={pending || disabled}>
      {pending && <Spinner />}
      {pending && pendingText ? pendingText : children}
    </Button>
  );
}

export function FormMessage({ state }: { state: ActionState }) {
  if (state.error) return <Alert tone="danger">{state.error}</Alert>;
  if (state.ok && state.message) return <Alert tone="success">{state.message}</Alert>;
  return null;
}

/**
 * Button that opens a confirmation dialog before running a server action.
 * The `action` is typically a server action bound with its arguments.
 */
export function ConfirmButton({
  action,
  title,
  description,
  confirmLabel = "Confirm",
  confirmVariant = "danger",
  variant = "outline-danger",
  size = "md",
  className,
  children,
  successMessage,
  redirectTo,
  disabled,
}: {
  action: () => Promise<ActionState | void>;
  title: string;
  description?: ReactNode;
  confirmLabel?: string;
  confirmVariant?: ButtonVariant;
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  children: ReactNode;
  successMessage?: string;
  redirectTo?: string;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const confirm = () => {
    setError(null);
    startTransition(async () => {
      try {
        const result = await action();
        if (result && result.error) {
          setError(result.error);
          return;
        }
        setOpen(false);
        if (successMessage || result?.message) toast({ title: successMessage ?? result?.message ?? "Done", variant: "success" });
        if (redirectTo) router.push(redirectTo);
        router.refresh();
      } catch {
        setError("Something went wrong. Please try again.");
      }
    });
  };

  return (
    <>
      <Button type="button" variant={variant} size={size} className={className} onClick={() => setOpen(true)} disabled={disabled}>
        {children}
      </Button>
      <Modal open={open} onClose={() => !pending && setOpen(false)} title={title} size="sm">
        {description && <div className="text-sm text-slate-600">{description}</div>}
        {error && (
          <div className="mt-3">
            <Alert tone="danger">{error}</Alert>
          </div>
        )}
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setOpen(false)} disabled={pending}>
            Cancel
          </Button>
          <Button variant={confirmVariant} onClick={confirm} disabled={pending}>
            {pending && <Spinner />}
            {confirmLabel}
          </Button>
        </div>
      </Modal>
    </>
  );
}

/** Simple action button (no confirmation) with pending state + toast. */
export function ActionButton({
  action,
  children,
  variant = "secondary",
  size = "md",
  className,
  successMessage,
  title,
}: {
  action: () => Promise<ActionState | void>;
  children: ReactNode;
  variant?: ButtonVariant;
  size?: ButtonSize;
  className?: string;
  successMessage?: string;
  title?: string;
}) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();
  return (
    <Button
      type="button"
      variant={variant}
      size={size}
      className={className}
      title={title}
      disabled={pending}
      onClick={() =>
        startTransition(async () => {
          const result = await action();
          if (result && result.error) {
            toast({ title: result.error, variant: "error" });
            return;
          }
          if (successMessage || result?.message) toast({ title: successMessage ?? result?.message ?? "Done", variant: "success" });
          router.refresh();
        })
      }
    >
      {pending ? <Spinner /> : children}
    </Button>
  );
}
