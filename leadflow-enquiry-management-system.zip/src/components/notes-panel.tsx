"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { MessageSquare, Pencil, Send, Trash2 } from "lucide-react";
import { addNote, deleteNote, updateNote } from "@/actions/notes";
import { ConfirmButton } from "./modal";
import { useToast } from "./toast";
import { Avatar, Button, DemoTag, Spinner, Textarea } from "./ui";

export type NoteItem = {
  id: string;
  content: string;
  authorName: string;
  createdAtLabel: string;
  edited: boolean;
  canEdit: boolean;
  isDemo: boolean;
};

export function NotesPanel({ enquiryId, notes }: { enquiryId: string; notes: NoteItem[] }) {
  const [draft, setDraft] = useState("");
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const submit = () => {
    if (!draft.trim()) return;
    startTransition(async () => {
      const res = await addNote(enquiryId, draft);
      if (res.error) {
        toast({ title: res.error, variant: "error" });
        return;
      }
      setDraft("");
      toast({ title: "Note added", variant: "success" });
      router.refresh();
    });
  };

  return (
    <div>
      <div className="border-b border-slate-100 p-5">
        <Textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Add an internal note about this enquiry… (Ctrl/⌘ + Enter to save)"
          className="min-h-[80px]"
          onKeyDown={(e) => {
            if ((e.metaKey || e.ctrlKey) && e.key === "Enter") submit();
          }}
        />
        <div className="mt-2 flex items-center justify-between">
          <p className="text-xs text-slate-400">{draft.length}/5000</p>
          <Button size="sm" onClick={submit} disabled={pending || draft.trim().length === 0}>
            {pending ? <Spinner /> : <Send className="h-3.5 w-3.5" />} Add note
          </Button>
        </div>
      </div>
      {notes.length === 0 ? (
        <div className="px-5 py-8 text-center">
          <MessageSquare className="mx-auto h-6 w-6 text-slate-300" />
          <p className="mt-2 text-sm text-slate-500">No notes yet. Capture call outcomes, preferences or next steps.</p>
        </div>
      ) : (
        <ul className="divide-y divide-slate-100">
          {notes.map((n) => (
            <NoteRow key={n.id} note={n} />
          ))}
        </ul>
      )}
    </div>
  );
}

function NoteRow({ note }: { note: NoteItem }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(note.content);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const save = () =>
    startTransition(async () => {
      const res = await updateNote(note.id, value);
      if (res.error) {
        toast({ title: res.error, variant: "error" });
        return;
      }
      setEditing(false);
      toast({ title: "Note updated", variant: "success" });
      router.refresh();
    });

  return (
    <li className="flex gap-3 px-5 py-4">
      <Avatar name={note.authorName} size="sm" className="mt-0.5" />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
          <span className="text-sm font-medium text-slate-900">{note.authorName}</span>
          <span className="text-xs text-slate-400">{note.createdAtLabel}</span>
          {note.edited && <span className="text-xs text-slate-400">(edited)</span>}
          {note.isDemo && <DemoTag />}
          {note.canEdit && !editing && (
            <span className="ml-auto flex items-center gap-1">
              <Button variant="ghost" size="icon-sm" onClick={() => setEditing(true)} aria-label="Edit note">
                <Pencil className="h-3.5 w-3.5" />
              </Button>
              <ConfirmButton
                action={() => deleteNote(note.id)}
                title="Delete this note?"
                description="This cannot be undone."
                confirmLabel="Delete note"
                variant="ghost"
                size="icon-sm"
                className="text-slate-500 hover:text-red-600"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </ConfirmButton>
            </span>
          )}
        </div>
        {editing ? (
          <div className="mt-2">
            <Textarea value={value} onChange={(e) => setValue(e.target.value)} className="min-h-[72px]" autoFocus />
            <div className="mt-2 flex justify-end gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  setEditing(false);
                  setValue(note.content);
                }}
                disabled={pending}
              >
                Cancel
              </Button>
              <Button size="sm" onClick={save} disabled={pending || value.trim().length === 0}>
                {pending && <Spinner />} Save
              </Button>
            </div>
          </div>
        ) : (
          <p className="mt-1 whitespace-pre-wrap text-sm text-slate-700">{note.content}</p>
        )}
      </div>
    </li>
  );
}
