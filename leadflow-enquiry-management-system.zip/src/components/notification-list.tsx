"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import type { LucideIcon } from "lucide-react";
import { AlertTriangle, Bell, CalendarCheck2, CalendarClock, Check, CheckCircle2, Inbox, Sparkles, Sun, Trash2 } from "lucide-react";
import { deleteNotification, markNotificationRead } from "@/actions/notifications";
import type { NotificationItem } from "@/lib/types";
import { Button, EmptyState, cn } from "./ui";

const ICONS: Record<string, { icon: LucideIcon; className: string }> = {
  new_enquiry: { icon: Inbox, className: "bg-blue-50 text-blue-600" },
  follow_up_upcoming: { icon: CalendarClock, className: "bg-brand-50 text-brand-600" },
  follow_up_due_today: { icon: Sun, className: "bg-amber-50 text-amber-600" },
  follow_up_overdue: { icon: AlertTriangle, className: "bg-red-50 text-red-600" },
  follow_up_completed: { icon: CalendarCheck2, className: "bg-emerald-50 text-emerald-600" },
  enquiry_converted: { icon: CheckCircle2, className: "bg-emerald-50 text-emerald-600" },
  account: { icon: Sparkles, className: "bg-violet-50 text-violet-600" },
};

export function NotificationList({ items }: { items: NotificationItem[] }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();

  if (items.length === 0) {
    return <EmptyState icon={Bell} title="No notifications" description="Reminders for upcoming, due and overdue follow-ups, new enquiries and conversions will appear here." />;
  }

  const open = (n: NotificationItem) =>
    startTransition(async () => {
      if (!n.isRead) await markNotificationRead(n.id);
      if (n.link) router.push(n.link);
      router.refresh();
    });

  return (
    <ul className={cn("divide-y divide-slate-100", pending && "opacity-70")}>
      {items.map((n) => {
        const meta = ICONS[n.type] ?? { icon: Bell, className: "bg-slate-100 text-slate-500" };
        const Icon = meta.icon;
        return (
          <li key={n.id} className={cn("flex items-start gap-3 px-5 py-4", !n.isRead && "bg-brand-50/40")}>
            <span className={cn("mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full", meta.className)}>
              <Icon className="h-4 w-4" />
            </span>
            <button type="button" onClick={() => open(n)} className="min-w-0 flex-1 text-left">
              <p className={cn("text-sm text-slate-900", !n.isRead && "font-semibold")}>{n.title}</p>
              <p className="mt-0.5 text-sm text-slate-600">{n.message}</p>
              <p className="mt-1 text-xs text-slate-400" title={n.createdAtLabel}>
                {n.timeAgo} · {n.createdAtLabel}
              </p>
            </button>
            <div className="flex shrink-0 items-center gap-0.5">
              {!n.isRead && (
                <Button
                  variant="ghost"
                  size="icon-sm"
                  title="Mark as read"
                  aria-label="Mark as read"
                  onClick={() =>
                    startTransition(async () => {
                      await markNotificationRead(n.id);
                      router.refresh();
                    })
                  }
                >
                  <Check className="h-4 w-4" />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon-sm"
                title="Delete"
                aria-label="Delete notification"
                className="text-slate-400 hover:text-red-600"
                onClick={() =>
                  startTransition(async () => {
                    await deleteNotification(n.id);
                    router.refresh();
                  })
                }
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
