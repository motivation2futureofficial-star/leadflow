"use client";

import { useActionState } from "react";
import { completeOnboarding } from "@/actions/onboarding";
import { BUSINESS_CATEGORIES, BUSINESS_SIZES } from "@/lib/constants";
import { initialActionState } from "@/lib/types";
import { Field, Input, Select } from "./ui";
import { FormMessage, SubmitButton } from "./modal";

export function OnboardingForm({
  defaults,
}: {
  defaults: { businessName: string; category: string; size: string; phone: string; email: string; address: string; website: string };
}) {
  const [state, action] = useActionState(completeOnboarding, initialActionState);
  return (
    <form action={action} className="space-y-8">
      <FormMessage state={state} />

      <section>
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">About your business</h2>
        <div className="mt-4 grid gap-5 sm:grid-cols-2">
          <Field label="Business name" htmlFor="businessName" error={state.fieldErrors?.businessName} required className="sm:col-span-2">
            <Input id="businessName" name="businessName" defaultValue={defaults.businessName} required invalid={Boolean(state.fieldErrors?.businessName)} />
          </Field>
          <Field label="Business category" htmlFor="category" error={state.fieldErrors?.category} required>
            <Select id="category" name="category" defaultValue={defaults.category} required invalid={Boolean(state.fieldErrors?.category)}>
              <option value="">Select a category</option>
              {BUSINESS_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Business size" htmlFor="size" error={state.fieldErrors?.size} required>
            <Select id="size" name="size" defaultValue={defaults.size} required invalid={Boolean(state.fieldErrors?.size)}>
              <option value="">Select team size</option>
              {BUSINESS_SIZES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          </Field>
        </div>
      </section>

      <section>
        <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">Contact information</h2>
        <p className="mt-1 text-xs text-slate-500">Optional — shown on your business profile.</p>
        <div className="mt-4 grid gap-5 sm:grid-cols-2">
          <Field label="Business phone" htmlFor="phone" error={state.fieldErrors?.phone}>
            <Input id="phone" name="phone" type="tel" defaultValue={defaults.phone} placeholder="+1 555 123 4567" />
          </Field>
          <Field label="Business email" htmlFor="email" error={state.fieldErrors?.email}>
            <Input id="email" name="email" type="email" defaultValue={defaults.email} placeholder="hello@business.com" invalid={Boolean(state.fieldErrors?.email)} />
          </Field>
          <Field label="Website" htmlFor="website" error={state.fieldErrors?.website}>
            <Input id="website" name="website" defaultValue={defaults.website} placeholder="www.business.com" />
          </Field>
          <Field label="Address" htmlFor="address" error={state.fieldErrors?.address}>
            <Input id="address" name="address" defaultValue={defaults.address} placeholder="City, Country" />
          </Field>
        </div>
      </section>

      <section className="rounded-lg border border-brand-200 bg-brand-50 p-4">
        <label className="flex items-start gap-3">
          <input type="checkbox" name="loadDemo" defaultChecked className="mt-0.5 h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500" />
          <span>
            <span className="block text-sm font-semibold text-brand-900">Load sample data to explore LeadFlow</span>
            <span className="mt-0.5 block text-xs text-brand-800/80">
              Adds 18 realistic sample enquiries with follow-ups, notes and history. Every sample record is clearly labelled and can be
              removed in one click from Settings without touching your real data.
            </span>
          </span>
        </label>
      </section>

      <SubmitButton size="lg" className="w-full" pendingText="Setting up your dashboard…">
        Finish setup & open dashboard
      </SubmitButton>
    </form>
  );
}
