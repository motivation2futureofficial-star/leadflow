"use client";

import { useActionState, useState, type ChangeEvent } from "react";
import { Building2, Upload } from "lucide-react";
import { changePassword, deleteAccount, updateBusiness, updatePreferences, updateProfile } from "@/actions/settings";
import { BUSINESS_CATEGORIES, BUSINESS_SIZES, CURRENCIES, DATE_FORMATS, DATE_RANGE_OPTIONS, TIME_ZONES } from "@/lib/constants";
import { initialActionState } from "@/lib/types";
import { FormMessage, SubmitButton } from "./modal";
import { Avatar, Field, Input, Select, Textarea, cn } from "./ui";

function useImagePreview(initial: string | null) {
  const [preview, setPreview] = useState<string | null>(initial);
  const [error, setError] = useState<string | null>(null);
  const onChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setError(null);
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("Please choose an image file.");
      return;
    }
    if (file.size > 1024 * 1024) {
      setError("Image must be smaller than 1 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setPreview(typeof reader.result === "string" ? reader.result : null);
    reader.readAsDataURL(file);
  };
  return { preview, setPreview, error, onChange };
}

export function ProfileForm({ user }: { user: { fullName: string; email: string; avatarUrl: string | null } }) {
  const [state, action] = useActionState(updateProfile, initialActionState);
  const img = useImagePreview(user.avatarUrl);
  const [remove, setRemove] = useState(false);
  return (
    <form action={action} className="space-y-5">
      <FormMessage state={state} />
      <div className="flex items-center gap-4">
        <Avatar name={user.fullName} src={remove ? null : img.preview} size="xl" />
        <div className="space-y-2">
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-inset ring-slate-300 hover:bg-slate-50">
            <Upload className="h-4 w-4" /> Upload photo
            <input
              type="file"
              name="avatar"
              accept="image/*"
              className="sr-only"
              onChange={(e) => {
                setRemove(false);
                img.onChange(e);
              }}
            />
          </label>
          {(img.preview || user.avatarUrl) && (
            <label className="flex items-center gap-2 text-xs text-slate-600">
              <input type="checkbox" name="removeAvatar" checked={remove} onChange={(e) => setRemove(e.target.checked)} className="h-4 w-4 rounded border-slate-300 text-brand-600" />
              Remove photo
            </label>
          )}
          <p className="text-xs text-slate-500">PNG, JPG or WebP up to 1 MB.</p>
          {(img.error || state.fieldErrors?.avatar) && <p className="text-xs font-medium text-red-600">{img.error ?? state.fieldErrors?.avatar}</p>}
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Full name" htmlFor="fullName" error={state.fieldErrors?.fullName} required>
          <Input id="fullName" name="fullName" defaultValue={state.data?.fullName ?? user.fullName} required invalid={Boolean(state.fieldErrors?.fullName)} />
        </Field>
        <Field label="Email address" htmlFor="email" error={state.fieldErrors?.email} hint="Used to log in." required>
          <Input id="email" name="email" type="email" defaultValue={state.data?.email ?? user.email} required invalid={Boolean(state.fieldErrors?.email)} />
        </Field>
      </div>
      <div className="flex justify-end">
        <SubmitButton pendingText="Saving…">Save profile</SubmitButton>
      </div>
    </form>
  );
}

export function PasswordForm() {
  const [state, action] = useActionState(changePassword, initialActionState);
  return (
    <form action={action} className="space-y-5">
      <FormMessage state={state} />
      <Field label="Current password" htmlFor="currentPassword" error={state.fieldErrors?.currentPassword} required>
        <Input id="currentPassword" name="currentPassword" type="password" autoComplete="current-password" required invalid={Boolean(state.fieldErrors?.currentPassword)} />
      </Field>
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="New password" htmlFor="newPassword" error={state.fieldErrors?.newPassword} hint="At least 8 characters." required>
          <Input id="newPassword" name="newPassword" type="password" autoComplete="new-password" required invalid={Boolean(state.fieldErrors?.newPassword)} />
        </Field>
        <Field label="Confirm new password" htmlFor="confirmPassword" error={state.fieldErrors?.confirmPassword} required>
          <Input id="confirmPassword" name="confirmPassword" type="password" autoComplete="new-password" required invalid={Boolean(state.fieldErrors?.confirmPassword)} />
        </Field>
      </div>
      <div className="flex justify-end">
        <SubmitButton pendingText="Updating…">Change password</SubmitButton>
      </div>
    </form>
  );
}

export function BusinessForm({
  business,
}: {
  business: { name: string; category: string | null; size: string | null; phone: string | null; email: string | null; address: string | null; website: string | null; logoUrl: string | null };
}) {
  const [state, action] = useActionState(updateBusiness, initialActionState);
  const img = useImagePreview(business.logoUrl);
  const [remove, setRemove] = useState(false);
  const v = (k: string, fallback: string | null) => state.data?.[k] ?? fallback ?? "";
  return (
    <form action={action} className="space-y-5">
      <FormMessage state={state} />
      <div className="flex items-center gap-4">
        {!remove && img.preview ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={img.preview} alt="Business logo" className="h-20 w-20 rounded-xl border border-slate-200 bg-white object-contain p-1" />
        ) : (
          <div className="flex h-20 w-20 items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50 text-slate-400">
            <Building2 className="h-8 w-8" />
          </div>
        )}
        <div className="space-y-2">
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-lg bg-white px-3 py-2 text-sm font-medium text-slate-700 shadow-sm ring-1 ring-inset ring-slate-300 hover:bg-slate-50">
            <Upload className="h-4 w-4" /> Upload logo
            <input
              type="file"
              name="logo"
              accept="image/*"
              className="sr-only"
              onChange={(e) => {
                setRemove(false);
                img.onChange(e);
              }}
            />
          </label>
          {(img.preview || business.logoUrl) && (
            <label className="flex items-center gap-2 text-xs text-slate-600">
              <input type="checkbox" name="removeLogo" checked={remove} onChange={(e) => setRemove(e.target.checked)} className="h-4 w-4 rounded border-slate-300 text-brand-600" />
              Remove logo
            </label>
          )}
          <p className="text-xs text-slate-500">Square images look best. Up to 1 MB.</p>
          {(img.error || state.fieldErrors?.logo) && <p className="text-xs font-medium text-red-600">{img.error ?? state.fieldErrors?.logo}</p>}
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Business name" htmlFor="name" error={state.fieldErrors?.name} required className="sm:col-span-2">
          <Input id="name" name="name" defaultValue={v("name", business.name)} required invalid={Boolean(state.fieldErrors?.name)} />
        </Field>
        <Field label="Business category" htmlFor="category" error={state.fieldErrors?.category}>
          <Select id="category" name="category" defaultValue={v("category", business.category)}>
            <option value="">Select a category</option>
            {BUSINESS_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Business size" htmlFor="size" error={state.fieldErrors?.size}>
          <Select id="size" name="size" defaultValue={v("size", business.size)}>
            <option value="">Select team size</option>
            {BUSINESS_SIZES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Business phone" htmlFor="bphone" error={state.fieldErrors?.phone}>
          <Input id="bphone" name="phone" type="tel" defaultValue={v("phone", business.phone)} />
        </Field>
        <Field label="Business email" htmlFor="bemail" error={state.fieldErrors?.email}>
          <Input id="bemail" name="email" type="email" defaultValue={v("email", business.email)} invalid={Boolean(state.fieldErrors?.email)} />
        </Field>
        <Field label="Website" htmlFor="website" error={state.fieldErrors?.website}>
          <Input id="website" name="website" defaultValue={v("website", business.website)} placeholder="www.business.com" />
        </Field>
        <Field label="Address" htmlFor="address" error={state.fieldErrors?.address}>
          <Textarea id="address" name="address" defaultValue={v("address", business.address)} className="min-h-[40px]" rows={2} />
        </Field>
      </div>
      <div className="flex justify-end">
        <SubmitButton pendingText="Saving…">Save business settings</SubmitButton>
      </div>
    </form>
  );
}

function Toggle({ name, label, description, defaultChecked }: { name: string; label: string; description: string; defaultChecked: boolean }) {
  const [on, setOn] = useState(defaultChecked);
  return (
    <label className="flex cursor-pointer items-start justify-between gap-4 rounded-lg border border-slate-200 p-4 hover:bg-slate-50">
      <span>
        <span className="block text-sm font-medium text-slate-900">{label}</span>
        <span className="mt-0.5 block text-xs text-slate-500">{description}</span>
      </span>
      <span className="relative mt-0.5 inline-flex shrink-0 items-center">
        <input type="checkbox" name={name} checked={on} onChange={(e) => setOn(e.target.checked)} className="peer sr-only" />
        <span className={cn("h-6 w-11 rounded-full transition-colors peer-focus-visible:ring-2 peer-focus-visible:ring-brand-500 peer-focus-visible:ring-offset-2", on ? "bg-brand-600" : "bg-slate-300")} />
        <span className={cn("absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform", on && "translate-x-5")} />
      </span>
    </label>
  );
}

export function PreferencesForm({
  prefs,
}: {
  prefs: {
    dateFormat: string;
    timeZone: string;
    currency: string;
    defaultDateRange: string;
    reminderLeadHours: number;
    notifyNewEnquiry: boolean;
    notifyUpcoming: boolean;
    notifyDueToday: boolean;
    notifyOverdue: boolean;
    notifyConversions: boolean;
  };
}) {
  const [state, action] = useActionState(updatePreferences, initialActionState);
  const tzOptions = TIME_ZONES.includes(prefs.timeZone) ? TIME_ZONES : [prefs.timeZone, ...TIME_ZONES];
  return (
    <form action={action} className="space-y-6">
      <FormMessage state={state} />
      <div className="grid gap-5 sm:grid-cols-2">
        <Field label="Date format" htmlFor="dateFormat" error={state.fieldErrors?.dateFormat}>
          <Select id="dateFormat" name="dateFormat" defaultValue={prefs.dateFormat}>
            {DATE_FORMATS.map((f) => (
              <option key={f} value={f}>
                {f}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Time zone" htmlFor="timeZone" error={state.fieldErrors?.timeZone} hint="Used for follow-up times and “today” calculations.">
          <Select id="timeZone" name="timeZone" defaultValue={prefs.timeZone}>
            {tzOptions.map((tz) => (
              <option key={tz} value={tz}>
                {tz.replace(/_/g, " ")}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Currency" htmlFor="currency" error={state.fieldErrors?.currency}>
          <Select id="currency" name="currency" defaultValue={prefs.currency}>
            {CURRENCIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Default dashboard date range" htmlFor="defaultDateRange" error={state.fieldErrors?.defaultDateRange}>
          <Select id="defaultDateRange" name="defaultDateRange" defaultValue={prefs.defaultDateRange}>
            {DATE_RANGE_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Remind me about upcoming follow-ups" htmlFor="reminderLeadHours" error={state.fieldErrors?.reminderLeadHours}>
          <Select id="reminderLeadHours" name="reminderLeadHours" defaultValue={String(prefs.reminderLeadHours)}>
            {[6, 12, 24, 48, 72, 168].map((h) => (
              <option key={h} value={h}>
                {h < 24 ? `${h} hours before` : `${h / 24} day${h === 24 ? "" : "s"} before`}
              </option>
            ))}
          </Select>
        </Field>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-slate-900">In-app notifications</h3>
        <p className="mt-0.5 text-xs text-slate-500">Choose which reminders appear in your notification centre.</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <Toggle name="notifyNewEnquiry" label="New enquiry added" description="When an enquiry is created." defaultChecked={prefs.notifyNewEnquiry} />
          <Toggle name="notifyUpcoming" label="Upcoming follow-ups" description="Ahead of time, based on your lead setting." defaultChecked={prefs.notifyUpcoming} />
          <Toggle name="notifyDueToday" label="Follow-ups due today" description="On the morning a follow-up is due." defaultChecked={prefs.notifyDueToday} />
          <Toggle name="notifyOverdue" label="Overdue follow-ups" description="When a follow-up passes its due date." defaultChecked={prefs.notifyOverdue} />
          <Toggle name="notifyConversions" label="Conversions" description="When an enquiry is marked as converted." defaultChecked={prefs.notifyConversions} />
        </div>
      </div>

      <div className="flex justify-end">
        <SubmitButton pendingText="Saving…">Save preferences</SubmitButton>
      </div>
    </form>
  );
}

export function DeleteAccountForm() {
  const [state, action] = useActionState(deleteAccount, initialActionState);
  const [confirm, setConfirm] = useState("");
  return (
    <form action={action} className="space-y-4">
      <FormMessage state={state} />
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label='Type "DELETE" to confirm' htmlFor="confirm" error={state.fieldErrors?.confirm} required>
          <Input id="confirm" name="confirm" value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="DELETE" autoComplete="off" invalid={Boolean(state.fieldErrors?.confirm)} />
        </Field>
        <Field label="Your password" htmlFor="delete-password" error={state.fieldErrors?.password} required>
          <Input id="delete-password" name="password" type="password" autoComplete="current-password" invalid={Boolean(state.fieldErrors?.password)} />
        </Field>
      </div>
      <div className="flex justify-end">
        <SubmitButton variant="danger" pendingText="Deleting account…" disabled={confirm !== "DELETE"}>
          Permanently delete my account
        </SubmitButton>
      </div>
    </form>
  );
}
