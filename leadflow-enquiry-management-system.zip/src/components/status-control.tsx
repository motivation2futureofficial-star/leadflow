"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition, type ChangeEvent } from "react";
import { ChevronDown, Mail, MessageCircle, PhoneCall, Users } from "lucide-react";
import { changeEnquiryStatus, logContact } from "@/actions/enquiries";
import { ENQUIRY_STATUSES, statusMeta } from "@/lib/constants";
import { Modal } from "./modal";
import { useToast } from "./toast";
import { Button, Spinner, Textarea, cn } from "./ui";

export function StatusControl({ enquiryId, status, className }: { enquiryId: string; status: string; className?: string }) {
  const [pending, startTransition] = useTransition();
  const [lostOpen, setLostOpen] = useState(false);
  const [reason, setReason] = useState("");
  const router = useRouter();
  const { toast } = useToast();
  const meta = statusMeta(status);

  const change = (next: string, lostReason?: string) =>
    startTransition(async () => {
      const res = await changeEnquiryStatus(enquiryId, next, lostReason);
      if (res.error) {
        toast({ title: res.error, variant: "error" });
        return;
      }
      setLostOpen(false);
      setReason("");
      if (res.message) toast({ title: res.message, variant: "success" });
      router.refresh();
    });

  const onSelect = (e: ChangeEvent<HTMLSelectElement>) => {
    const next = e.target.value;
    if (next === status) return;
    if (next === "lost") {
      setLostOpen(true);
      return;
    }
    change(next);
  };

  return (
    <>
      <div className={cn("relative inline-flex items-center", className)}>
        <select
          value={status}
          onChange={onSelect}
          disabled={pending}
          aria-label="Change status"
          className={cn(
            "cursor-pointer appearance-none rounded-full py-0.5 pl-2.5 pr-7 text-xs font-medium ring-1 ring-inset focus:outline-none focus:ring-2 focus:ring-brand-500 disabled:opacity-60",
            meta.badge,
          )}
        >
          {ENQUIRY_STATUSES.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </select>
        {pending ? (
          <Spinner className="pointer-events-none absolute right-2 h-3 w-3" />
        ) : (
          <ChevronDown className="pointer-events-none absolute right-2 h-3 w-3 opacity-70" />
        )}
      </div>
      <Modal open={lostOpen} onClose={() => !pending && setLostOpen(false)} title="Mark enquiry as lost" description="Recording the reason helps you understand why deals fall through." size="sm">
        <label htmlFor={`lost-reason-${enquiryId}`} className="mb-1.5 block text-sm font-medium text-slate-700">
          Reason for loss <span className="text-red-500">*</span>
        </label>
        <Textarea
          id={`lost-reason-${enquiryId}`}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="e.g. Chose a competitor, budget constraints, no response after 3 attempts…"
          autoFocus
        />
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setLostOpen(false)} disabled={pending}>
            Cancel
          </Button>
          <Button variant="danger" onClick={() => change("lost", reason)} disabled={pending || reason.trim().length === 0}>
            {pending && <Spinner />} Mark as lost
          </Button>
        </div>
      </Modal>
    </>
  );
}

const METHODS = [
  { value: "phone", label: "Phone call", icon: PhoneCall },
  { value: "whatsapp", label: "WhatsApp", icon: MessageCircle },
  { value: "email", label: "Email", icon: Mail },
  { value: "meeting", label: "Meeting", icon: Users },
];

export function LogContactButton({ enquiryId, isNew }: { enquiryId: string; isNew: boolean }) {
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { toast } = useToast();

  const log = (method: string) =>
    startTransition(async () => {
      const res = await logContact(enquiryId, method);
      if (res.error) {
        toast({ title: res.error, variant: "error" });
        return;
      }
      setOpen(false);
      toast({ title: isNew ? "Contact logged · status moved to Contacted" : "Contact logged", variant: "success" });
      router.refresh();
    });

  return (
    <>
      <Button variant="secondary" onClick={() => setOpen(true)}>
        <PhoneCall className="h-4 w-4" /> Log contact
      </Button>
      <Modal open={open} onClose={() => !pending && setOpen(false)} title="Log a customer contact" description={isNew ? "This records the interaction and moves the enquiry from New to Contacted." : "This records the interaction in the timeline."} size="sm">
        <div className="grid grid-cols-2 gap-2">
          {METHODS.map((m) => (
            <button
              key={m.value}
              type="button"
              disabled={pending}
              onClick={() => log(m.value)}
              className="flex items-center gap-2 rounded-lg border border-slate-200 px-3 py-3 text-sm font-medium text-slate-700 hover:border-brand-300 hover:bg-brand-50 disabled:opacity-50"
            >
              <m.icon className="h-4 w-4 text-brand-600" /> {m.label}
            </button>
          ))}
        </div>
        {pending && (
          <p className="mt-3 flex items-center gap-2 text-xs text-slate-500">
            <Spinner /> Saving…
          </p>
        )}
      </Modal>
    </>
  );
}
