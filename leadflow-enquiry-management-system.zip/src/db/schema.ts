import {
  boolean,
  date,
  index,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

export const enquiryStatusEnum = pgEnum("enquiry_status", [
  "new",
  "contacted",
  "interested",
  "follow_up_required",
  "converted",
  "lost",
]);

export const priorityEnum = pgEnum("priority_level", ["low", "medium", "high", "urgent"]);

export const followUpStatusEnum = pgEnum("follow_up_status", ["pending", "completed", "cancelled"]);

const timestamps = {
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
};

// ---------------------------------------------------------------------------
// Users & authentication
// ---------------------------------------------------------------------------

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    fullName: text("full_name").notNull(),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    avatarUrl: text("avatar_url"),
    ...timestamps,
  },
  (t) => [uniqueIndex("users_email_unique").on(t.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(), // sha256 hash of the session token
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    remember: boolean("remember").notNull().default(false),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("sessions_user_idx").on(t.userId), index("sessions_expires_idx").on(t.expiresAt)],
);

export const passwordResetTokens = pgTable(
  "password_reset_tokens",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("password_reset_token_hash_unique").on(t.tokenHash)],
);

// ---------------------------------------------------------------------------
// Business profile & preferences
// ---------------------------------------------------------------------------

export const businesses = pgTable(
  "businesses",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerId: uuid("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    category: text("category"),
    size: text("size"),
    phone: text("phone"),
    email: text("email"),
    address: text("address"),
    website: text("website"),
    logoUrl: text("logo_url"),
    onboardingCompleted: boolean("onboarding_completed").notNull().default(false),
    demoSeededAt: timestamp("demo_seeded_at", { withTimezone: true }),
    demoRemovedAt: timestamp("demo_removed_at", { withTimezone: true }),
    ...timestamps,
  },
  (t) => [uniqueIndex("businesses_owner_unique").on(t.ownerId)],
);

export const userPreferences = pgTable("user_preferences", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  dateFormat: text("date_format").notNull().default("DD/MM/YYYY"),
  timeZone: text("time_zone").notNull().default("UTC"),
  currency: text("currency").notNull().default("USD"),
  defaultDateRange: text("default_date_range").notNull().default("30d"),
  notifyNewEnquiry: boolean("notify_new_enquiry").notNull().default(true),
  notifyUpcoming: boolean("notify_upcoming").notNull().default(true),
  notifyDueToday: boolean("notify_due_today").notNull().default(true),
  notifyOverdue: boolean("notify_overdue").notNull().default(true),
  notifyConversions: boolean("notify_conversions").notNull().default(true),
  reminderLeadHours: integer("reminder_lead_hours").notNull().default(24),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

// ---------------------------------------------------------------------------
// CRM data
// ---------------------------------------------------------------------------

export const customers = pgTable(
  "customers",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businesses.id, { onDelete: "cascade" }),
    fullName: text("full_name").notNull(),
    phone: text("phone"),
    email: text("email"),
    company: text("company"),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [
    index("customers_business_idx").on(t.businessId),
    index("customers_business_email_idx").on(t.businessId, t.email),
    index("customers_business_phone_idx").on(t.businessId, t.phone),
    index("customers_business_name_idx").on(t.businessId, t.fullName),
  ],
);

export const enquirySources = pgTable(
  "enquiry_sources",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businesses.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    isCustom: boolean("is_custom").notNull().default(true),
    isDemo: boolean("is_demo").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("enquiry_sources_business_name_unique").on(t.businessId, t.name)],
);

export const enquiries = pgTable(
  "enquiries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businesses.id, { onDelete: "cascade" }),
    customerId: uuid("customer_id")
      .notNull()
      .references(() => customers.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    description: text("description"),
    source: text("source").notNull(),
    productService: text("product_service"),
    enquiryDate: date("enquiry_date").notNull(),
    assignedTo: text("assigned_to"),
    status: enquiryStatusEnum("status").notNull().default("new"),
    priority: priorityEnum("priority").notNull().default("medium"),
    estimatedValue: numeric("estimated_value", { precision: 14, scale: 2 }),
    internalNotes: text("internal_notes"),
    lostReason: text("lost_reason"),
    contactedAt: timestamp("contacted_at", { withTimezone: true }),
    convertedAt: timestamp("converted_at", { withTimezone: true }),
    lostAt: timestamp("lost_at", { withTimezone: true }),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [
    index("enquiries_business_idx").on(t.businessId),
    index("enquiries_business_status_idx").on(t.businessId, t.status),
    index("enquiries_business_source_idx").on(t.businessId, t.source),
    index("enquiries_business_date_idx").on(t.businessId, t.enquiryDate),
    index("enquiries_business_created_idx").on(t.businessId, t.createdAt),
    index("enquiries_customer_idx").on(t.customerId),
  ],
);

export const followUps = pgTable(
  "follow_ups",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businesses.id, { onDelete: "cascade" }),
    enquiryId: uuid("enquiry_id")
      .notNull()
      .references(() => enquiries.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    description: text("description"),
    dueAt: timestamp("due_at", { withTimezone: true }).notNull(),
    priority: priorityEnum("priority").notNull().default("medium"),
    status: followUpStatusEnum("status").notNull().default("pending"),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    completionNotes: text("completion_notes"),
    createdById: uuid("created_by_id").references(() => users.id, { onDelete: "set null" }),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [
    index("follow_ups_business_status_due_idx").on(t.businessId, t.status, t.dueAt),
    index("follow_ups_enquiry_idx").on(t.enquiryId),
  ],
);

export const activityLogs = pgTable(
  "activity_logs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businesses.id, { onDelete: "cascade" }),
    enquiryId: uuid("enquiry_id").references(() => enquiries.id, { onDelete: "set null" }),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    type: text("type").notNull(),
    description: text("description").notNull(),
    metadata: jsonb("metadata").$type<Record<string, unknown>>(),
    isDemo: boolean("is_demo").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("activity_logs_business_created_idx").on(t.businessId, t.createdAt),
    index("activity_logs_enquiry_idx").on(t.enquiryId),
  ],
);

export const notes = pgTable(
  "notes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businesses.id, { onDelete: "cascade" }),
    enquiryId: uuid("enquiry_id")
      .notNull()
      .references(() => enquiries.id, { onDelete: "cascade" }),
    authorId: uuid("author_id").references(() => users.id, { onDelete: "set null" }),
    content: text("content").notNull(),
    isDemo: boolean("is_demo").notNull().default(false),
    ...timestamps,
  },
  (t) => [index("notes_enquiry_idx").on(t.enquiryId)],
);

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    businessId: uuid("business_id")
      .notNull()
      .references(() => businesses.id, { onDelete: "cascade" }),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: text("type").notNull(),
    title: text("title").notNull(),
    message: text("message").notNull(),
    link: text("link"),
    isRead: boolean("is_read").notNull().default(false),
    dedupeKey: text("dedupe_key").notNull(),
    isDemo: boolean("is_demo").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("notifications_user_read_idx").on(t.userId, t.isRead, t.createdAt),
    uniqueIndex("notifications_user_dedupe_unique").on(t.userId, t.dedupeKey),
  ],
);

export type User = typeof users.$inferSelect;
export type Business = typeof businesses.$inferSelect;
export type UserPreferences = typeof userPreferences.$inferSelect;
export type Customer = typeof customers.$inferSelect;
export type Enquiry = typeof enquiries.$inferSelect;
export type FollowUp = typeof followUps.$inferSelect;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type Note = typeof notes.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
