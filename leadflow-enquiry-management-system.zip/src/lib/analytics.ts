import "server-only";
import { and, count, desc, eq, gte, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { activityLogs, customers, enquiries, followUps, users } from "@/db/schema";
import { ACTIVE_STATUSES, ENQUIRY_STATUSES, SOURCE_COLORS, type EnquiryStatus } from "./constants";
import { addDays, diffDays, firstParam, lastNMonths, monthLabel, todayInTz, zonedDayBounds } from "./format";

export type RangeKey = "today" | "7d" | "30d" | "90d" | "all" | "custom";
export type DateRange = { key: RangeKey; from: string; to: string; label: string };

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function resolveRange(sp: Record<string, string | string[] | undefined>, tz: string, defaultKey = "30d"): DateRange {
  const today = todayInTz(tz);
  const raw = firstParam(sp.range) ?? defaultKey;
  const from = firstParam(sp.from);
  const to = firstParam(sp.to);
  if (raw === "custom" && from && to && DATE_RE.test(from) && DATE_RE.test(to) && from <= to) {
    return { key: "custom", from, to, label: "Custom range" };
  }
  switch (raw) {
    case "today":
      return { key: "today", from: today, to: today, label: "Today" };
    case "7d":
      return { key: "7d", from: addDays(today, -6), to: today, label: "Last 7 days" };
    case "90d":
      return { key: "90d", from: addDays(today, -89), to: today, label: "Last 90 days" };
    case "all":
      return { key: "all", from: "2000-01-01", to: today, label: "All time" };
    default:
      return { key: "30d", from: addDays(today, -29), to: today, label: "Last 30 days" };
  }
}

function rangeCondition(businessId: string, range: DateRange) {
  return and(
    eq(enquiries.businessId, businessId),
    gte(enquiries.enquiryDate, range.from),
    lte(enquiries.enquiryDate, range.to),
  );
}

export type StatusCounts = Record<EnquiryStatus, number>;

function emptyStatusCounts(): StatusCounts {
  return { new: 0, contacted: 0, interested: 0, follow_up_required: 0, converted: 0, lost: 0 };
}

export async function getDashboardStats(businessId: string, range: DateRange, tz: string) {
  const statusRows = await db
    .select({
      status: enquiries.status,
      count: count(),
      value: sql<string | null>`sum(${enquiries.estimatedValue})`,
    })
    .from(enquiries)
    .where(rangeCondition(businessId, range))
    .groupBy(enquiries.status);

  const byStatus = emptyStatusCounts();
  const valueByStatus = emptyStatusCounts();
  for (const r of statusRows) {
    byStatus[r.status] = r.count;
    valueByStatus[r.status] = Number(r.value ?? 0);
  }
  const total = Object.values(byStatus).reduce((a, b) => a + b, 0);
  const active = ACTIVE_STATUSES.reduce((a, s) => a + byStatus[s], 0);
  const pipelineValue = ACTIVE_STATUSES.reduce((a, s) => a + valueByStatus[s], 0);
  const wonValue = valueByStatus.converted;
  const conversionRate = total > 0 ? (byStatus.converted / total) * 100 : 0;
  const closed = byStatus.converted + byStatus.lost;
  const winRate = closed > 0 ? (byStatus.converted / closed) * 100 : 0;

  // Previous period for trend comparison
  const length = diffDays(range.from, range.to) + 1;
  const prevRange: DateRange = { key: range.key, from: addDays(range.from, -length), to: addDays(range.from, -1), label: "" };
  const prevRows =
    range.key === "all"
      ? []
      : await db
          .select({ status: enquiries.status, count: count() })
          .from(enquiries)
          .where(rangeCondition(businessId, prevRange))
          .groupBy(enquiries.status);
  const prevTotal = prevRows.reduce((a, r) => a + r.count, 0);
  const prevConverted = prevRows.find((r) => r.status === "converted")?.count ?? 0;

  const { start, end } = zonedDayBounds(tz);
  const [fu] = await db
    .select({
      due: sql<number>`count(*) filter (where ${followUps.dueAt} <= ${end})`.mapWith(Number),
      overdue: sql<number>`count(*) filter (where ${followUps.dueAt} < ${start})`.mapWith(Number),
      dueToday: sql<number>`count(*) filter (where ${followUps.dueAt} >= ${start} and ${followUps.dueAt} <= ${end})`.mapWith(Number),
      pending: count(),
    })
    .from(followUps)
    .where(and(eq(followUps.businessId, businessId), eq(followUps.status, "pending")));

  return {
    total,
    active,
    byStatus,
    valueByStatus,
    pipelineValue,
    wonValue,
    conversionRate,
    winRate,
    prevTotal,
    prevConverted,
    hasPrev: range.key !== "all",
    followUpsDue: fu?.due ?? 0,
    overdue: fu?.overdue ?? 0,
    dueToday: fu?.dueToday ?? 0,
    pendingFollowUps: fu?.pending ?? 0,
  };
}

export type DashboardStats = Awaited<ReturnType<typeof getDashboardStats>>;

export async function getMonthlyPerformance(businessId: string, tz: string, months = 6) {
  const list = lastNMonths(months, tz);
  const startMonth = `${list[0]}-01`;
  const startDate = new Date(`${startMonth}T00:00:00Z`);
  startDate.setUTCDate(startDate.getUTCDate() - 1); // small buffer for time zones

  const receivedExpr = sql<string>`to_char(${enquiries.enquiryDate}, 'YYYY-MM')`;
  const convertedExpr = sql<string>`to_char(${enquiries.convertedAt} at time zone ${tz}, 'YYYY-MM')`;
  const lostExpr = sql<string>`to_char(${enquiries.lostAt} at time zone ${tz}, 'YYYY-MM')`;

  const [received, converted, lost] = await Promise.all([
    db
      .select({ month: receivedExpr, n: count() })
      .from(enquiries)
      .where(and(eq(enquiries.businessId, businessId), gte(enquiries.enquiryDate, startMonth)))
      .groupBy(sql`1`),
    db
      .select({ month: convertedExpr, n: count() })
      .from(enquiries)
      .where(and(eq(enquiries.businessId, businessId), eq(enquiries.status, "converted"), gte(enquiries.convertedAt, startDate)))
      .groupBy(sql`1`),
    db
      .select({ month: lostExpr, n: count() })
      .from(enquiries)
      .where(and(eq(enquiries.businessId, businessId), eq(enquiries.status, "lost"), gte(enquiries.lostAt, startDate)))
      .groupBy(sql`1`),
  ]);

  const map = new Map(list.map((m) => [m, { month: m, label: monthLabel(m), received: 0, converted: 0, lost: 0, rate: 0 }]));
  for (const r of received) map.get(r.month) && (map.get(r.month)!.received = r.n);
  for (const r of converted) map.get(r.month) && (map.get(r.month)!.converted = r.n);
  for (const r of lost) map.get(r.month) && (map.get(r.month)!.lost = r.n);
  const rows = Array.from(map.values()).map((r) => ({
    ...r,
    rate: r.received > 0 ? Math.round((r.converted / r.received) * 1000) / 10 : 0,
  }));
  const last = rows[rows.length - 1];
  const prev = rows[rows.length - 2];
  const growth = prev && prev.received > 0 ? ((last.received - prev.received) / prev.received) * 100 : null;
  return { rows, growth, current: last, previous: prev };
}

export async function getDashboardCharts(businessId: string, range: DateRange, tz: string) {
  // Enquiries over time (daily, or weekly for long ranges)
  let from = range.from;
  if (range.key === "all") {
    const [minRow] = await db
      .select({ min: sql<string | null>`min(${enquiries.enquiryDate})` })
      .from(enquiries)
      .where(eq(enquiries.businessId, businessId));
    from = minRow?.min ?? addDays(range.to, -29);
    if (diffDays(from, range.to) < 13) from = addDays(range.to, -13);
  }
  const daily = await db
    .select({ day: enquiries.enquiryDate, n: count() })
    .from(enquiries)
    .where(and(eq(enquiries.businessId, businessId), gte(enquiries.enquiryDate, from), lte(enquiries.enquiryDate, range.to)))
    .groupBy(enquiries.enquiryDate);
  const dailyMap = new Map(daily.map((d) => [d.day, d.n]));
  const totalDays = diffDays(from, range.to) + 1;
  const weekly = totalDays > 92;
  const series: { label: string; date: string; count: number }[] = [];
  if (weekly) {
    let cursor = from;
    while (cursor <= range.to) {
      const weekEnd = addDays(cursor, 6);
      let sum = 0;
      for (let i = 0; i < 7; i++) sum += dailyMap.get(addDays(cursor, i)) ?? 0;
      series.push({ label: shortDate(cursor), date: cursor, count: sum });
      cursor = addDays(weekEnd, 1);
    }
  } else {
    for (let i = 0; i < totalDays; i++) {
      const d = addDays(from, i);
      series.push({ label: shortDate(d), date: d, count: dailyMap.get(d) ?? 0 });
    }
  }

  const [sourceRows, statusRows, monthly] = await Promise.all([
    db
      .select({ source: enquiries.source, n: count() })
      .from(enquiries)
      .where(rangeCondition(businessId, range))
      .groupBy(enquiries.source)
      .orderBy(desc(count())),
    db
      .select({ status: enquiries.status, n: count() })
      .from(enquiries)
      .where(rangeCondition(businessId, range))
      .groupBy(enquiries.status),
    getMonthlyPerformance(businessId, tz, 6),
  ]);

  const bySource = sourceRows.map((r, i) => ({ name: r.source, value: r.n, color: SOURCE_COLORS[i % SOURCE_COLORS.length] }));
  const byStatus = ENQUIRY_STATUSES.map((s) => ({
    name: s.label,
    value: statusRows.find((r) => r.status === s.value)?.n ?? 0,
    color: s.hex,
  }));

  return { overTime: series, weekly, bySource, byStatus, monthly: monthly.rows, growth: monthly.growth };
}

function shortDate(d: string) {
  const [, m, day] = d.split("-").map(Number);
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${day} ${months[m - 1]}`;
}

export async function getRecentActivity(businessId: string, limit = 10) {
  return db
    .select({
      log: activityLogs,
      userName: users.fullName,
      customerName: customers.fullName,
      enquiryTitle: enquiries.title,
    })
    .from(activityLogs)
    .leftJoin(enquiries, eq(enquiries.id, activityLogs.enquiryId))
    .leftJoin(customers, eq(customers.id, enquiries.customerId))
    .leftJoin(users, eq(users.id, activityLogs.userId))
    .where(eq(activityLogs.businessId, businessId))
    .orderBy(desc(activityLogs.createdAt))
    .limit(limit);
}

export async function getAnalyticsData(businessId: string, range: DateRange, tz: string) {
  const [stats, sourceRows, monthly, priorityRows, extra] = await Promise.all([
    getDashboardStats(businessId, range, tz),
    db
      .select({
        source: enquiries.source,
        total: count(),
        converted: sql<number>`count(*) filter (where ${enquiries.status} = 'converted')`.mapWith(Number),
        lost: sql<number>`count(*) filter (where ${enquiries.status} = 'lost')`.mapWith(Number),
        value: sql<string | null>`sum(${enquiries.estimatedValue}) filter (where ${enquiries.status} = 'converted')`,
      })
      .from(enquiries)
      .where(rangeCondition(businessId, range))
      .groupBy(enquiries.source)
      .orderBy(desc(count())),
    getMonthlyPerformance(businessId, tz, 12),
    db
      .select({ priority: enquiries.priority, n: count() })
      .from(enquiries)
      .where(rangeCondition(businessId, range))
      .groupBy(enquiries.priority),
    db
      .select({
        avgDealValue: sql<string | null>`avg(${enquiries.estimatedValue}) filter (where ${enquiries.status} = 'converted')`,
        avgDaysToConvert: sql<string | null>`avg((${enquiries.convertedAt} at time zone ${tz})::date - ${enquiries.enquiryDate}) filter (where ${enquiries.status} = 'converted')`,
        contactedWithin24h: sql<number>`count(*) filter (where ${enquiries.contactedAt} is not null and ${enquiries.contactedAt} <= ${enquiries.createdAt} + interval '24 hours')`.mapWith(Number),
        contactedTotal: sql<number>`count(*) filter (where ${enquiries.contactedAt} is not null)`.mapWith(Number),
      })
      .from(enquiries)
      .where(rangeCondition(businessId, range)),
  ]);

  const sources = sourceRows.map((r, i) => ({
    name: r.source,
    total: r.total,
    converted: r.converted,
    lost: r.lost,
    value: Number(r.value ?? 0),
    share: stats.total > 0 ? (r.total / stats.total) * 100 : 0,
    rate: r.total > 0 ? (r.converted / r.total) * 100 : 0,
    color: SOURCE_COLORS[i % SOURCE_COLORS.length],
  }));

  const priorities = priorityRows.map((p) => ({ priority: p.priority, n: p.n }));

  return {
    stats,
    sources,
    monthly: monthly.rows,
    growth: monthly.growth,
    priorities,
    avgDealValue: Number(extra[0]?.avgDealValue ?? 0),
    avgDaysToConvert: extra[0]?.avgDaysToConvert ? Number(extra[0].avgDaysToConvert) : null,
    contactedWithin24h: extra[0]?.contactedWithin24h ?? 0,
    contactedTotal: extra[0]?.contactedTotal ?? 0,
  };
}
