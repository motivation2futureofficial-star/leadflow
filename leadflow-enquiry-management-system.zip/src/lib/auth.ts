import "server-only";
import { cache } from "react";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { createHash, randomBytes, scrypt as scryptCb, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { and, eq, gt, lt } from "drizzle-orm";
import { db } from "@/db";
import { businesses, sessions, userPreferences, users, type Business, type UserPreferences } from "@/db/schema";

const scrypt = promisify(scryptCb) as (password: string, salt: string, keylen: number) => Promise<Buffer>;

export const SESSION_COOKIE = "leadflow_session";
const DAY_MS = 86_400_000;

export type AuthUser = { id: string; fullName: string; email: string; avatarUrl: string | null; createdAt: Date };
export type AuthContext = { user: AuthUser; business: Business; prefs: UserPreferences };

export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derived = await scrypt(password, salt, 64);
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [scheme, salt, hash] = stored.split(":");
  if (scheme !== "scrypt" || !salt || !hash) return false;
  const derived = await scrypt(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return expected.length === derived.length && timingSafeEqual(expected, derived);
}

export function sha256(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

export function generateToken() {
  return randomBytes(32).toString("hex");
}

async function isSecureRequest() {
  try {
    const h = await headers();
    const proto = h.get("x-forwarded-proto");
    if (proto) return proto.split(",")[0].trim() === "https";
    return false;
  } catch {
    return false;
  }
}

export async function createSession(userId: string, remember: boolean) {
  const token = generateToken();
  const expiresAt = new Date(Date.now() + (remember ? 30 * DAY_MS : DAY_MS));
  await db.insert(sessions).values({ id: sha256(token), userId, remember, expiresAt });
  // Opportunistic cleanup of expired sessions.
  await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: await isSecureRequest(),
    path: "/",
    ...(remember ? { expires: expiresAt } : {}),
  });
}

export async function destroySession() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.id, sha256(token)));
  }
  store.delete(SESSION_COOKIE);
}

export async function deleteAllUserSessions(userId: string) {
  await db.delete(sessions).where(eq(sessions.userId, userId));
}

export function defaultPreferences(userId: string): UserPreferences {
  return {
    userId,
    dateFormat: "DD/MM/YYYY",
    timeZone: "UTC",
    currency: "USD",
    defaultDateRange: "30d",
    notifyNewEnquiry: true,
    notifyUpcoming: true,
    notifyDueToday: true,
    notifyOverdue: true,
    notifyConversions: true,
    reminderLeadHours: 24,
    updatedAt: new Date(),
  };
}

export const getCurrentUser = cache(async (): Promise<AuthContext | null> => {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users, business: businesses, prefs: userPreferences })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .leftJoin(businesses, eq(businesses.ownerId, users.id))
    .leftJoin(userPreferences, eq(userPreferences.userId, users.id))
    .where(and(eq(sessions.id, sha256(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  const row = rows[0];
  if (!row || !row.business) return null;
  return {
    user: {
      id: row.user.id,
      fullName: row.user.fullName,
      email: row.user.email,
      avatarUrl: row.user.avatarUrl,
      createdAt: row.user.createdAt,
    },
    business: row.business,
    prefs: row.prefs ?? defaultPreferences(row.user.id),
  };
});

/** Server components / actions: redirects to login (or onboarding) when needed. */
export async function requireUser(opts: { allowOnboarding?: boolean } = {}): Promise<AuthContext> {
  const ctx = await getCurrentUser();
  if (!ctx) redirect("/login");
  if (!ctx.business.onboardingCompleted && !opts.allowOnboarding) redirect("/onboarding");
  return ctx;
}

/** API routes: returns null instead of redirecting. */
export async function requireApiUser(): Promise<AuthContext | null> {
  const ctx = await getCurrentUser();
  if (!ctx || !ctx.business.onboardingCompleted) return null;
  return ctx;
}
