export const APP_NAME = "LeadFlow";

export const ENQUIRY_STATUSES = [
  { value: "new", label: "New", badge: "bg-blue-50 text-blue-700 ring-blue-600/20", dot: "bg-blue-500", hex: "#3b82f6" },
  { value: "contacted", label: "Contacted", badge: "bg-sky-50 text-sky-700 ring-sky-600/20", dot: "bg-sky-500", hex: "#0ea5e9" },
  { value: "interested", label: "Interested", badge: "bg-violet-50 text-violet-700 ring-violet-600/20", dot: "bg-violet-500", hex: "#8b5cf6" },
  { value: "follow_up_required", label: "Follow-up Required", badge: "bg-amber-50 text-amber-700 ring-amber-600/20", dot: "bg-amber-500", hex: "#f59e0b" },
  { value: "converted", label: "Converted", badge: "bg-emerald-50 text-emerald-700 ring-emerald-600/20", dot: "bg-emerald-500", hex: "#10b981" },
  { value: "lost", label: "Lost", badge: "bg-red-50 text-red-700 ring-red-600/20", dot: "bg-red-500", hex: "#ef4444" },
] as const;

export type EnquiryStatus = (typeof ENQUIRY_STATUSES)[number]["value"];
export const STATUS_VALUES = ENQUIRY_STATUSES.map((s) => s.value) as [EnquiryStatus, ...EnquiryStatus[]];
export const ACTIVE_STATUSES: EnquiryStatus[] = ["new", "contacted", "interested", "follow_up_required"];

export function statusMeta(value: string) {
  return ENQUIRY_STATUSES.find((s) => s.value === value) ?? ENQUIRY_STATUSES[0];
}

export function isStatus(value: unknown): value is EnquiryStatus {
  return typeof value === "string" && (STATUS_VALUES as string[]).includes(value);
}

export const PRIORITIES = [
  { value: "low", label: "Low", badge: "bg-slate-100 text-slate-600 ring-slate-500/20", hex: "#94a3b8" },
  { value: "medium", label: "Medium", badge: "bg-blue-50 text-blue-700 ring-blue-600/20", hex: "#3b82f6" },
  { value: "high", label: "High", badge: "bg-orange-50 text-orange-700 ring-orange-600/20", hex: "#f97316" },
  { value: "urgent", label: "Urgent", badge: "bg-red-50 text-red-700 ring-red-600/20", hex: "#ef4444" },
] as const;

export type Priority = (typeof PRIORITIES)[number]["value"];
export const PRIORITY_VALUES = PRIORITIES.map((p) => p.value) as [Priority, ...Priority[]];

export function priorityMeta(value: string) {
  return PRIORITIES.find((p) => p.value === value) ?? PRIORITIES[1];
}

export function isPriority(value: unknown): value is Priority {
  return typeof value === "string" && (PRIORITY_VALUES as string[]).includes(value);
}

export const DEFAULT_SOURCES = [
  "Website",
  "Instagram",
  "Facebook",
  "WhatsApp",
  "Google Ads",
  "Referral",
  "Phone Call",
  "Walk-in",
  "Other",
];

export const SOURCE_COLORS = [
  "#2563eb",
  "#ec4899",
  "#1d4ed8",
  "#22c55e",
  "#f59e0b",
  "#8b5cf6",
  "#0ea5e9",
  "#14b8a6",
  "#94a3b8",
  "#f97316",
  "#a855f7",
  "#64748b",
];

export const BUSINESS_CATEGORIES = [
  "Digital Marketing Agency",
  "Real Estate",
  "Coaching / Training Institute",
  "Educational Consultancy",
  "Freelance / Consulting",
  "Home & Repair Services",
  "Healthcare & Wellness",
  "Retail & E-commerce",
  "Software & IT Services",
  "Finance & Accounting",
  "Events & Photography",
  "Travel & Hospitality",
  "Other",
];

export const BUSINESS_SIZES = ["Just me", "2-5 people", "6-20 people", "21-50 people", "51-200 people", "200+ people"];

export const DATE_FORMATS = ["DD/MM/YYYY", "MM/DD/YYYY", "YYYY-MM-DD", "DD MMM YYYY", "MMM D, YYYY"];

export const CURRENCIES = ["USD", "EUR", "GBP", "INR", "AED", "AUD", "CAD", "SGD", "ZAR", "NGN", "KES", "PHP", "MYR", "JPY"];

export const TIME_ZONES = [
  "UTC",
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "America/Toronto",
  "America/Vancouver",
  "America/Mexico_City",
  "America/Sao_Paulo",
  "Europe/London",
  "Europe/Dublin",
  "Europe/Paris",
  "Europe/Berlin",
  "Europe/Madrid",
  "Europe/Rome",
  "Europe/Amsterdam",
  "Europe/Istanbul",
  "Africa/Cairo",
  "Africa/Lagos",
  "Africa/Nairobi",
  "Africa/Johannesburg",
  "Asia/Dubai",
  "Asia/Karachi",
  "Asia/Kolkata",
  "Asia/Dhaka",
  "Asia/Bangkok",
  "Asia/Jakarta",
  "Asia/Singapore",
  "Asia/Kuala_Lumpur",
  "Asia/Manila",
  "Asia/Hong_Kong",
  "Asia/Shanghai",
  "Asia/Tokyo",
  "Asia/Seoul",
  "Australia/Perth",
  "Australia/Sydney",
  "Australia/Melbourne",
  "Pacific/Auckland",
];

export const DATE_RANGE_OPTIONS = [
  { value: "today", label: "Today" },
  { value: "7d", label: "Last 7 days" },
  { value: "30d", label: "Last 30 days" },
  { value: "90d", label: "Last 90 days" },
  { value: "all", label: "All time" },
];

export const ACTIVITY_LABELS: Record<string, string> = {
  enquiry_created: "Enquiry created",
  enquiry_updated: "Enquiry updated",
  enquiry_deleted: "Enquiry deleted",
  status_changed: "Status changed",
  contacted: "Customer contacted",
  follow_up_scheduled: "Follow-up scheduled",
  follow_up_completed: "Follow-up completed",
  follow_up_rescheduled: "Follow-up rescheduled",
  follow_up_cancelled: "Follow-up cancelled",
  note_added: "Note added",
  note_updated: "Note updated",
  note_deleted: "Note deleted",
  converted: "Customer converted",
  lost: "Enquiry marked as lost",
};

export const FOLLOW_UP_TIME_PRESETS = ["09:00", "10:00", "11:00", "12:00", "14:00", "15:00", "16:00", "17:00"];
