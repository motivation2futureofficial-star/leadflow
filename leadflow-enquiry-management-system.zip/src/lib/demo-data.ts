import "server-only";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  activityLogs,
  businesses,
  customers,
  enquiries,
  enquirySources,
  followUps,
  notes,
  notifications,
} from "@/db/schema";
import type { EnquiryStatus, Priority } from "./constants";
import { statusMeta } from "./constants";
import { addDays, makeZonedDate, pad, todayInTz } from "./format";

type DemoFollowUp = {
  title: string;
  day: number;
  hour: number;
  priority: Priority;
  status?: "pending" | "completed" | "cancelled";
  completedDay?: number;
  completionNotes?: string;
  description?: string;
};

type DemoEnquiry = {
  customer: string;
  title: string;
  description: string;
  source: string;
  productService: string;
  day: number;
  priority: Priority;
  status: EnquiryStatus;
  value: number | null;
  assignedTo?: string;
  contactedDay?: number;
  interestedDay?: number;
  convertedDay?: number;
  lostDay?: number;
  lostReason?: string;
  notes?: { text: string; day: number }[];
  followUps?: DemoFollowUp[];
};

const DEMO_CUSTOMERS = [
  { key: "priya", fullName: "Priya Sharma", phone: "+91 98765 43210", email: "priya.sharma@example.com", company: null },
  { key: "daniel", fullName: "Daniel Okafor", phone: "+44 7700 900123", email: "daniel@okaforstudio.co.uk", company: "Okafor Studio" },
  { key: "maria", fullName: "Maria Gonzalez", phone: "+1 (305) 555-0142", email: "maria.g@brightbakery.com", company: "Bright Bakery" },
  { key: "arjun", fullName: "Arjun Mehta", phone: "+91 91234 56789", email: "arjun.mehta@example.com", company: null },
  { key: "sophie", fullName: "Sophie Turner", phone: "+61 412 345 678", email: "sophie.turner@example.com", company: null },
  { key: "liam", fullName: "Liam Chen", phone: "+65 8123 4567", email: "liam.chen@novatrade.sg", company: "NovaTrade Pte Ltd" },
  { key: "fatima", fullName: "Fatima Al-Sayed", phone: "+971 50 123 4567", email: "fatima.alsayed@example.com", company: null },
  { key: "james", fullName: "James Wilson", phone: "+1 (212) 555-0199", email: "dr.wilson@smilecaredental.com", company: "SmileCare Dental" },
  { key: "aisha", fullName: "Aisha Khan", phone: "+92 300 1234567", email: "aisha.khan@example.com", company: null },
  { key: "carlos", fullName: "Carlos Rivera", phone: "+34 612 345 678", email: "carlos@riveraoffices.es", company: "Rivera Offices" },
  { key: "emily", fullName: "Emily Johnson", phone: "+1 (415) 555-0133", email: "emily.johnson@example.com", company: null },
  { key: "noah", fullName: "Noah Patel", phone: "+1 (647) 555-0177", email: "noah@patellogistics.ca", company: "Patel Logistics" },
  { key: "olivia", fullName: "Olivia Brown", phone: "+44 7911 123456", email: "olivia.brown@example.com", company: null },
  { key: "hiroshi", fullName: "Hiroshi Tanaka", phone: "+81 90-1234-5678", email: "h.tanaka@tanaka-industrial.jp", company: "Tanaka Industrial" },
  { key: "grace", fullName: "Grace Mwangi", phone: "+254 712 345678", email: "grace@mwangiboutique.co.ke", company: "Mwangi Boutique" },
  { key: "tom", fullName: "Tom Becker", phone: "+49 151 23456789", email: "tom.becker@example.com", company: "Becker Consulting" },
];

const DEMO_ENQUIRIES: DemoEnquiry[] = [
  {
    customer: "priya",
    title: "Wedding photography package",
    description: "Looking for a full-day wedding photography package for a December wedding with around 250 guests. Interested in a pre-wedding shoot add-on.",
    source: "Instagram",
    productService: "Premium Wedding Package",
    day: -3,
    priority: "high",
    status: "interested",
    value: 2500,
    assignedTo: "Sam Lee",
    contactedDay: -2,
    interestedDay: -1,
    notes: [{ text: "Loved the portfolio. Comparing two other studios, decision expected within a week.", day: -1 }],
    followUps: [{ title: "Send final quote with pre-wedding add-on", day: 1, hour: 11, priority: "high", description: "Include the 2 photographer option and album upgrade pricing." }],
  },
  {
    customer: "daniel",
    title: "Website redesign quote",
    description: "Current website is 5 years old and not mobile friendly. Wants a modern redesign with an online booking feature.",
    source: "Website",
    productService: "Website Redesign",
    day: -1,
    priority: "medium",
    status: "new",
    value: 4800,
    followUps: [{ title: "Discovery call", day: 0, hour: 15, priority: "medium", description: "30 minute intro call to understand requirements." }],
  },
  {
    customer: "maria",
    title: "Monthly bookkeeping services",
    description: "Bakery with two locations needs monthly bookkeeping and quarterly tax prep.",
    source: "Referral",
    productService: "Bookkeeping Retainer",
    day: -6,
    priority: "medium",
    status: "contacted",
    value: 1200,
    assignedTo: "Alex Morgan",
    contactedDay: -5,
    followUps: [{ title: "Follow up on proposal", day: -2, hour: 10, priority: "medium", description: "Proposal sent 4 days ago, no reply yet." }],
  },
  {
    customer: "arjun",
    title: "IELTS coaching enrollment",
    description: "Needs band 7.5 for Canadian PR application. Prefers weekend batches.",
    source: "Google Ads",
    productService: "IELTS Weekend Batch",
    day: -9,
    priority: "high",
    status: "follow_up_required",
    value: 650,
    contactedDay: -8,
    notes: [{ text: "Asked for a demo class. Scheduled for Saturday but did not show up.", day: -5 }],
    followUps: [{ title: "Reschedule demo class", day: -4, hour: 12, priority: "high" }],
  },
  {
    customer: "sophie",
    title: "Home interior consultation",
    description: "Renovating a 3 bedroom house. Wants full interior design for living room and kitchen.",
    source: "Facebook",
    productService: "Full Home Interior",
    day: -25,
    priority: "medium",
    status: "converted",
    value: 7500,
    assignedTo: "Sam Lee",
    contactedDay: -24,
    interestedDay: -20,
    convertedDay: -10,
    notes: [{ text: "Signed the agreement and paid 30% deposit.", day: -10 }],
    followUps: [{ title: "Site visit and measurements", day: -18, hour: 10, priority: "high", status: "completed", completedDay: -18, completionNotes: "Measurements done, mood board shared." }],
  },
  {
    customer: "liam",
    title: "Bulk order of corporate gifts",
    description: "200 branded gift boxes for a year-end client event.",
    source: "WhatsApp",
    productService: "Corporate Gift Boxes",
    day: -30,
    priority: "low",
    status: "lost",
    value: 900,
    contactedDay: -29,
    lostDay: -22,
    lostReason: "Chose a competitor with lower pricing",
  },
  {
    customer: "fatima",
    title: "2BHK apartment viewing",
    description: "Looking for a 2 bedroom apartment near the marina, budget up to 180k, ready to move within 2 months.",
    source: "Walk-in",
    productService: "Marina Heights – 2BHK",
    day: -2,
    priority: "urgent",
    status: "interested",
    value: 180000,
    assignedTo: "Alex Morgan",
    contactedDay: -2,
    interestedDay: -1,
    followUps: [{ title: "Second viewing with spouse", day: 0, hour: 17, priority: "urgent", description: "Bring floor plans and payment plan options." }],
  },
  {
    customer: "james",
    title: "SEO retainer for dental clinic",
    description: "Wants to rank for local dental keywords and improve Google Business profile.",
    source: "Phone Call",
    productService: "Local SEO Retainer",
    day: -4,
    priority: "medium",
    status: "contacted",
    value: 1500,
    contactedDay: -3,
    followUps: [{ title: "Share SEO audit report", day: 3, hour: 10, priority: "medium" }],
  },
  {
    customer: "aisha",
    title: "Bridal makeup trial",
    description: "Wedding in 6 weeks, wants a trial session before booking.",
    source: "Instagram",
    productService: "Bridal Makeup",
    day: 0,
    priority: "low",
    status: "new",
    value: 300,
  },
  {
    customer: "carlos",
    title: "Commercial cleaning contract",
    description: "Three office floors, nightly cleaning five days a week.",
    source: "Website",
    productService: "Commercial Cleaning Contract",
    day: -12,
    priority: "high",
    status: "follow_up_required",
    value: 3600,
    assignedTo: "Sam Lee",
    contactedDay: -11,
    notes: [{ text: "Facilities manager wants references from similar sized offices.", day: -7 }],
    followUps: [{ title: "Send client references", day: 5, hour: 9, priority: "high" }],
  },
  {
    customer: "emily",
    title: "Career counselling session",
    description: "Recent graduate exploring a switch into UX design.",
    source: "Referral",
    productService: "Career Counselling",
    day: -40,
    priority: "low",
    status: "converted",
    value: 150,
    contactedDay: -39,
    convertedDay: -35,
  },
  {
    customer: "noah",
    title: "Custom CRM development",
    description: "Logistics company needs a custom shipment tracking CRM integrated with their accounting system.",
    source: "Google Ads",
    productService: "Custom Software Development",
    day: -7,
    priority: "urgent",
    status: "interested",
    value: 15000,
    assignedTo: "Alex Morgan",
    contactedDay: -6,
    interestedDay: -3,
    notes: [{ text: "Technical requirements document received. Needs a proposal by end of next week.", day: -3 }],
    followUps: [{ title: "Present proposal and timeline", day: 1, hour: 14, priority: "urgent" }],
  },
  {
    customer: "olivia",
    title: "Yoga studio membership",
    description: "Interested in a 3 month unlimited membership.",
    source: "Facebook",
    productService: "3-Month Membership",
    day: -50,
    priority: "low",
    status: "lost",
    value: 80,
    contactedDay: -49,
    lostDay: -45,
    lostReason: "No longer interested",
  },
  {
    customer: "daniel",
    title: "Ongoing website maintenance",
    description: "Monthly maintenance plan for plugin updates, backups and minor content changes.",
    source: "Website",
    productService: "Maintenance Plan",
    day: -60,
    priority: "medium",
    status: "converted",
    value: 1800,
    contactedDay: -59,
    convertedDay: -55,
  },
  {
    customer: "hiroshi",
    title: "Industrial equipment demo",
    description: "Evaluating our packaging line for a new plant. Wants an on-site demo and a formal quotation.",
    source: "Trade Show",
    productService: "Packaging Line PL-400",
    day: -15,
    priority: "high",
    status: "contacted",
    value: 42000,
    assignedTo: "Sam Lee",
    contactedDay: -14,
    followUps: [{ title: "Confirm on-site demo date", day: -1, hour: 9, priority: "high" }],
  },
  {
    customer: "grace",
    title: "Social media management",
    description: "Boutique wants Instagram and Facebook management with 3 posts per week.",
    source: "WhatsApp",
    productService: "Social Media Starter",
    day: -2,
    priority: "medium",
    status: "new",
    value: 950,
  },
  {
    customer: "priya",
    title: "Pre-wedding shoot add-on",
    description: "Separate enquiry about a destination pre-wedding shoot in Goa.",
    source: "Instagram",
    productService: "Pre-Wedding Shoot",
    day: -1,
    priority: "low",
    status: "new",
    value: 600,
  },
  {
    customer: "tom",
    title: "Tax filing for small business",
    description: "Annual tax filing and advisory for a one-person consulting company.",
    source: "Referral",
    productService: "Annual Tax Filing",
    day: -75,
    priority: "medium",
    status: "converted",
    value: 400,
    contactedDay: -74,
    convertedDay: -70,
  },
];

export async function seedDemoData(businessId: string, userId: string, tz: string) {
  const today = todayInTz(tz);
  const dayStr = (offset: number) => addDays(today, offset);
  const at = (offset: number, hour = 10, minute = 0) => makeZonedDate(dayStr(offset), `${pad(hour)}:${pad(minute)}`, tz);
  const now = new Date();
  const clamp = (d: Date) => (d.getTime() > now.getTime() ? new Date(now.getTime() - 60_000) : d);

  await db.transaction(async (tx) => {
    const insertedCustomers = await tx
      .insert(customers)
      .values(
        DEMO_CUSTOMERS.map((c, i) => ({
          businessId,
          fullName: c.fullName,
          phone: c.phone,
          email: c.email,
          company: c.company,
          isDemo: true,
          createdAt: clamp(at(-80 + i * 2, 9)),
          updatedAt: clamp(at(-80 + i * 2, 9)),
        })),
      )
      .returning({ id: customers.id, email: customers.email });
    const customerIdByKey = new Map<string, string>();
    DEMO_CUSTOMERS.forEach((c) => {
      const row = insertedCustomers.find((r) => r.email === c.email);
      if (row) customerIdByKey.set(c.key, row.id);
    });

    await tx
      .insert(enquirySources)
      .values({ businessId, name: "Trade Show", isCustom: true, isDemo: true })
      .onConflictDoNothing();

    const enquiryValues = DEMO_ENQUIRIES.map((e, i) => {
      const createdAt = clamp(at(e.day, 9 + (i % 7), (i * 7) % 60));
      return {
        businessId,
        customerId: customerIdByKey.get(e.customer)!,
        title: e.title,
        description: e.description,
        source: e.source,
        productService: e.productService,
        enquiryDate: dayStr(e.day),
        assignedTo: e.assignedTo ?? null,
        status: e.status,
        priority: e.priority,
        estimatedValue: e.value === null ? null : e.value.toFixed(2),
        lostReason: e.lostReason ?? null,
        contactedAt: e.contactedDay !== undefined ? clamp(at(e.contactedDay, 11)) : null,
        convertedAt: e.convertedDay !== undefined ? clamp(at(e.convertedDay, 16)) : null,
        lostAt: e.lostDay !== undefined ? clamp(at(e.lostDay, 15)) : null,
        isDemo: true,
        createdAt,
        updatedAt: createdAt,
      };
    });
    const insertedEnquiries = await tx.insert(enquiries).values(enquiryValues).returning({ id: enquiries.id, title: enquiries.title });
    const enquiryIdByIndex = DEMO_ENQUIRIES.map((e) => insertedEnquiries.find((r) => r.title === e.title)!.id);

    const activityValues: (typeof activityLogs.$inferInsert)[] = [];
    const followUpValues: (typeof followUps.$inferInsert)[] = [];
    const noteValues: (typeof notes.$inferInsert)[] = [];

    DEMO_ENQUIRIES.forEach((e, i) => {
      const enquiryId = enquiryIdByIndex[i];
      const createdAt = enquiryValues[i].createdAt;
      const base = { businessId, enquiryId, userId, isDemo: true };
      activityValues.push({ ...base, type: "enquiry_created", description: `Enquiry "${e.title}" received via ${e.source}`, createdAt });

      let previous: EnquiryStatus = "new";
      const transition = (to: EnquiryStatus, when: Date) => {
        activityValues.push({
          ...base,
          type: to === "converted" ? "converted" : to === "lost" ? "lost" : "status_changed",
          description:
            to === "converted"
              ? "Enquiry marked as converted — customer won"
              : to === "lost"
                ? `Enquiry marked as lost: ${e.lostReason ?? "No reason provided"}`
                : `Status changed from ${statusMeta(previous).label} to ${statusMeta(to).label}`,
          metadata: { from: previous, to },
          createdAt: when,
        });
        previous = to;
      };

      if (e.contactedDay !== undefined) {
        activityValues.push({ ...base, type: "contacted", description: "Customer contacted by phone", createdAt: clamp(at(e.contactedDay, 11)) });
        transition("contacted", clamp(at(e.contactedDay, 11, 5)));
      }
      if (e.interestedDay !== undefined) transition("interested", clamp(at(e.interestedDay, 12)));
      if (e.status === "follow_up_required") transition("follow_up_required", clamp(at(e.day + 2, 13)));
      if (e.convertedDay !== undefined) transition("converted", clamp(at(e.convertedDay, 16)));
      if (e.lostDay !== undefined) transition("lost", clamp(at(e.lostDay, 15)));

      for (const n of e.notes ?? []) {
        const when = clamp(at(n.day, 14));
        noteValues.push({ businessId, enquiryId, authorId: userId, content: n.text, isDemo: true, createdAt: when, updatedAt: when });
        activityValues.push({ ...base, type: "note_added", description: `Note added: "${n.text.slice(0, 60)}${n.text.length > 60 ? "…" : ""}"`, createdAt: when });
      }

      for (const f of e.followUps ?? []) {
        const dueAt = at(f.day, f.hour);
        const scheduledAt = clamp(at(Math.min(f.day - 1, e.day), 10, 30));
        const completed = f.status === "completed";
        const completedAt = completed ? clamp(at(f.completedDay ?? f.day, f.hour + 1)) : null;
        followUpValues.push({
          businessId,
          enquiryId,
          title: f.title,
          description: f.description ?? null,
          dueAt,
          priority: f.priority,
          status: f.status ?? "pending",
          completedAt,
          completionNotes: f.completionNotes ?? null,
          createdById: userId,
          isDemo: true,
          createdAt: scheduledAt,
          updatedAt: completedAt ?? scheduledAt,
        });
        activityValues.push({ ...base, type: "follow_up_scheduled", description: `Follow-up scheduled: "${f.title}"`, createdAt: scheduledAt });
        if (completed && completedAt) {
          activityValues.push({ ...base, type: "follow_up_completed", description: `Follow-up completed: "${f.title}"${f.completionNotes ? ` — ${f.completionNotes}` : ""}`, createdAt: completedAt });
        }
      }
    });

    if (followUpValues.length) await tx.insert(followUps).values(followUpValues);
    if (noteValues.length) await tx.insert(notes).values(noteValues);
    if (activityValues.length) await tx.insert(activityLogs).values(activityValues);

    const newest = DEMO_ENQUIRIES.map((e, i) => ({ e, i })).filter(({ e }) => e.status === "new").slice(0, 2);
    const notificationValues: (typeof notifications.$inferInsert)[] = newest.map(({ e, i }) => ({
      businessId,
      userId,
      type: "new_enquiry",
      title: "New enquiry added",
      message: `${DEMO_CUSTOMERS.find((c) => c.key === e.customer)?.fullName} enquired about "${e.title}" via ${e.source}.`,
      link: `/enquiries/${enquiryIdByIndex[i]}`,
      dedupeKey: `demo:new:${enquiryIdByIndex[i]}`,
      isDemo: true,
      createdAt: enquiryValues[i].createdAt,
    }));
    const sophieIndex = DEMO_ENQUIRIES.findIndex((e) => e.customer === "sophie");
    notificationValues.push({
      businessId,
      userId,
      type: "enquiry_converted",
      title: "Enquiry converted 🎉",
      message: `Sophie Turner became a customer — "Home interior consultation".`,
      link: `/enquiries/${enquiryIdByIndex[sophieIndex]}`,
      dedupeKey: `demo:converted:${enquiryIdByIndex[sophieIndex]}`,
      isDemo: true,
      isRead: true,
      createdAt: enquiryValues[sophieIndex].convertedAt ?? now,
    });
    await tx.insert(notifications).values(notificationValues).onConflictDoNothing();

    await tx.update(businesses).set({ demoSeededAt: now, updatedAt: now }).where(eq(businesses.id, businessId));
  });
}

export async function removeDemoData(businessId: string) {
  await db.transaction(async (tx) => {
    await tx.delete(notifications).where(and(eq(notifications.businessId, businessId), eq(notifications.isDemo, true)));
    await tx.delete(activityLogs).where(and(eq(activityLogs.businessId, businessId), eq(activityLogs.isDemo, true)));
    await tx.delete(notes).where(and(eq(notes.businessId, businessId), eq(notes.isDemo, true)));
    await tx.delete(followUps).where(and(eq(followUps.businessId, businessId), eq(followUps.isDemo, true)));
    await tx.delete(enquiries).where(and(eq(enquiries.businessId, businessId), eq(enquiries.isDemo, true)));
    await tx.delete(customers).where(and(eq(customers.businessId, businessId), eq(customers.isDemo, true)));
    await tx.delete(enquirySources).where(and(eq(enquirySources.businessId, businessId), eq(enquirySources.isDemo, true)));
    await tx
      .update(businesses)
      .set({ demoRemovedAt: new Date(), updatedAt: new Date() })
      .where(eq(businesses.id, businessId));
  });
}
