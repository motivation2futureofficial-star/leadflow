import "server-only";
import { headers } from "next/headers";

/**
 * Transactional email via Resend's REST API. Only active when RESEND_API_KEY and
 * EMAIL_FROM are configured. We never pretend an email was sent when it was not.
 */
export function isEmailConfigured() {
  return Boolean(process.env.RESEND_API_KEY && process.env.EMAIL_FROM);
}

export async function sendEmail(input: { to: string; subject: string; html: string }) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!key || !from) return false;
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: input.to, subject: input.subject, html: input.html }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function getAppOrigin() {
  if (process.env.APP_URL) return process.env.APP_URL.replace(/\/$/, "");
  try {
    const h = await headers();
    const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
    const proto = h.get("x-forwarded-proto")?.split(",")[0].trim() ?? "http";
    return `${proto}://${host}`;
  } catch {
    return "http://localhost:3000";
  }
}
