import "server-only";
import { randomUUID } from "node:crypto";
import { and, eq, lte } from "drizzle-orm";
import { db } from "@/db";
import { activityLogs, customers, enquiries, followUps, notifications, type UserPreferences } from "@/db/schema";
import { zonedDayBounds } from "./format";

export async function logActivity(input: {
  businessId: string;
  enquiryId?: string | null;
  userId?: string | null;
  type: string;
  description: string;
  metadata?: Record<string, unknown>;
  isDemo?: boolean;
}) {
  await db.insert(activityLogs).values({
    businessId: input.businessId,
    enquiryId: input.enquiryId ?? null,
    userId: input.userId ?? null,
    type: input.type,
    description: input.description,
    metadata: input.metadata ?? null,
    isDemo: input.isDemo ?? false,
  });
}

export async function createNotification(input: {
  businessId: string;
  userId: string;
  type: string;
  title: string;
  message: string;
  link?: string | null;
  dedupeKey?: string;
  isDemo?: boolean;
}) {
  await db
    .insert(notifications)
    .values({
      businessId: input.businessId,
      userId: input.userId,
      type: input.type,
      title: input.title,
      message: input.message,
      link: input.link ?? null,
      dedupeKey: input.dedupeKey ?? randomUUID(),
      isDemo: input.isDemo ?? false,
    })
    .onConflictDoNothing({ target: [notifications.userId, notifications.dedupeKey] });
}

/**
 * Generates in-app reminder notifications for pending follow-ups that are
 * upcoming (within the user's lead window), due today, or overdue.
 * Idempotent thanks to dedupe keys, so it is safe to run on every request.
 */
export async function syncFollowUpNotifications(businessId: string, userId: string, prefs: UserPreferences) {
  if (!prefs.notifyUpcoming && !prefs.notifyDueToday && !prefs.notifyOverdue) return;
  const now = new Date();
  const { start, end } = zonedDayBounds(prefs.timeZone, now);
  const leadMs = Math.max(1, prefs.reminderLeadHours) * 3_600_000;
  const horizon = new Date(Math.max(end.getTime(), now.getTime() + leadMs));

  const rows = await db
    .select({
      id: followUps.id,
      title: followUps.title,
      dueAt: followUps.dueAt,
      enquiryId: followUps.enquiryId,
      isDemo: followUps.isDemo,
      customerName: customers.fullName,
    })
    .from(followUps)
    .innerJoin(enquiries, eq(enquiries.id, followUps.enquiryId))
    .innerJoin(customers, eq(customers.id, enquiries.customerId))
    .where(and(eq(followUps.businessId, businessId), eq(followUps.status, "pending"), lte(followUps.dueAt, horizon)));

  if (rows.length === 0) return;

  const values: (typeof notifications.$inferInsert)[] = [];
  for (const r of rows) {
    const due = r.dueAt.getTime();
    let kind: "overdue" | "due_today" | "upcoming";
    if (due < start.getTime()) kind = "overdue";
    else if (due <= end.getTime()) kind = "due_today";
    else kind = "upcoming";

    if (kind === "overdue" && !prefs.notifyOverdue) continue;
    if (kind === "due_today" && !prefs.notifyDueToday) continue;
    if (kind === "upcoming" && !prefs.notifyUpcoming) continue;

    const titles = {
      overdue: "Follow-up overdue",
      due_today: "Follow-up due today",
      upcoming: "Follow-up coming up",
    } as const;
    const messages = {
      overdue: `"${r.title}" for ${r.customerName} is overdue.`,
      due_today: `"${r.title}" for ${r.customerName} is due today.`,
      upcoming: `"${r.title}" for ${r.customerName} is due soon.`,
    } as const;

    values.push({
      businessId,
      userId,
      type: `follow_up_${kind}`,
      title: titles[kind],
      message: messages[kind],
      link: `/enquiries/${r.enquiryId}`,
      dedupeKey: `fu:${r.id}:${kind}`,
      isDemo: r.isDemo,
    });
  }

  if (values.length === 0) return;
  await db
    .insert(notifications)
    .values(values)
    .onConflictDoNothing({ target: [notifications.userId, notifications.dedupeKey] });
}

/** Marks reminder notifications for a follow-up as read (e.g. after completion). */
export async function resolveFollowUpNotifications(userId: string, followUpId: string) {
  for (const kind of ["overdue", "due_today", "upcoming"]) {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(and(eq(notifications.userId, userId), eq(notifications.dedupeKey, `fu:${followUpId}:${kind}`)));
  }
}

/** Removes reminder notifications for a follow-up (e.g. after rescheduling) so new ones can be generated. */
export async function clearFollowUpNotifications(userId: string, followUpId: string) {
  for (const kind of ["overdue", "due_today", "upcoming"]) {
    await db
      .delete(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.dedupeKey, `fu:${followUpId}:${kind}`)));
  }
}
