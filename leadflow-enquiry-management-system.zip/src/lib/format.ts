export type FormatPrefs = { dateFormat: string; timeZone: string; currency?: string };

const MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function pad(n: number) {
  return String(n).padStart(2, "0");
}

export function safeTz(tz?: string | null) {
  if (!tz) return "UTC";
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return tz;
  } catch {
    return "UTC";
  }
}

function dateParts(date: Date, tz: string) {
  const f = new Intl.DateTimeFormat("en-US", {
    timeZone: safeTz(tz),
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const map: Record<string, string> = {};
  for (const p of f.formatToParts(date)) map[p.type] = p.value;
  const h = Number(map.hour);
  return {
    y: Number(map.year),
    m: Number(map.month),
    d: Number(map.day),
    h: h === 24 ? 0 : h,
    mi: Number(map.minute),
    s: Number(map.second),
  };
}

/** Offset (ms) between the wall clock in `tz` and UTC at the given instant. */
export function tzOffsetMs(tz: string, date: Date) {
  const p = dateParts(date, tz);
  const asUtc = Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi, p.s);
  return asUtc - Math.floor(date.getTime() / 1000) * 1000;
}

/** Today's calendar date (YYYY-MM-DD) in the given time zone. */
export function todayInTz(tz: string, now = new Date()) {
  const p = dateParts(now, tz);
  return `${p.y}-${pad(p.m)}-${pad(p.d)}`;
}

/** Build a UTC instant from a wall-clock date/time in `tz`. */
export function makeZonedDate(dateStr: string, timeStr: string | undefined | null, tz: string) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const [hh, mm] = (timeStr && /^\d{2}:\d{2}/.test(timeStr) ? timeStr : "09:00").split(":").map(Number);
  const guess = new Date(Date.UTC(y, m - 1, d, hh, mm, 0));
  const offset = tzOffsetMs(tz, guess);
  return new Date(guess.getTime() - offset);
}

export function zonedDayBounds(tz: string, now = new Date()) {
  const today = todayInTz(tz, now);
  const start = makeZonedDate(today, "00:00", tz);
  const end = new Date(start.getTime() + 86_400_000 - 1);
  return { start, end, today };
}

export function toDateInput(date: Date, tz: string) {
  const p = dateParts(date, tz);
  return `${p.y}-${pad(p.m)}-${pad(p.d)}`;
}

export function toTimeInput(date: Date, tz: string) {
  const p = dateParts(date, tz);
  return `${pad(p.h)}:${pad(p.mi)}`;
}

export function addDays(dateStr: string, n: number) {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

export function diffDays(fromStr: string, toStr: string) {
  const [y1, m1, d1] = fromStr.split("-").map(Number);
  const [y2, m2, d2] = toStr.split("-").map(Number);
  return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / 86_400_000);
}

export function isDateOnly(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

export function formatDate(value: Date | string | null | undefined, prefs: FormatPrefs) {
  if (!value) return "—";
  let y: number, m: number, d: number;
  if (isDateOnly(value)) {
    [y, m, d] = value.split("-").map(Number);
  } else {
    const dt = typeof value === "string" ? new Date(value) : value;
    if (Number.isNaN(dt.getTime())) return "—";
    const p = dateParts(dt, prefs.timeZone);
    y = p.y;
    m = p.m;
    d = p.d;
  }
  switch (prefs.dateFormat) {
    case "MM/DD/YYYY":
      return `${pad(m)}/${pad(d)}/${y}`;
    case "YYYY-MM-DD":
      return `${y}-${pad(m)}-${pad(d)}`;
    case "DD MMM YYYY":
      return `${d} ${MONTHS_SHORT[m - 1]} ${y}`;
    case "MMM D, YYYY":
      return `${MONTHS_SHORT[m - 1]} ${d}, ${y}`;
    default:
      return `${pad(d)}/${pad(m)}/${y}`;
  }
}

export function formatTime(value: Date | string | null | undefined, prefs: FormatPrefs) {
  if (!value) return "—";
  const dt = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(dt.getTime())) return "—";
  return new Intl.DateTimeFormat("en-US", {
    timeZone: safeTz(prefs.timeZone),
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(dt);
}

export function formatDateTime(value: Date | string | null | undefined, prefs: FormatPrefs) {
  if (!value) return "—";
  return `${formatDate(value, prefs)}, ${formatTime(value, prefs)}`;
}

export function formatCurrency(value: number | string | null | undefined, currency = "USD") {
  const n = typeof value === "string" ? Number(value) : value;
  if (n === null || n === undefined || !Number.isFinite(n)) return "—";
  try {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency,
      maximumFractionDigits: Number.isInteger(n) ? 0 : 2,
    }).format(n);
  } catch {
    return `${currency} ${n.toFixed(2)}`;
  }
}

export function formatNumber(n: number) {
  return new Intl.NumberFormat("en-US").format(n);
}

export function formatPercent(n: number, digits = 1) {
  if (!Number.isFinite(n)) return "0%";
  return `${n.toFixed(digits)}%`;
}

export function relativeTime(value: Date | string, now = new Date()) {
  const dt = typeof value === "string" ? new Date(value) : value;
  const diff = now.getTime() - dt.getTime();
  const abs = Math.abs(diff);
  const future = diff < 0;
  const minutes = Math.round(abs / 60_000);
  const hours = Math.round(abs / 3_600_000);
  const days = Math.round(abs / 86_400_000);
  let text: string;
  if (minutes < 1) return "just now";
  if (minutes < 60) text = `${minutes}m`;
  else if (hours < 24) text = `${hours}h`;
  else if (days < 7) text = `${days}d`;
  else if (days < 30) text = `${Math.round(days / 7)}w`;
  else if (days < 365) text = `${Math.round(days / 30)}mo`;
  else text = `${Math.round(days / 365)}y`;
  return future ? `in ${text}` : `${text} ago`;
}

/** Human description of when a follow-up is due, relative to "today" in the user's time zone. */
export function describeDue(dueAt: Date, prefs: FormatPrefs, now = new Date()) {
  const today = todayInTz(prefs.timeZone, now);
  const dueDay = toDateInput(dueAt, prefs.timeZone);
  const delta = diffDays(today, dueDay);
  const time = formatTime(dueAt, prefs);
  if (delta === 0) {
    return { label: `Today at ${time}`, tone: dueAt.getTime() < now.getTime() ? "warning" : "info", delta } as const;
  }
  if (delta < 0) {
    const n = Math.abs(delta);
    return { label: `Overdue by ${n} day${n === 1 ? "" : "s"}`, tone: "danger", delta } as const;
  }
  if (delta === 1) return { label: `Tomorrow at ${time}`, tone: "info", delta } as const;
  if (delta < 7) return { label: `In ${delta} days · ${formatDate(dueAt, prefs)}`, tone: "neutral", delta } as const;
  return { label: formatDateTime(dueAt, prefs), tone: "neutral", delta } as const;
}

export function initials(name: string) {
  return (
    name
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((p) => p[0]?.toUpperCase() ?? "")
      .join("") || "?"
  );
}

export function monthLabel(ym: string, withYear = true) {
  const [y, m] = ym.split("-").map(Number);
  return withYear ? `${MONTHS_SHORT[m - 1]} ${String(y).slice(2)}` : MONTHS_SHORT[m - 1];
}

/** Returns the last `n` months (YYYY-MM) ending with the current month in `tz`. */
export function lastNMonths(n: number, tz: string, now = new Date()) {
  const today = todayInTz(tz, now);
  const [y, m] = today.split("-").map(Number);
  const out: string[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const dt = new Date(Date.UTC(y, m - 1 - i, 1));
    out.push(`${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}`);
  }
  return out;
}

export function firstParam(v: string | string[] | undefined) {
  return Array.isArray(v) ? v[0] : v;
}

export function truncate(text: string, max = 80) {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

export function normalizePhone(phone: string) {
  return phone.replace(/[^\d+]/g, "");
}

export function csvEscape(value: unknown) {
  if (value === null || value === undefined) return "";
  const s = value instanceof Date ? value.toISOString() : String(value);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
