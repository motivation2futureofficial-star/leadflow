import "server-only";
import { and, asc, count, desc, eq, gte, ilike, inArray, lt, lte, max, or, sql, type SQL } from "drizzle-orm";
import type { AnyPgColumn } from "drizzle-orm/pg-core";
import { db } from "@/db";
import {
  activityLogs,
  customers,
  enquiries,
  enquirySources,
  followUps,
  notes,
  notifications,
  users,
} from "@/db/schema";
import { ACTIVE_STATUSES, DEFAULT_SOURCES, isPriority, isStatus } from "./constants";
import { zonedDayBounds } from "./format";

// ---------------------------------------------------------------------------
// Sources & options
// ---------------------------------------------------------------------------

export async function getSourceOptions(businessId: string): Promise<string[]> {
  const custom = await db
    .select({ name: enquirySources.name })
    .from(enquirySources)
    .where(eq(enquirySources.businessId, businessId))
    .orderBy(asc(enquirySources.name));
  const set = new Set<string>(DEFAULT_SOURCES);
  for (const c of custom) set.add(c.name);
  return Array.from(set);
}

export async function getAssigneeOptions(businessId: string): Promise<string[]> {
  const rows = await db
    .selectDistinct({ name: enquiries.assignedTo })
    .from(enquiries)
    .where(and(eq(enquiries.businessId, businessId), sql`${enquiries.assignedTo} is not null and ${enquiries.assignedTo} <> ''`))
    .orderBy(asc(enquiries.assignedTo));
  return rows.map((r) => r.name).filter((n): n is string => Boolean(n));
}

export async function getEnquiryOptions(businessId: string) {
  const rows = await db
    .select({ id: enquiries.id, title: enquiries.title, customerName: customers.fullName, status: enquiries.status })
    .from(enquiries)
    .innerJoin(customers, eq(customers.id, enquiries.customerId))
    .where(and(eq(enquiries.businessId, businessId), inArray(enquiries.status, ACTIVE_STATUSES)))
    .orderBy(desc(enquiries.createdAt))
    .limit(500);
  return rows.map((r) => ({ id: r.id, label: `${r.customerName} — ${r.title}` }));
}

// ---------------------------------------------------------------------------
// Enquiries list
// ---------------------------------------------------------------------------

export type EnquiryFilters = {
  q?: string;
  status?: string;
  source?: string;
  priority?: string;
  from?: string;
  to?: string;
  sort?: string;
  dir?: string;
  page?: number;
  pageSize?: number;
  customerId?: string;
};

export const ENQUIRY_SORTS = ["created", "name", "status", "priority", "date", "followup", "value"] as const;

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export function parseEnquiryFilters(sp: Record<string, string | string[] | undefined>): EnquiryFilters {
  const g = (k: string) => {
    const v = sp[k];
    return Array.isArray(v) ? v[0] : v;
  };
  const page = Math.max(1, Number.parseInt(g("page") ?? "1", 10) || 1);
  const pageSizeRaw = Number.parseInt(g("pageSize") ?? "10", 10);
  const pageSize = [10, 25, 50].includes(pageSizeRaw) ? pageSizeRaw : 10;
  return {
    q: g("q")?.trim() || undefined,
    status: g("status") || undefined,
    source: g("source") || undefined,
    priority: g("priority") || undefined,
    from: g("from") || undefined,
    to: g("to") || undefined,
    sort: g("sort") || undefined,
    dir: g("dir") || undefined,
    page,
    pageSize,
  };
}

const nextFollowUpExpr = sql<Date | null>`(select min(f.due_at) from follow_ups f where f.enquiry_id = ${enquiries.id} and f.status = 'pending')`;

function buildEnquiryConditions(businessId: string, f: EnquiryFilters) {
  const conds: (SQL | undefined)[] = [eq(enquiries.businessId, businessId)];
  if (f.q) {
    const like = `%${f.q.replace(/[%_]/g, "\\$&")}%`;
    conds.push(
      or(
        ilike(customers.fullName, like),
        ilike(customers.email, like),
        ilike(customers.phone, like),
        ilike(customers.company, like),
        ilike(enquiries.title, like),
        ilike(enquiries.productService, like),
      ),
    );
  }
  if (isStatus(f.status)) conds.push(eq(enquiries.status, f.status));
  else if (f.status === "active") conds.push(inArray(enquiries.status, ACTIVE_STATUSES));
  if (f.source) conds.push(eq(enquiries.source, f.source));
  if (isPriority(f.priority)) conds.push(eq(enquiries.priority, f.priority));
  if (f.from && DATE_RE.test(f.from)) conds.push(gte(enquiries.enquiryDate, f.from));
  if (f.to && DATE_RE.test(f.to)) conds.push(lte(enquiries.enquiryDate, f.to));
  if (f.customerId) conds.push(eq(enquiries.customerId, f.customerId));
  return and(...conds);
}

export async function listEnquiries(businessId: string, f: EnquiryFilters) {
  const where = buildEnquiryConditions(businessId, f);
  const page = f.page ?? 1;
  const pageSize = f.pageSize ?? 10;
  const dir = f.dir === "asc" ? asc : desc;
  const sortMap: Record<string, SQL | AnyPgColumn> = {
    created: enquiries.createdAt,
    name: customers.fullName,
    status: enquiries.status,
    priority: sql`case ${enquiries.priority} when 'urgent' then 4 when 'high' then 3 when 'medium' then 2 else 1 end`,
    date: enquiries.enquiryDate,
    followup: nextFollowUpExpr,
    value: enquiries.estimatedValue,
  };
  const sortExpr = sortMap[f.sort ?? "created"] ?? enquiries.createdAt;

  const [rows, totalRow] = await Promise.all([
    db
      .select({
        id: enquiries.id,
        title: enquiries.title,
        status: enquiries.status,
        priority: enquiries.priority,
        source: enquiries.source,
        productService: enquiries.productService,
        enquiryDate: enquiries.enquiryDate,
        estimatedValue: enquiries.estimatedValue,
        assignedTo: enquiries.assignedTo,
        createdAt: enquiries.createdAt,
        isDemo: enquiries.isDemo,
        customerId: customers.id,
        customerName: customers.fullName,
        customerPhone: customers.phone,
        customerEmail: customers.email,
        customerCompany: customers.company,
        nextFollowUpAt: nextFollowUpExpr,
      })
      .from(enquiries)
      .innerJoin(customers, eq(customers.id, enquiries.customerId))
      .where(where)
      .orderBy(f.sort === "followup" ? sql`${nextFollowUpExpr} ${sql.raw(f.dir === "asc" ? "asc nulls last" : "desc nulls last")}` : dir(sortExpr), desc(enquiries.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize),
    db
      .select({ total: count() })
      .from(enquiries)
      .innerJoin(customers, eq(customers.id, enquiries.customerId))
      .where(where),
  ]);

  const total = totalRow[0]?.total ?? 0;
  return {
    rows: rows.map((r) => ({ ...r, nextFollowUpAt: r.nextFollowUpAt ? new Date(r.nextFollowUpAt) : null })),
    total,
    page,
    pageSize,
    pageCount: Math.max(1, Math.ceil(total / pageSize)),
  };
}

export type EnquiryListRow = Awaited<ReturnType<typeof listEnquiries>>["rows"][number];

// ---------------------------------------------------------------------------
// Enquiry detail
// ---------------------------------------------------------------------------

export async function getEnquiryDetail(businessId: string, id: string) {
  const rows = await db
    .select({ enquiry: enquiries, customer: customers })
    .from(enquiries)
    .innerJoin(customers, eq(customers.id, enquiries.customerId))
    .where(and(eq(enquiries.id, id), eq(enquiries.businessId, businessId)))
    .limit(1);
  const row = rows[0];
  if (!row) return null;

  const [fus, ns, acts] = await Promise.all([
    db.select().from(followUps).where(eq(followUps.enquiryId, id)).orderBy(asc(followUps.dueAt)),
    db
      .select({ note: notes, authorName: users.fullName })
      .from(notes)
      .leftJoin(users, eq(users.id, notes.authorId))
      .where(eq(notes.enquiryId, id))
      .orderBy(desc(notes.createdAt)),
    db
      .select({ log: activityLogs, userName: users.fullName })
      .from(activityLogs)
      .leftJoin(users, eq(users.id, activityLogs.userId))
      .where(eq(activityLogs.enquiryId, id))
      .orderBy(desc(activityLogs.createdAt))
      .limit(100),
  ]);

  return { enquiry: row.enquiry, customer: row.customer, followUps: fus, notes: ns, activities: acts };
}

// ---------------------------------------------------------------------------
// Customers
// ---------------------------------------------------------------------------

export async function listCustomers(businessId: string, q?: string) {
  const conds: (SQL | undefined)[] = [eq(customers.businessId, businessId)];
  if (q) {
    const like = `%${q.replace(/[%_]/g, "\\$&")}%`;
    conds.push(
      or(ilike(customers.fullName, like), ilike(customers.email, like), ilike(customers.phone, like), ilike(customers.company, like)),
    );
  }
  const rows = await db
    .select({
      customer: customers,
      enquiryCount: count(enquiries.id),
      convertedCount: sql<number>`count(*) filter (where ${enquiries.status} = 'converted')`.mapWith(Number),
      activeCount: sql<number>`count(*) filter (where ${enquiries.status} in ('new','contacted','interested','follow_up_required'))`.mapWith(Number),
      totalValue: sql<string | null>`coalesce(sum(${enquiries.estimatedValue}), 0)`,
      lastEnquiryAt: max(enquiries.createdAt),
      latestStatus: sql<string | null>`(select e2.status from enquiries e2 where e2.customer_id = ${customers.id} order by e2.created_at desc limit 1)`,
    })
    .from(customers)
    .leftJoin(enquiries, eq(enquiries.customerId, customers.id))
    .where(and(...conds))
    .groupBy(customers.id)
    .orderBy(desc(max(enquiries.createdAt)), asc(customers.fullName))
    .limit(500);
  return rows;
}

export async function getCustomerDetail(businessId: string, id: string) {
  const rows = await db
    .select()
    .from(customers)
    .where(and(eq(customers.id, id), eq(customers.businessId, businessId)))
    .limit(1);
  const customer = rows[0];
  if (!customer) return null;
  const [enqs, acts] = await Promise.all([
    db
      .select({ enquiry: enquiries, nextFollowUpAt: nextFollowUpExpr })
      .from(enquiries)
      .where(eq(enquiries.customerId, id))
      .orderBy(desc(enquiries.createdAt)),
    db
      .select({ log: activityLogs, userName: users.fullName, enquiryTitle: enquiries.title })
      .from(activityLogs)
      .innerJoin(enquiries, eq(enquiries.id, activityLogs.enquiryId))
      .leftJoin(users, eq(users.id, activityLogs.userId))
      .where(eq(enquiries.customerId, id))
      .orderBy(desc(activityLogs.createdAt))
      .limit(100),
  ]);
  return {
    customer,
    enquiries: enqs.map((e) => ({ ...e.enquiry, nextFollowUpAt: e.nextFollowUpAt ? new Date(e.nextFollowUpAt) : null })),
    activities: acts,
  };
}

// ---------------------------------------------------------------------------
// Follow-ups
// ---------------------------------------------------------------------------

export async function getFollowUpBuckets(businessId: string, tz: string, includeHistory = false) {
  const now = new Date();
  const { start, end } = zonedDayBounds(tz, now);
  const base = {
    followUp: followUps,
    enquiryTitle: enquiries.title,
    enquiryStatus: enquiries.status,
    customerName: customers.fullName,
    customerPhone: customers.phone,
    customerId: customers.id,
  };
  const pending = await db
    .select(base)
    .from(followUps)
    .innerJoin(enquiries, eq(enquiries.id, followUps.enquiryId))
    .innerJoin(customers, eq(customers.id, enquiries.customerId))
    .where(and(eq(followUps.businessId, businessId), eq(followUps.status, "pending")))
    .orderBy(asc(followUps.dueAt));

  const overdue = pending.filter((p) => p.followUp.dueAt.getTime() < start.getTime());
  const dueToday = pending.filter((p) => p.followUp.dueAt.getTime() >= start.getTime() && p.followUp.dueAt.getTime() <= end.getTime());
  const upcoming = pending.filter((p) => p.followUp.dueAt.getTime() > end.getTime());

  const history = includeHistory
    ? await db
        .select(base)
        .from(followUps)
        .innerJoin(enquiries, eq(enquiries.id, followUps.enquiryId))
        .innerJoin(customers, eq(customers.id, enquiries.customerId))
        .where(and(eq(followUps.businessId, businessId), inArray(followUps.status, ["completed", "cancelled"])))
        .orderBy(desc(followUps.updatedAt))
        .limit(100)
    : [];

  return { overdue, dueToday, upcoming, history, now };
}

export type FollowUpRow = Awaited<ReturnType<typeof getFollowUpBuckets>>["overdue"][number];

export async function getFollowUpCounts(businessId: string, tz: string) {
  const { start, end } = zonedDayBounds(tz);
  const [row] = await db
    .select({
      overdue: sql<number>`count(*) filter (where ${followUps.dueAt} < ${start})`.mapWith(Number),
      dueToday: sql<number>`count(*) filter (where ${followUps.dueAt} >= ${start} and ${followUps.dueAt} <= ${end})`.mapWith(Number),
      pending: count(),
    })
    .from(followUps)
    .where(and(eq(followUps.businessId, businessId), eq(followUps.status, "pending")));
  return row ?? { overdue: 0, dueToday: 0, pending: 0 };
}

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------

export async function getNotifications(userId: string, limit = 50) {
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}

export async function getUnreadCount(userId: string) {
  const [row] = await db
    .select({ n: count() })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
  return row?.n ?? 0;
}

// ---------------------------------------------------------------------------
// Demo + search
// ---------------------------------------------------------------------------

export async function getDemoCounts(businessId: string) {
  const [e] = await db
    .select({ n: count() })
    .from(enquiries)
    .where(and(eq(enquiries.businessId, businessId), eq(enquiries.isDemo, true)));
  const [c] = await db
    .select({ n: count() })
    .from(customers)
    .where(and(eq(customers.businessId, businessId), eq(customers.isDemo, true)));
  return { enquiries: e?.n ?? 0, customers: c?.n ?? 0 };
}

export async function globalSearch(businessId: string, q: string) {
  const like = `%${q.replace(/[%_]/g, "\\$&")}%`;
  const [enqs, custs] = await Promise.all([
    db
      .select({ id: enquiries.id, title: enquiries.title, status: enquiries.status, customerName: customers.fullName })
      .from(enquiries)
      .innerJoin(customers, eq(customers.id, enquiries.customerId))
      .where(
        and(
          eq(enquiries.businessId, businessId),
          or(ilike(enquiries.title, like), ilike(customers.fullName, like), ilike(enquiries.productService, like)),
        ),
      )
      .orderBy(desc(enquiries.createdAt))
      .limit(6),
    db
      .select({ id: customers.id, fullName: customers.fullName, email: customers.email, phone: customers.phone })
      .from(customers)
      .where(
        and(
          eq(customers.businessId, businessId),
          or(ilike(customers.fullName, like), ilike(customers.email, like), ilike(customers.phone, like), ilike(customers.company, like)),
        ),
      )
      .orderBy(asc(customers.fullName))
      .limit(5),
  ]);
  return { enquiries: enqs, customers: custs };
}

export async function getOverdueFollowUpsBefore(businessId: string, before: Date) {
  return db
    .select({ id: followUps.id })
    .from(followUps)
    .where(and(eq(followUps.businessId, businessId), eq(followUps.status, "pending"), lt(followUps.dueAt, before)));
}
