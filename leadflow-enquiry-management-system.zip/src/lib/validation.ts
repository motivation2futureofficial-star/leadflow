import { z } from "zod";
import { PRIORITY_VALUES, STATUS_VALUES } from "./constants";

export const emailSchema = z.string().trim().toLowerCase().email("Enter a valid email address").max(200);
export const optionalEmail = z
  .string()
  .trim()
  .toLowerCase()
  .max(200)
  .refine((v) => v === "" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), "Enter a valid email address");

export const registerSchema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name").max(100),
  businessName: z.string().trim().min(2, "Enter your business name").max(120),
  email: emailSchema,
  password: z.string().min(8, "Password must be at least 8 characters").max(128),
  timeZone: z.string().trim().max(80).optional(),
});

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Enter your password"),
});

export const resetPasswordSchema = z
  .object({
    token: z.string().min(10, "Reset link is invalid"),
    password: z.string().min(8, "Password must be at least 8 characters").max(128),
    confirmPassword: z.string(),
  })
  .refine((d) => d.password === d.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export const onboardingSchema = z.object({
  businessName: z.string().trim().min(2, "Enter your business name").max(120),
  category: z.string().trim().min(1, "Select a business category").max(80),
  size: z.string().trim().min(1, "Select your business size").max(40),
  phone: z.string().trim().max(40),
  email: optionalEmail,
  address: z.string().trim().max(300),
  website: z.string().trim().max(200),
});

export const enquirySchema = z.object({
  customerName: z.string().trim().min(2, "Customer name is required").max(120),
  phone: z.string().trim().min(5, "Phone number is required").max(40),
  email: optionalEmail,
  company: z.string().trim().max(120),
  title: z.string().trim().min(3, "Enquiry title is required").max(200),
  description: z.string().trim().max(5000),
  source: z.string().trim().min(1, "Select an enquiry source").max(60),
  productService: z.string().trim().max(200),
  enquiryDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Enter a valid enquiry date"),
  assignedTo: z.string().trim().max(100),
  priority: z.enum(PRIORITY_VALUES, { message: "Select a priority" }),
  estimatedValue: z.string().trim().max(30),
  internalNotes: z.string().trim().max(5000),
  status: z.enum(STATUS_VALUES).or(z.literal("")).optional(),
  lostReason: z.string().trim().max(500).optional(),
  followUpDate: z.string().trim().optional(),
  followUpTime: z.string().trim().optional(),
});

export const followUpSchema = z.object({
  enquiryId: z.string().uuid("Select an enquiry"),
  title: z.string().trim().min(2, "Enter a reminder title").max(200),
  description: z.string().trim().max(2000),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Choose a follow-up date"),
  time: z.string().regex(/^\d{2}:\d{2}$/, "Choose a follow-up time"),
  priority: z.enum(PRIORITY_VALUES, { message: "Select a priority" }),
});

export const noteSchema = z.string().trim().min(1, "Note cannot be empty").max(5000, "Note is too long");

export const profileSchema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name").max(100),
  email: emailSchema,
});

export const passwordChangeSchema = z
  .object({
    currentPassword: z.string().min(1, "Enter your current password"),
    newPassword: z.string().min(8, "New password must be at least 8 characters").max(128),
    confirmPassword: z.string(),
  })
  .refine((d) => d.newPassword === d.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export const businessSchema = z.object({
  name: z.string().trim().min(2, "Enter your business name").max(120),
  category: z.string().trim().max(80),
  size: z.string().trim().max(40),
  phone: z.string().trim().max(40),
  email: optionalEmail,
  address: z.string().trim().max(300),
  website: z.string().trim().max(200),
});

export const preferencesSchema = z.object({
  dateFormat: z.string().trim().min(1).max(20),
  timeZone: z.string().trim().min(1).max(80),
  currency: z.string().trim().length(3, "Select a currency"),
  defaultDateRange: z.enum(["today", "7d", "30d", "90d", "all"]),
  reminderLeadHours: z.coerce.number().int().min(1).max(168),
});

export function fieldErrorsFrom(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "form");
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}

/** Collect string fields from FormData into a plain object (ignores files). */
export function formToObject(formData: FormData, keys: string[]) {
  const out: Record<string, string> = {};
  for (const key of keys) {
    const v = formData.get(key);
    out[key] = typeof v === "string" ? v : "";
  }
  return out;
}

export function parseMoney(input: string): { value: string | null; error?: string } {
  const raw = input.replace(/[,\s]/g, "");
  if (raw === "") return { value: null };
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 0) return { value: null, error: "Enter a valid amount" };
  if (n > 999_999_999_999) return { value: null, error: "Amount is too large" };
  return { value: n.toFixed(2) };
}
